<script setup>
</script>

<template>
    <div>
        <div class="bg-primary relative z-20">
            <div class="absolute top-0 left-0 w-full h-full bg-black opacity-20 z-10"></div>
            <div class=" px-6 py-24 sm:px-6 sm:py-16 lg:px-8">
                <div class=" mx-auto max-w-6xl text-center">
                    <h2 data-wow-duration="2s" class="wow animate__rubberBand text-3xl font-bold tracking-tight text-black sm:text-4xl">
                        Who we are
                    </h2>
                    <p data-wow-duration="1s" class="wow animate__lightSpeedInRight font-medium text-left mx-auto mt-6 max-w-6xl text-lg leading-8 text-white">
                        We are a team of passionate professionals who share a common vision: to revolutionize the commercial
                        kitchen experience. Our journey began with a collective drive to address the challenges faced by
                        clients when setting up their dream culinary spaces. Drawing from our diverse backgrounds in the
                        hospitality industry, we recognized that many clients, especially first-time purchasers, lacked the
                        knowledge and guidance required to navigate the complexities of commercial kitchen design and
                        equipment selection. We were determined to make a difference.
                    </p>
                    <p data-wow-duration="1s" data-wow-delay="1s" class="wow animate__lightSpeedInLeft font-medium text-left mx-auto mt-6 max-w-6xl text-lg leading-8 text-white">
                        Together, we formed Commercial Kitchens Consultants with a singular mission: to empower our clients
                        and ensure a seamless journey in creating their ideal commercial kitchens. We believe that no client
                        should endure the frustration of unmet timelines or fall prey to suppliers who prioritize their own
                        interests. Join us on this exciting journey as we redefine culinary spaces and elevate the dining
                        experience for your guests. Together, let's create exceptional culinary spaces that inspire,
                        captivate, and drive success. Welcome to Commercial Kitchens Consultants, where we elevate culinary
                        spaces, together.
                    </p>
                    <div data-wow-duration="1s" data-wow-delay="2s" class="wow animate__backInUp mt-10 flex items-center justify-center gap-x-6">
                        <a href="#"
                            class="transform transition hover:scale-125 duration-700 ease-in-out bg-black px-10 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white">
                            Enquire
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>