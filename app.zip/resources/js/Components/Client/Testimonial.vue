<script setup>
</script>

<template>
    <div>
        <div class="relative isolate bg-white pb-32 pt-24 sm:pt-32">
            <div class="absolute inset-x-0 top-1/2 -z-10 -translate-y-1/2 transform-gpu overflow-hidden opacity-30 blur-3xl"
                aria-hidden="true">
                <div class="ml-[max(50%,38rem)] aspect-[1313/771] w-[82.0625rem] bg-gradient-to-tr from-[#f97316] to-[#000]"
                    style="clip-path: polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)">
                </div>
            </div>
            <div class="absolute inset-x-0 top-0 -z-10 flex transform-gpu overflow-hidden pt-32 opacity-25 blur-3xl sm:pt-40 xl:justify-end"
                aria-hidden="true">
                <div class="ml-[-22rem] aspect-[1313/771] w-[82.0625rem] flex-none origin-top-right rotate-[30deg] bg-gradient-to-tr from-[#f97316] to-[#000] xl:ml-0 xl:mr-[calc(50%-12rem)]"
                    style="clip-path: polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)">
                </div>
            </div>
            <div class="mx-auto max-w-7xl px-6 lg:px-8">
                <div class="mx-auto max-w-xl text-center">
                    <h2 class="text-lg font-semibold leading-8 tracking-tight text-primary">Testimonials</h2>
                    <p data-wow-duration="1.5s" class="wow animate__rubberBand mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Working with amazing people</p>
                </div>

                <div
                    class="mx-auto mt-16 grid max-w-2xl grid-cols-1 grid-rows-1 gap-8 text-sm leading-6 text-gray-900 sm:mt-20 sm:grid-cols-2 xl:mx-0 xl:max-w-none xl:grid-flow-col xl:grid-cols-4">

                    <!-- <figure
                        class="col-span-2 hidden sm:block sm:rounded-2xl sm:bg-white sm:shadow-lg sm:ring-1 sm:ring-primary xl:col-start-2 xl:row-end-1">
                        <blockquote class="p-12 text-md font-semibold leading-8 tracking-tight text-gray-900">
                            <p>“I had the pleasure of working with Commercial Kitchens Consultants on our restaurant
                                project, and I
                                couldn&#39;t be more impressed. Despite my frequent travels in and out of the
                                country, they managed the
                                project seamlessly. From kitchen design to equipment selection, their expertise and
                                attention to detail
                                were exceptional. Thanks to their dedication and professionalism, Golden Stool now
                                has a functional
                                and kitchen that perfectly complements our menu”</p>
                        </blockquote>
                    </figure> -->

                    <div class="space-y-8 xl:contents xl:space-y-0">
                        <div data-wow-delay="0.5s" class="wow animate__rubberBand space-y-8 xl:row-span-2">
                            <figure class="mt-1 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary">
                                <blockquote class="text-black font-semibold">
                                    <p>“I had the pleasure of working with Commercial Kitchens Consultants on our restaurant
                                        project, and I
                                        couldn&#39;t be more impressed. Despite my frequent travels in and out of the
                                        country, they managed the
                                        project seamlessly. From kitchen design to equipment selection, their expertise and
                                        attention to detail
                                        were exceptional. Thanks to their dedication and professionalism, Golden Stool now
                                        has a functional
                                        and kitchen that perfectly complements our menu”</p>
                                </blockquote>
                                <figcaption class="mt-6 flex items-center gap-x-4">
                                    <img class="h-10 w-10 rounded-full bg-gray-50"
                                        src="https://goldenstoolkitchen.com/wp-content/uploads/2022/01/golden-logo.svg"
                                        alt="">
                                    <div>
                                        <div class="font-semibold">Martin Yeboha</div>
                                        <div class="text-primary">Golden Stool Restaurant</div>
                                    </div>
                                </figcaption>
                            </figure>

                            <!-- More testimonials... -->
                        </div>
                        <div data-wow-delay="1s" class="wow animate__rubberBand space-y-8 xl:row-start-1">
                            <figure class="mt-14 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary">
                                <blockquote class="text-black font-semibold">
                                    <p>“We had strict timelines to upgrade our cafe&#39;s kitchen. The team displayed
                                        excellent project
                                        management skills and attention to detail. They listened to our requirements and
                                        provided valuable
                                        recommendations. Thanks to their expertise, our kitchen is now more efficient and
                                        functional. I would
                                        highly recommend their services.&quot;”</p>
                                </blockquote>
                                <figcaption class="mt-6 flex items-center gap-x-4">
                                    <img class="h-10 w-10 rounded-full bg-gray-50" src="/img/db.jpg" alt="">
                                    <div>
                                        <div class="font-semibold">Gideon</div>
                                        <div class="text-primary">Dohn Café</div>
                                    </div>
                                </figcaption>
                            </figure>

                            <!-- More testimonials... -->
                        </div>
                    </div>
                    <div class="space-y-8 xl:contents xl:space-y-0">
                        <div data-wow-delay="1.5s" class="wow animate__rubberBand space-y-8 xl:row-start-1">
                            <figure class="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary">
                                <blockquote class="text-black font-semibold">
                                    <p>“ I can confidently recommend Commercial Kitchens Consultants for their
                                        excellent service. Throughout
                                        the process, they provided valuable guidance and support. Despite my busy schedule,
                                        they managed the
                                        project effectively, ensuring we got a kitchen that meets our needs. Their expertise
                                        and transparency
                                        was highly appreciated”</p>
                                </blockquote>
                                <figcaption class="mt-6 flex items-center gap-x-4">
                                    <img class="h-10 w-10 rounded-full bg-gray-50"
                                        src="https://media.istockphoto.com/id/1415397771/vector/teapot-logo-teahouse-logo-design.jpg?s=612x612&w=0&k=20&c=eOa2TDw60gIS3x-pfZM0Wnli048xnproGh1Ic-Xfzhg="
                                        alt="">
                                    <div>
                                        <div class="font-semibold">Tinega</div>
                                        <div class="text-primary">Fahari Tea Restaurant</div>
                                    </div>
                                </figcaption>
                            </figure>

                        </div>
                        <div data-wow-delay="2s" class="wow animate__rubberBand space-y-8 xl:row-span-2">
                            <figure class="mt-20 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary">
                                <blockquote class="text-black font-semibold">
                                    <p>“ This being our first restaurant we had no knowledge of the process and what we
                                        needed for the
                                        kitchen set up. The team at CKC were very helpful and they provided guidance
                                        throughout the process.
                                        They understood our budget constraints and they were able to match us up with
                                        reliable suppliers and
                                        we truly got value for our money. Would highly recommend them.”</p>
                                </blockquote>
                                <figcaption class="mt-6 flex items-center gap-x-4">
                                    <img class="h-10 w-10 rounded-full bg-gray-50"
                                        src="https://media-cdn.grubhub.com/image/upload/d_search:browse-images:default.jpg/w_300,q_100,fl_lossy,dpr_2.0,c_fit,f_auto,h_300/qekxwuihiwpua1rhmxzw"
                                        alt="">
                                    <div>
                                        <div class="font-semibold">Mukhtar</div>
                                        <div class="text-primary">Saffron Grill</div>
                                    </div>
                                </figcaption>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>