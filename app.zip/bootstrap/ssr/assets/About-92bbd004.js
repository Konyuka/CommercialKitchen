import { withCtx, unref, createVNode, createTextVNode, openBlock, createBlock, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderStyle } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ClientLayout-b69b3b9c.js";
import "wow.js";
const _sfc_main = {
  __name: "About",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Our Story" }, null, _parent2, _scopeId));
            _push2(`<div class="bg-primary"${_scopeId}><main class="relative isolate"${_scopeId}><div class="absolute inset-x-0 top-4 -z-10 flex transform-gpu justify-center overflow-hidden blur-3xl" aria-hidden="true"${_scopeId}><div class="aspect-[1108/632] w-[69.25rem] flex-none bg-gradient-to-r from-[#80caff] to-[#4f46e5] opacity-25" style="${ssrRenderStyle({ "clip-path": "polygon(73.6% 51.7%, 91.7% 11.8%, 100% 46.4%, 97.4% 82.2%, 92.5% 84.9%, 75.7% 64%, 55.3% 47.5%, 46.5% 49.4%, 45% 62.9%, 50.3% 87.2%, 21.3% 64.1%, 0.1% 100%, 5.4% 51.1%, 21.4% 63.9%, 58.9% 0.2%, 73.6% 51.7%)" })}"${_scopeId}></div></div><div class="px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl pt-20 text-center"${_scopeId}><h2 class="wow animate__rubberBand text-4xl font-bold tracking-tight text-white sm:text-6xl"${_scopeId}>Who We Are</h2><p class="mt-6 text-lg leading-8 text-black font-bold"${_scopeId}> Commercial Kitchen Consultancy </p></div></div><div class="mx-auto mt-20 max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl lg:mx-0 lg:max-w-none"${_scopeId}><div class="grid max-w-xl grid-cols-1 gap-8 text-base leading-10 text-black font-medium lg:max-w-none lg:grid-cols-2"${_scopeId}><div data-wow-duration="1.5s" data-wow-delay="2s" class="wow animate__lightSpeedInLeft"${_scopeId}><p${_scopeId}> We are a team of passionate professionals who share a common vision: to revolutionize the commercial kitchen experience. Our journey began with a collective drive to address the challenges faced by clients when setting up their dream culinary spaces. <br${_scopeId}> <br${_scopeId}> Drawing from our diverse backgrounds in the hospitality industry, we recognized that many clients, especially first-time purchasers, lacked the knowledge and guidance required to navigate the complexities of commercial kitchen design and equipment selection. We were determined to make a difference. </p></div><div data-wow-duration="1.5s" data-wow-delay="1s" class="wow animate__lightSpeedInLeft"${_scopeId}><p${_scopeId}> Together, we formed Commercial Kitchens Consultants with a singular mission: to empower our clients and ensure a seamless journey in creating their ideal commercial kitchens. We believe that no client should endure the frustration of unmet timelines or fall prey to suppliers who prioritize their own interests. <br${_scopeId}> <br${_scopeId}> Join us on this exciting journey as we redefine culinary spaces and elevate the dining experience for your guests. Together, let&#39;s create exceptional culinary spaces that inspire, captivate, and drive success. Welcome to Commercial Kitchens Consultants, where we elevate culinary spaces, together. </p></div></div><dl class="mt-16 grid grid-cols-1 gap-x-8 gap-y-12 sm:mt-20 sm:grid-cols-2 sm:gap-y-16 lg:mt-28 lg:grid-cols-4"${_scopeId}><div data-wow-duration="1.5s" data-wow-delay="1s" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>Business was founded</dt><dd class="text-3xl font-semibold tracking-tight text-white"${_scopeId}>2015</dd></div><div data-wow-duration="1.5s" data-wow-delay="1.5s" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>People on the team</dt><dd class="text-3xl font-semibold tracking-tight text-white"${_scopeId}>43+</dd></div><div data-wow-duration="1.5s" data-wow-delay="2s" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>Clients on the platform</dt><dd class="text-3xl font-semibold tracking-tight text-white"${_scopeId}>758+</dd></div><div data-wow-duration="1.5s" data-wow-delay="2.5s" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>Projects completed</dt><dd class="text-3xl font-semibold tracking-tight text-white"${_scopeId}>124</dd></div></dl></div></div><div class="mt-32 sm:mt-40 xl:mx-auto xl:max-w-7xl xl:px-8"${_scopeId}><img src="https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;w=2894&amp;q=80" alt="" class="aspect-[9/4] w-full object-cover xl:rounded-3xl"${_scopeId}></div><div class="mx-auto mt-32 max-w-7xl px-6 sm:mt-40 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl lg:mx-0"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-white sm:text-4xl"${_scopeId}>Our values</h2><p class="mt-6 text-lg leading-8 text-gray-300"${_scopeId}>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores impedit perferendis suscipit eaque, iste dolor cupiditate blanditiis.</p></div><dl class="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 text-base leading-7 text-gray-300 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:gap-x-16"${_scopeId}><div class="relative pl-9"${_scopeId}><dt class="inline font-semibold text-white"${_scopeId}><svg class="absolute left-1 top-1 h-5 w-5 text-indigo-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"${_scopeId}><path fill-rule="evenodd" d="M4.606 12.97a.75.75 0 01-.134 1.051 2.494 2.494 0 00-.93 2.437 2.494 2.494 0 002.437-.93.75.75 0 111.186.918 3.995 3.995 0 01-4.482 1.332.75.75 0 01-.461-.461 3.994 3.994 0 011.332-4.482.75.75 0 011.052.134z" clip-rule="evenodd"${_scopeId}></path><path fill-rule="evenodd" d="M5.752 12A13.07 13.07 0 008 14.248v4.002c0 .414.336.75.75.75a5 5 0 004.797-6.414 12.984 12.984 0 005.45-10.848.75.75 0 00-.735-.735 12.984 12.984 0 00-10.849 5.45A5 5 0 001 11.25c.001.414.337.75.751.75h4.002zM13 9a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"${_scopeId}></path></svg> Be world-class. <br${_scopeId}></dt><dd class="inline"${_scopeId}>Lorem ipsum, dolor sit amet consectetur adipisicing elit aute id magna.</dd></div><div class="relative pl-9"${_scopeId}><dt class="inline font-semibold text-white"${_scopeId}><svg class="absolute left-1 top-1 h-5 w-5 text-indigo-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"${_scopeId}><path fill-rule="evenodd" d="M11 2a1 1 0 10-2 0v6.5a.5.5 0 01-1 0V3a1 1 0 10-2 0v5.5a.5.5 0 01-1 0V5a1 1 0 10-2 0v7a7 7 0 1014 0V8a1 1 0 10-2 0v3.5a.5.5 0 01-1 0V3a1 1 0 10-2 0v5.5a.5.5 0 01-1 0V2z" clip-rule="evenodd"${_scopeId}></path></svg> Take responsibility. <br${_scopeId}></dt><dd class="inline"${_scopeId}>Anim aute id magna aliqua ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo.</dd></div><div class="relative pl-9"${_scopeId}><dt class="inline font-semibold text-white"${_scopeId}><svg class="absolute left-1 top-1 h-5 w-5 text-indigo-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"${_scopeId}><path d="M10 9a3 3 0 100-6 3 3 0 000 6zM6 8a2 2 0 11-4 0 2 2 0 014 0zM1.49 15.326a.78.78 0 01-.358-.442 3 3 0 014.308-3.516 6.484 6.484 0 00-1.905 3.959c-.023.222-.014.442.025.654a4.97 4.97 0 01-2.07-.655zM16.44 15.98a4.97 4.97 0 002.07-.654.78.78 0 00.357-.442 3 3 0 00-4.308-3.517 6.484 6.484 0 011.907 3.96 2.32 2.32 0 01-.026.654zM18 8a2 2 0 11-4 0 2 2 0 014 0zM5.304 16.19a.844.844 0 01-.277-.71 5 5 0 019.947 0 .843.843 0 01-.277.71A6.975 6.975 0 0110 18a6.974 6.974 0 01-4.696-1.81z"${_scopeId}></path></svg> Be supportive. <br${_scopeId}></dt><dd class="inline"${_scopeId}>Ac tincidunt sapien vehicula erat auctor pellentesque rhoncus voluptas blanditiis et.</dd></div><div class="relative pl-9"${_scopeId}><dt class="inline font-semibold text-white"${_scopeId}><svg class="absolute left-1 top-1 h-5 w-5 text-indigo-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"${_scopeId}><path fill-rule="evenodd" d="M9.664 1.319a.75.75 0 01.672 0 41.059 41.059 0 018.198 5.424.75.75 0 01-.254 1.285 31.372 31.372 0 00-7.86 3.83.75.75 0 01-.84 0 31.508 31.508 0 00-2.08-1.287V9.394c0-.244.116-.463.302-.592a35.504 35.504 0 013.305-2.033.75.75 0 00-.714-1.319 37 37 0 00-3.446 2.12A2.216 2.216 0 006 9.393v.38a31.293 31.293 0 00-4.28-1.746.75.75 0 01-.254-1.285 41.059 41.059 0 018.198-5.424zM6 11.459a29.848 29.848 0 00-2.455-1.158 41.029 41.029 0 00-.39 3.114.75.75 0 00.419.74c.528.256 1.046.53 1.554.82-.21.324-.455.63-.739.914a.75.75 0 101.06 1.06c.37-.369.69-.77.96-1.193a26.61 26.61 0 013.095 2.348.75.75 0 00.992 0 26.547 26.547 0 015.93-3.95.75.75 0 00.42-.739 41.053 41.053 0 00-.39-3.114 29.925 29.925 0 00-5.199 2.801 2.25 2.25 0 01-2.514 0c-.41-.275-.826-.541-1.25-.797a6.985 6.985 0 01-1.084 3.45 26.503 26.503 0 00-1.281-.78A5.487 5.487 0 006 12v-.54z" clip-rule="evenodd"${_scopeId}></path></svg> Always learning. <br${_scopeId}></dt><dd class="inline"${_scopeId}>Iure sed ab. Aperiam optio placeat dolor facere. Officiis pariatur eveniet atque et dolor.</dd></div><div class="relative pl-9"${_scopeId}><dt class="inline font-semibold text-white"${_scopeId}><svg class="absolute left-1 top-1 h-5 w-5 text-indigo-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"${_scopeId}><path d="M15.98 1.804a1 1 0 00-1.96 0l-.24 1.192a1 1 0 01-.784.785l-1.192.238a1 1 0 000 1.962l1.192.238a1 1 0 01.785.785l.238 1.192a1 1 0 001.962 0l.238-1.192a1 1 0 01.785-.785l1.192-.238a1 1 0 000-1.962l-1.192-.238a1 1 0 01-.785-.785l-.238-1.192zM6.949 5.684a1 1 0 00-1.898 0l-.683 2.051a1 1 0 01-.633.633l-2.051.683a1 1 0 000 1.898l2.051.684a1 1 0 01.633.632l.683 2.051a1 1 0 001.898 0l.683-2.051a1 1 0 01.633-.633l2.051-.683a1 1 0 000-1.898l-2.051-.683a1 1 0 01-.633-.633L6.95 5.684zM13.949 13.684a1 1 0 00-1.898 0l-.184.551a1 1 0 01-.632.633l-.551.183a1 1 0 000 1.898l.551.183a1 1 0 01.633.633l.183.551a1 1 0 001.898 0l.184-.551a1 1 0 01.632-.633l.551-.183a1 1 0 000-1.898l-.551-.184a1 1 0 01-.633-.632l-.183-.551z"${_scopeId}></path></svg> Share everything you know. <br${_scopeId}></dt><dd class="inline"${_scopeId}>Laudantium tempora sint ut consectetur ratione. Ut illum ut rem numquam fuga delectus.</dd></div><div class="relative pl-9"${_scopeId}><dt class="inline font-semibold text-white"${_scopeId}><svg class="absolute left-1 top-1 h-5 w-5 text-indigo-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"${_scopeId}><path d="M10 2a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 2zM10 15a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 15zM10 7a3 3 0 100 6 3 3 0 000-6zM15.657 5.404a.75.75 0 10-1.06-1.06l-1.061 1.06a.75.75 0 001.06 1.06l1.06-1.06zM6.464 14.596a.75.75 0 10-1.06-1.06l-1.06 1.06a.75.75 0 001.06 1.06l1.06-1.06zM18 10a.75.75 0 01-.75.75h-1.5a.75.75 0 010-1.5h1.5A.75.75 0 0118 10zM5 10a.75.75 0 01-.75.75h-1.5a.75.75 0 010-1.5h1.5A.75.75 0 015 10zM14.596 15.657a.75.75 0 001.06-1.06l-1.06-1.061a.75.75 0 10-1.06 1.06l1.06 1.06zM5.404 6.464a.75.75 0 001.06-1.06l-1.06-1.06a.75.75 0 10-1.061 1.06l1.06 1.06z"${_scopeId}></path></svg> Enjoy downtime. <br${_scopeId}></dt><dd class="inline"${_scopeId}>Culpa dolorem voluptatem velit autem rerum qui et corrupti. Quibusdam quo placeat.</dd></div></dl></div><div class="mx-auto mt-32 max-w-7xl px-6 sm:mt-40 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl lg:mx-0"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-white sm:text-4xl"${_scopeId}>Our portfolio</h2><p class="mt-6 text-lg leading-8 text-black font-medium"${_scopeId}>Who we have work with</p></div><ul role="list" class="mx-auto mt-20 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-14 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:grid-cols-3 xl:grid-cols-4"${_scopeId}><li${_scopeId}><img class="aspect-[14/13] w-full rounded-2xl object-cover" src="https://trendtype.com/wp-content/uploads/2017/07/Java-House-logo.jpg" alt=""${_scopeId}><h3 class="mb-20 mt-6 text-lg font-semibold leading-8 tracking-tight text-white"${_scopeId}>Java</h3></li></ul></div></main><div${_scopeId}></div></div>`);
          } else {
            return [
              createVNode(unref(Head), { title: "Our Story" }),
              createVNode("div", { class: "bg-primary" }, [
                createVNode("main", { class: "relative isolate" }, [
                  createVNode("div", {
                    class: "absolute inset-x-0 top-4 -z-10 flex transform-gpu justify-center overflow-hidden blur-3xl",
                    "aria-hidden": "true"
                  }, [
                    createVNode("div", {
                      class: "aspect-[1108/632] w-[69.25rem] flex-none bg-gradient-to-r from-[#80caff] to-[#4f46e5] opacity-25",
                      style: { "clip-path": "polygon(73.6% 51.7%, 91.7% 11.8%, 100% 46.4%, 97.4% 82.2%, 92.5% 84.9%, 75.7% 64%, 55.3% 47.5%, 46.5% 49.4%, 45% 62.9%, 50.3% 87.2%, 21.3% 64.1%, 0.1% 100%, 5.4% 51.1%, 21.4% 63.9%, 58.9% 0.2%, 73.6% 51.7%)" }
                    })
                  ]),
                  createVNode("div", { class: "px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl pt-20 text-center" }, [
                      createVNode("h2", { class: "wow animate__rubberBand text-4xl font-bold tracking-tight text-white sm:text-6xl" }, "Who We Are"),
                      createVNode("p", { class: "mt-6 text-lg leading-8 text-black font-bold" }, " Commercial Kitchen Consultancy ")
                    ])
                  ]),
                  createVNode("div", { class: "mx-auto mt-20 max-w-7xl px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl lg:mx-0 lg:max-w-none" }, [
                      createVNode("div", { class: "grid max-w-xl grid-cols-1 gap-8 text-base leading-10 text-black font-medium lg:max-w-none lg:grid-cols-2" }, [
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "2s",
                          class: "wow animate__lightSpeedInLeft"
                        }, [
                          createVNode("p", null, [
                            createTextVNode(" We are a team of passionate professionals who share a common vision: to revolutionize the commercial kitchen experience. Our journey began with a collective drive to address the challenges faced by clients when setting up their dream culinary spaces. "),
                            createVNode("br"),
                            createTextVNode(),
                            createVNode("br"),
                            createTextVNode(" Drawing from our diverse backgrounds in the hospitality industry, we recognized that many clients, especially first-time purchasers, lacked the knowledge and guidance required to navigate the complexities of commercial kitchen design and equipment selection. We were determined to make a difference. ")
                          ])
                        ]),
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "1s",
                          class: "wow animate__lightSpeedInLeft"
                        }, [
                          createVNode("p", null, [
                            createTextVNode(" Together, we formed Commercial Kitchens Consultants with a singular mission: to empower our clients and ensure a seamless journey in creating their ideal commercial kitchens. We believe that no client should endure the frustration of unmet timelines or fall prey to suppliers who prioritize their own interests. "),
                            createVNode("br"),
                            createTextVNode(),
                            createVNode("br"),
                            createTextVNode(" Join us on this exciting journey as we redefine culinary spaces and elevate the dining experience for your guests. Together, let's create exceptional culinary spaces that inspire, captivate, and drive success. Welcome to Commercial Kitchens Consultants, where we elevate culinary spaces, together. ")
                          ])
                        ])
                      ]),
                      createVNode("dl", { class: "mt-16 grid grid-cols-1 gap-x-8 gap-y-12 sm:mt-20 sm:grid-cols-2 sm:gap-y-16 lg:mt-28 lg:grid-cols-4" }, [
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "1s",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "Business was founded"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-white" }, "2015")
                        ]),
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "1.5s",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "People on the team"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-white" }, "43+")
                        ]),
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "2s",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "Clients on the platform"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-white" }, "758+")
                        ]),
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "2.5s",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "Projects completed"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-white" }, "124")
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "mt-32 sm:mt-40 xl:mx-auto xl:max-w-7xl xl:px-8" }, [
                    createVNode("img", {
                      src: "https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2894&q=80",
                      alt: "",
                      class: "aspect-[9/4] w-full object-cover xl:rounded-3xl"
                    })
                  ]),
                  createVNode("div", { class: "mx-auto mt-32 max-w-7xl px-6 sm:mt-40 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl lg:mx-0" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-white sm:text-4xl" }, "Our values"),
                      createVNode("p", { class: "mt-6 text-lg leading-8 text-gray-300" }, "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores impedit perferendis suscipit eaque, iste dolor cupiditate blanditiis.")
                    ]),
                    createVNode("dl", { class: "mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 text-base leading-7 text-gray-300 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:gap-x-16" }, [
                      createVNode("div", { class: "relative pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-white" }, [
                          (openBlock(), createBlock("svg", {
                            class: "absolute left-1 top-1 h-5 w-5 text-indigo-500",
                            viewBox: "0 0 20 20",
                            fill: "currentColor",
                            "aria-hidden": "true"
                          }, [
                            createVNode("path", {
                              "fill-rule": "evenodd",
                              d: "M4.606 12.97a.75.75 0 01-.134 1.051 2.494 2.494 0 00-.93 2.437 2.494 2.494 0 002.437-.93.75.75 0 111.186.918 3.995 3.995 0 01-4.482 1.332.75.75 0 01-.461-.461 3.994 3.994 0 011.332-4.482.75.75 0 011.052.134z",
                              "clip-rule": "evenodd"
                            }),
                            createVNode("path", {
                              "fill-rule": "evenodd",
                              d: "M5.752 12A13.07 13.07 0 008 14.248v4.002c0 .414.336.75.75.75a5 5 0 004.797-6.414 12.984 12.984 0 005.45-10.848.75.75 0 00-.735-.735 12.984 12.984 0 00-10.849 5.45A5 5 0 001 11.25c.001.414.337.75.751.75h4.002zM13 9a2 2 0 100-4 2 2 0 000 4z",
                              "clip-rule": "evenodd"
                            })
                          ])),
                          createTextVNode(" Be world-class. "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "inline" }, "Lorem ipsum, dolor sit amet consectetur adipisicing elit aute id magna.")
                      ]),
                      createVNode("div", { class: "relative pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-white" }, [
                          (openBlock(), createBlock("svg", {
                            class: "absolute left-1 top-1 h-5 w-5 text-indigo-500",
                            viewBox: "0 0 20 20",
                            fill: "currentColor",
                            "aria-hidden": "true"
                          }, [
                            createVNode("path", {
                              "fill-rule": "evenodd",
                              d: "M11 2a1 1 0 10-2 0v6.5a.5.5 0 01-1 0V3a1 1 0 10-2 0v5.5a.5.5 0 01-1 0V5a1 1 0 10-2 0v7a7 7 0 1014 0V8a1 1 0 10-2 0v3.5a.5.5 0 01-1 0V3a1 1 0 10-2 0v5.5a.5.5 0 01-1 0V2z",
                              "clip-rule": "evenodd"
                            })
                          ])),
                          createTextVNode(" Take responsibility. "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "inline" }, "Anim aute id magna aliqua ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo.")
                      ]),
                      createVNode("div", { class: "relative pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-white" }, [
                          (openBlock(), createBlock("svg", {
                            class: "absolute left-1 top-1 h-5 w-5 text-indigo-500",
                            viewBox: "0 0 20 20",
                            fill: "currentColor",
                            "aria-hidden": "true"
                          }, [
                            createVNode("path", { d: "M10 9a3 3 0 100-6 3 3 0 000 6zM6 8a2 2 0 11-4 0 2 2 0 014 0zM1.49 15.326a.78.78 0 01-.358-.442 3 3 0 014.308-3.516 6.484 6.484 0 00-1.905 3.959c-.023.222-.014.442.025.654a4.97 4.97 0 01-2.07-.655zM16.44 15.98a4.97 4.97 0 002.07-.654.78.78 0 00.357-.442 3 3 0 00-4.308-3.517 6.484 6.484 0 011.907 3.96 2.32 2.32 0 01-.026.654zM18 8a2 2 0 11-4 0 2 2 0 014 0zM5.304 16.19a.844.844 0 01-.277-.71 5 5 0 019.947 0 .843.843 0 01-.277.71A6.975 6.975 0 0110 18a6.974 6.974 0 01-4.696-1.81z" })
                          ])),
                          createTextVNode(" Be supportive. "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "inline" }, "Ac tincidunt sapien vehicula erat auctor pellentesque rhoncus voluptas blanditiis et.")
                      ]),
                      createVNode("div", { class: "relative pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-white" }, [
                          (openBlock(), createBlock("svg", {
                            class: "absolute left-1 top-1 h-5 w-5 text-indigo-500",
                            viewBox: "0 0 20 20",
                            fill: "currentColor",
                            "aria-hidden": "true"
                          }, [
                            createVNode("path", {
                              "fill-rule": "evenodd",
                              d: "M9.664 1.319a.75.75 0 01.672 0 41.059 41.059 0 018.198 5.424.75.75 0 01-.254 1.285 31.372 31.372 0 00-7.86 3.83.75.75 0 01-.84 0 31.508 31.508 0 00-2.08-1.287V9.394c0-.244.116-.463.302-.592a35.504 35.504 0 013.305-2.033.75.75 0 00-.714-1.319 37 37 0 00-3.446 2.12A2.216 2.216 0 006 9.393v.38a31.293 31.293 0 00-4.28-1.746.75.75 0 01-.254-1.285 41.059 41.059 0 018.198-5.424zM6 11.459a29.848 29.848 0 00-2.455-1.158 41.029 41.029 0 00-.39 3.114.75.75 0 00.419.74c.528.256 1.046.53 1.554.82-.21.324-.455.63-.739.914a.75.75 0 101.06 1.06c.37-.369.69-.77.96-1.193a26.61 26.61 0 013.095 2.348.75.75 0 00.992 0 26.547 26.547 0 015.93-3.95.75.75 0 00.42-.739 41.053 41.053 0 00-.39-3.114 29.925 29.925 0 00-5.199 2.801 2.25 2.25 0 01-2.514 0c-.41-.275-.826-.541-1.25-.797a6.985 6.985 0 01-1.084 3.45 26.503 26.503 0 00-1.281-.78A5.487 5.487 0 006 12v-.54z",
                              "clip-rule": "evenodd"
                            })
                          ])),
                          createTextVNode(" Always learning. "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "inline" }, "Iure sed ab. Aperiam optio placeat dolor facere. Officiis pariatur eveniet atque et dolor.")
                      ]),
                      createVNode("div", { class: "relative pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-white" }, [
                          (openBlock(), createBlock("svg", {
                            class: "absolute left-1 top-1 h-5 w-5 text-indigo-500",
                            viewBox: "0 0 20 20",
                            fill: "currentColor",
                            "aria-hidden": "true"
                          }, [
                            createVNode("path", { d: "M15.98 1.804a1 1 0 00-1.96 0l-.24 1.192a1 1 0 01-.784.785l-1.192.238a1 1 0 000 1.962l1.192.238a1 1 0 01.785.785l.238 1.192a1 1 0 001.962 0l.238-1.192a1 1 0 01.785-.785l1.192-.238a1 1 0 000-1.962l-1.192-.238a1 1 0 01-.785-.785l-.238-1.192zM6.949 5.684a1 1 0 00-1.898 0l-.683 2.051a1 1 0 01-.633.633l-2.051.683a1 1 0 000 1.898l2.051.684a1 1 0 01.633.632l.683 2.051a1 1 0 001.898 0l.683-2.051a1 1 0 01.633-.633l2.051-.683a1 1 0 000-1.898l-2.051-.683a1 1 0 01-.633-.633L6.95 5.684zM13.949 13.684a1 1 0 00-1.898 0l-.184.551a1 1 0 01-.632.633l-.551.183a1 1 0 000 1.898l.551.183a1 1 0 01.633.633l.183.551a1 1 0 001.898 0l.184-.551a1 1 0 01.632-.633l.551-.183a1 1 0 000-1.898l-.551-.184a1 1 0 01-.633-.632l-.183-.551z" })
                          ])),
                          createTextVNode(" Share everything you know. "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "inline" }, "Laudantium tempora sint ut consectetur ratione. Ut illum ut rem numquam fuga delectus.")
                      ]),
                      createVNode("div", { class: "relative pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-white" }, [
                          (openBlock(), createBlock("svg", {
                            class: "absolute left-1 top-1 h-5 w-5 text-indigo-500",
                            viewBox: "0 0 20 20",
                            fill: "currentColor",
                            "aria-hidden": "true"
                          }, [
                            createVNode("path", { d: "M10 2a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 2zM10 15a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 15zM10 7a3 3 0 100 6 3 3 0 000-6zM15.657 5.404a.75.75 0 10-1.06-1.06l-1.061 1.06a.75.75 0 001.06 1.06l1.06-1.06zM6.464 14.596a.75.75 0 10-1.06-1.06l-1.06 1.06a.75.75 0 001.06 1.06l1.06-1.06zM18 10a.75.75 0 01-.75.75h-1.5a.75.75 0 010-1.5h1.5A.75.75 0 0118 10zM5 10a.75.75 0 01-.75.75h-1.5a.75.75 0 010-1.5h1.5A.75.75 0 015 10zM14.596 15.657a.75.75 0 001.06-1.06l-1.06-1.061a.75.75 0 10-1.06 1.06l1.06 1.06zM5.404 6.464a.75.75 0 001.06-1.06l-1.06-1.06a.75.75 0 10-1.061 1.06l1.06 1.06z" })
                          ])),
                          createTextVNode(" Enjoy downtime. "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "inline" }, "Culpa dolorem voluptatem velit autem rerum qui et corrupti. Quibusdam quo placeat.")
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "mx-auto mt-32 max-w-7xl px-6 sm:mt-40 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl lg:mx-0" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-white sm:text-4xl" }, "Our portfolio"),
                      createVNode("p", { class: "mt-6 text-lg leading-8 text-black font-medium" }, "Who we have work with")
                    ]),
                    createVNode("ul", {
                      role: "list",
                      class: "mx-auto mt-20 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-14 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:grid-cols-3 xl:grid-cols-4"
                    }, [
                      createVNode("li", null, [
                        createVNode("img", {
                          class: "aspect-[14/13] w-full rounded-2xl object-cover",
                          src: "https://trendtype.com/wp-content/uploads/2017/07/Java-House-logo.jpg",
                          alt: ""
                        }),
                        createVNode("h3", { class: "mb-20 mt-6 text-lg font-semibold leading-8 tracking-tight text-white" }, "Java")
                      ])
                    ])
                  ])
                ]),
                createVNode("div")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Client/About.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
