import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderSlot } from "vue/server-renderer";
import { computed, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, createTextVNode, useSSRContext, onMounted } from "vue";
import { Link } from "@inertiajs/vue3";
import WOW from "wow.js";
const _sfc_main$2 = {
  __name: "Navigation",
  __ssrInlineRender: true,
  setup(__props) {
    const currentRoute = computed(() => {
      const pathName = window.location.pathname;
      return pathName;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "bg-black min-h-[120px] border-gray-200 dark:bg-gray-900 px-10" }, _attrs))}><div class="max-w-screen-2xl flex-wrap flex justify-between mx-auto items-center px-4 py-2"><div class="flex gap-10 mt-2"><a href="https://www.instagram.com/commercialkitchensconsultants/" target="_blank"><img src="/img/fb.svg" alt="" class="h-8 w-8 wow animate__zoomInDown" data-wow-duration="0.5s"></a><a href="https://www.instagram.com/commercialkitchensconsultants/" target="_blank"><img src="/img/ig.svg" alt="" class="h-8 w-8 wow animate__zoomInDown" data-wow-duration="1s"></a><a href="https://www.instagram.com/commercialkitchensconsultants/" target="_blank"><img src="/img/linkedin.svg" alt="" class="h-8 w-8 wow animate__zoomInDown" data-wow-duration="1.5s"></a></div><div class="flex justify-between"><a href="tel:+254717269050" class="text-white text-xl mr-10 wow animate__zoomInDown" data-wow-duration="2s"><i class="fas fa-phone-volume text-primary fa-xl mr-2"></i> +254 717 269 050 </a><a href="tel:+254717269050" class="text-white text-xl wow animate__zoomInDown" data-wow-duration="2.5s"><i class="fas fa-envelope-dot text-primary fa-xl mr-2"></i> info@commercialkitchen.co.ke </a></div><div class="flex gap-2"><button type="button" data-wow-duration="3s" class="wow animate__zoomInDown border-2 border-primary hover:bg-primary hover:text-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"> Supplier Portal </button><button type="button" data-wow-duration="3.5s" class="wow animate__zoomInDown border-2 border-primary hover:bg-primary hover:text-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"> Client Portal </button></div></div><div class="max-w-screen-2xl flex flex-wrap items-center justify-between mx-auto px-4 py-2">`);
      _push(ssrRenderComponent(unref(Link), {
        to: "/",
        class: "flex items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img src="/img/logo.jpg" class="h-20 mr-3 wow animate__lightSpeedInLeft fadein" data-wow-duration="1s" data-wow-delay="2s" alt="Flowbite Logo"${_scopeId}><span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white"${_scopeId}>Commercial Kitchen Equipment</span>`);
          } else {
            return [
              createVNode("img", {
                src: "/img/logo.jpg",
                class: "h-20 mr-3 wow animate__lightSpeedInLeft fadein",
                "data-wow-duration": "1s",
                "data-wow-delay": "2s",
                alt: "Flowbite Logo"
              }),
              createVNode("span", { class: "self-center text-2xl font-semibold whitespace-nowrap dark:text-white" }, "Commercial Kitchen Equipment")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button data-collapse-toggle="navbar-default" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false"><span class="sr-only">Open main menu</span><svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15"></path></svg></button><div class="hidden w-full md:block md:w-auto" id="navbar-default"><ul class="font-medium flex flex-col p-4 md:p-0 mt-4 border rounded-lg md:flex-row md:space-x-1 md:mt-0 md:border-0"><li>`);
      _push(ssrRenderComponent(unref(Link), {
        href: "/",
        class: [[currentRoute.value == "/" ? "text-primary font-bold" : "text-white"], "wow animate__lightSpeedInRight block py-2 pl-3 pr-4 text-xl rounded md:bg-transparent"],
        "data-wow-duration": "2s",
        "aria-current": "page"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (currentRoute.value == "/") {
              _push2(`<i class="fas fa-caret-right"${_scopeId}></i>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(` Home `);
          } else {
            return [
              currentRoute.value == "/" ? (openBlock(), createBlock("i", {
                key: 0,
                class: "fas fa-caret-right"
              })) : createCommentVNode("", true),
              createTextVNode(" Home ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(unref(Link), {
        href: "/commercial-kitchen-services",
        class: [[currentRoute.value == "/commercial-kitchen-services" ? "text-primary font-bold" : "text-white"], "wow animate__lightSpeedInRight block py-2 pl-3 pr-4 text-xl rounded md:bg-transparent"],
        "data-wow-duration": "2.5s",
        "aria-current": "page"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (currentRoute.value == "/commercial-kitchen-services") {
              _push2(`<i class="fas fa-caret-right"${_scopeId}></i>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(` Services `);
          } else {
            return [
              currentRoute.value == "/commercial-kitchen-services" ? (openBlock(), createBlock("i", {
                key: 0,
                class: "fas fa-caret-right"
              })) : createCommentVNode("", true),
              createTextVNode(" Services ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(unref(Link), {
        href: "/commercial-kitchen-about",
        class: [[currentRoute.value == "/commercial-kitchen-about" ? "text-primary font-bold" : "text-white"], "wow animate__lightSpeedInRight block py-2 pl-3 pr-4 text-xl rounded md:bg-transparent"],
        "data-wow-duration": "3s",
        "aria-current": "page"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (currentRoute.value == "/commercial-kitchen-about") {
              _push2(`<i class="fas fa-caret-right"${_scopeId}></i>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(` Our Story `);
          } else {
            return [
              currentRoute.value == "/commercial-kitchen-about" ? (openBlock(), createBlock("i", {
                key: 0,
                class: "fas fa-caret-right"
              })) : createCommentVNode("", true),
              createTextVNode(" Our Story ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(unref(Link), {
        href: "/commercial-kitchen-media",
        class: [[currentRoute.value == "/commercial-kitchen-media" ? "text-primary font-bold" : "text-white"], "wow animate__lightSpeedInRight block py-2 pl-3 pr-4 text-xl rounded md:bg-transparent"],
        "data-wow-duration": "3.5s",
        "aria-current": "page"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (currentRoute.value == "/commercial-kitchen-media") {
              _push2(`<i class="fas fa-caret-right"${_scopeId}></i>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(` Media `);
          } else {
            return [
              currentRoute.value == "/commercial-kitchen-media" ? (openBlock(), createBlock("i", {
                key: 0,
                class: "fas fa-caret-right"
              })) : createCommentVNode("", true),
              createTextVNode(" Media ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li>`);
      _push(ssrRenderComponent(unref(Link), {
        href: "/commercial-kitchen-contact",
        class: [[currentRoute.value == "/commercial-kitchen-contact" ? "text-primary font-bold" : "text-white"], "wow animate__lightSpeedInRight block py-2 pl-3 pr-4 text-xl rounded md:bg-transparent"],
        "aria-current": "page"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (currentRoute.value == "/commercial-kitchen-contact") {
              _push2(`<i class="fas fa-caret-right"${_scopeId}></i>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(` Get in Touch `);
          } else {
            return [
              currentRoute.value == "/commercial-kitchen-contact" ? (openBlock(), createBlock("i", {
                key: 0,
                class: "fas fa-caret-right"
              })) : createCommentVNode("", true),
              createTextVNode(" Get in Touch ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div></div></nav>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Client/Navigation.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    const currentYear = computed(() => {
      const currentDate = /* @__PURE__ */ new Date();
      return currentDate.getFullYear();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><footer class="bg-black" aria-labelledby="footer-heading"><h2 id="footer-heading" class="sr-only">Footer</h2><div class="mx-auto max-w-7xl px-6 pb-8 pt-16 sm:pt-10"><div class="xl:grid xl:grid-cols-3 xl:gap-8"><img data-wow-delay="2s" class="wow animate__lightSpeedInLeft h-20 w-18" src="/img/logo.jpg" alt="Commercial Kitchen"><div class="mt-16 grid grid-cols-2 gap-8 xl:col-span-2 xl:mt-0"><div class="md:grid md:grid-cols-2 md:gap-8"></div><div class="md:grid md:grid-cols-2 md:gap-8"><div><h3 class="text-sm font-semibold leading-6 text-primary">Quick Links</h3><ul role="list" class="mt-6 space-y-4"><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> Services</a></li><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> Products</a></li><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> Contact Us</a></li><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> About Us</a></li></ul></div><div class="mt-10 md:mt-0"><h3 class="text-sm font-semibold leading-6 text-primary">Helper Links</h3><ul role="list" class="mt-6 space-y-4"><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> Blogs</a></li><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> Gallery</a></li><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> Careers</a></li><li><a href="#" class="text-sm leading-6 text-white hover:text-primary"><i class="mr-2 fas fa-caret-right"></i> Policies</a></li></ul></div></div></div></div><div class="mt-10 border-t border-white/10 lg:flex lg:items-center lg:justify-between"><div><h3 class="text-sm font-semibold leading-6 text-primary">Subscribe to our newsletter</h3><p class="mt-2 text-sm leading-6 text-white">The latest news, articles, and resources, sent to your inbox weekly.</p></div><form class="mt-6 sm:flex sm:max-w-md lg:mt-0"><label for="email-address" class="sr-only">Email address</label><input type="email" name="email-address" id="email-address" autocomplete="email" required class="w-full min-w-0 appearance-none rounded-md border-0 bg-white/5 px-3 py-1.5 text-base font-medium text-white shadow-sm ring-1 ring-inset ring-white placeholder:text-white focus:ring-2 focus:ring-inset focus:ring-primary sm:w-56 sm:text-sm sm:leading-6" placeholder="Enter your email"><div class="mt-4 sm:ml-4 sm:mt-0 sm:flex-shrink-0"><button type="submit" class="flex w-full items-center justify-center rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white shadow-sm ring-1 ring-primary hover:bg-primary hover:text-black hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500">Subscribe</button></div></form></div><div class="mt-8 border-t border-white/10 pt-8 md:flex md:items-center md:justify-between"><div class="flex space-x-6 md:order-2"><div class="flex gap-16 mt-2"><a href="https://www.instagram.com/commercialkitchensconsultants/" target="_blank"><img src="/img/fb.svg" alt="" class="h-8 w-8"></a><a href="https://www.instagram.com/commercialkitchensconsultants/" target="_blank"><img src="/img/ig.svg" alt="" class="h-8 w-8"></a><a href="https://www.instagram.com/commercialkitchensconsultants/" target="_blank"><img src="/img/linkedin.svg" alt="" class="h-8 w-8"></a></div></div><p class="mt-8 text-xs leading-5 text-white md:order-1 md:mt-0">© ${ssrInterpolate(currentYear.value)} Commercial Kitchen Equipment </p><p class="mt-8 text-xs leading-5 text-white md:order-1 md:mt-0">Designed by <a href="https://www.linkedin.com/in/michaelsaiba/" target="_blank" class="text-primary underline">Michael Saiba</a></p></div></div></footer></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Client/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "ClientLayout",
  __ssrInlineRender: true,
  setup(__props) {
    onMounted(() => {
      new WOW().init();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(ssrRenderComponent(_sfc_main$1, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/ClientLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
