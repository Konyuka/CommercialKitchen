import { unref, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ClientLayout-b69b3b9c.js";
import "wow.js";
const _sfc_main = {
  __name: "Media",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Blogs & Gallery" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="bg-white py-24 sm:py-32"${_scopeId}><div class="mx-auto max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl text-center"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-primary sm:text-4xl"${_scopeId}>From our blogs</h2><p class="mt-2 text-lg leading-8 text-gray-600"${_scopeId}>Learn how to grow your business with our expert advice.</p></div><div class="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3"${_scopeId}><article class="flex flex-col items-start justify-between"${_scopeId}><div class="relative w-full"${_scopeId}><img src="https://images.unsplash.com/photo-1496128858413-b36217c2ce36?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;w=3603&amp;q=80" alt="" class="aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"${_scopeId}><div class="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10"${_scopeId}></div></div><div class="max-w-xl"${_scopeId}><div class="mt-8 flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Mar 16, 2023</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Marketing</a></div><div class="group relative"${_scopeId}><h3 class="mt-3 text-lg font-semibold leading-6 text-primary group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Boost your conversion rate </a></h3><p class="mt-5 line-clamp-3 text-sm leading-6 text-black font-medium"${_scopeId}>Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.</p></div></div></article></div></div></div><div class="bg-white py-24 sm:py-32"${_scopeId}><div class="mx-auto max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl text-center"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-primary sm:text-4xl"${_scopeId}>From our Gallery</h2></div><div class="mx-auto mt-16 grid max-w-2xl auto-rows-fr grid-cols-1 gap-8 sm:mt-20 lg:mx-0 lg:max-w-none lg:grid-cols-3"${_scopeId}><article class="relative isolate flex flex-col justify-end overflow-hidden rounded-2xl bg-gray-900 px-8 pb-8 pt-80 sm:pt-48 lg:pt-80"${_scopeId}><img src="https://images.unsplash.com/photo-1496128858413-b36217c2ce36?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;w=3603&amp;q=80" alt="" class="absolute inset-0 -z-10 h-full w-full object-cover"${_scopeId}><div class="absolute inset-0 -z-10 bg-gradient-to-t from-gray-900 via-gray-900/40"${_scopeId}></div><div class="absolute inset-0 -z-10 rounded-2xl ring-1 ring-inset ring-gray-900/10"${_scopeId}></div><h3 class="mt-3 text-lg font-semibold leading-6 text-black"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Boost your conversion rate </a></h3></article></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "bg-white py-24 sm:py-32" }, [
                  createVNode("div", { class: "mx-auto max-w-7xl px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl text-center" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-primary sm:text-4xl" }, "From our blogs"),
                      createVNode("p", { class: "mt-2 text-lg leading-8 text-gray-600" }, "Learn how to grow your business with our expert advice.")
                    ]),
                    createVNode("div", { class: "mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3" }, [
                      createVNode("article", { class: "flex flex-col items-start justify-between" }, [
                        createVNode("div", { class: "relative w-full" }, [
                          createVNode("img", {
                            src: "https://images.unsplash.com/photo-1496128858413-b36217c2ce36?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3603&q=80",
                            alt: "",
                            class: "aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"
                          }),
                          createVNode("div", { class: "absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" })
                        ]),
                        createVNode("div", { class: "max-w-xl" }, [
                          createVNode("div", { class: "mt-8 flex items-center gap-x-4 text-xs" }, [
                            createVNode("time", {
                              datetime: "2020-03-16",
                              class: "text-gray-500"
                            }, "Mar 16, 2023"),
                            createVNode("a", {
                              href: "#",
                              class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                            }, "Marketing")
                          ]),
                          createVNode("div", { class: "group relative" }, [
                            createVNode("h3", { class: "mt-3 text-lg font-semibold leading-6 text-primary group-hover:text-gray-600" }, [
                              createVNode("a", { href: "#" }, [
                                createVNode("span", { class: "absolute inset-0" }),
                                createTextVNode(" Boost your conversion rate ")
                              ])
                            ]),
                            createVNode("p", { class: "mt-5 line-clamp-3 text-sm leading-6 text-black font-medium" }, "Illo sint voluptas. Error voluptates culpa eligendi. Hic vel totam vitae illo. Non aliquid explicabo necessitatibus unde. Sed exercitationem placeat consectetur nulla deserunt vel. Iusto corrupti dicta.")
                          ])
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white py-24 sm:py-32" }, [
                  createVNode("div", { class: "mx-auto max-w-7xl px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl text-center" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-primary sm:text-4xl" }, "From our Gallery")
                    ]),
                    createVNode("div", { class: "mx-auto mt-16 grid max-w-2xl auto-rows-fr grid-cols-1 gap-8 sm:mt-20 lg:mx-0 lg:max-w-none lg:grid-cols-3" }, [
                      createVNode("article", { class: "relative isolate flex flex-col justify-end overflow-hidden rounded-2xl bg-gray-900 px-8 pb-8 pt-80 sm:pt-48 lg:pt-80" }, [
                        createVNode("img", {
                          src: "https://images.unsplash.com/photo-1496128858413-b36217c2ce36?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=3603&q=80",
                          alt: "",
                          class: "absolute inset-0 -z-10 h-full w-full object-cover"
                        }),
                        createVNode("div", { class: "absolute inset-0 -z-10 bg-gradient-to-t from-gray-900 via-gray-900/40" }),
                        createVNode("div", { class: "absolute inset-0 -z-10 rounded-2xl ring-1 ring-inset ring-gray-900/10" }),
                        createVNode("h3", { class: "mt-3 text-lg font-semibold leading-6 text-black" }, [
                          createVNode("a", { href: "#" }, [
                            createVNode("span", { class: "absolute inset-0" }),
                            createTextVNode(" Boost your conversion rate ")
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Client/Media.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
