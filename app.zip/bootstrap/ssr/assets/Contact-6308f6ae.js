import { unref, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ClientLayout-b69b3b9c.js";
import "wow.js";
const _sfc_main = {
  __name: "Contact",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Contact Us" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-white py-20"${_scopeId}><div class="mx-auto max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl lg:mx-0"${_scopeId}><h2 data-wow-duration="1.5s" data-wow-delay="1s" class="wow animate__lightSpeedInLeft text-3xl font-bold tracking-tight text-primary"${_scopeId}>Get in touch, we are here to help</h2><p data-wow-duration="1.5s" data-wow-delay="1.5s" class="wow animate__lightSpeedInLeft mt-6 text-lg leading-8 text-black font-medium"${_scopeId}>Looking to start your food service business? Take the first step by contacting us today. Fill in the form below and let our expert team guide you towards achieving your dreams. Together, we&#39;ll bring your vision to life. Get started now!</p></div><div class="mt-12 flex justify-between divide-primary divide-x-4"${_scopeId}><a href="tel:+254717269050" data-wow-delay="1.5s" data-wow-duration="1.5s" class="wow animate__backInUp group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"${_scopeId}><div class="h-20 w-20 bg-white rounded group-hover:bg-primary"${_scopeId}><i class="fas fa-phone flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white"${_scopeId}></i></div><div class="ml-5"${_scopeId}><div class=""${_scopeId}><h1 class="font-bold text-2xl leading-10 text-primary"${_scopeId}>Phone Number</h1><h5 class="font-bold leading-10 text-2xl"${_scopeId}> +254 717 269 050</h5></div></div></a><a href="mailto:info@commercialkitchen.co.ke" data-wow-delay="2s" data-wow-duration="1.5s" class="wow animate__backInUp group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"${_scopeId}><div class="h-20 w-20 bg-white rounded group-hover:bg-primary"${_scopeId}><i class="fas fa-envelope flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white"${_scopeId}></i></div><div class="ml-5"${_scopeId}><div class=""${_scopeId}><h1 class="font-bold text-2xl leading-10 text-primary"${_scopeId}>Email Address</h1><h5 class="font-bold leading-10 text-xl"${_scopeId}> info@commercialkitchen.co.ke</h5></div></div></a><a href="https://www.google.com/maps/dir//commodore+suites/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x182f109ec56d4431:0xdee2bf2039412201?sa=X&amp;ved=2ahUKEwibpu2ftPeAAxULLsAKHY8IAK4Q9Rd6BAhSEAA&amp;ved=2ahUKEwibpu2ftPeAAxULLsAKHY8IAK4Q9Rd6BAhiEAM" target="_blank" data-wow-delay="2.5s" data-wow-duration="1.5s" class="wow animate__backInUp group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"${_scopeId}><div class="h-20 w-20 bg-white rounded group-hover:bg-primary"${_scopeId}><i class="fas fa-map-location-dot flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white"${_scopeId}></i></div><div class="ml-5"${_scopeId}><div class=""${_scopeId}><h1 class="font-bold text-2xl leading-10 text-primary"${_scopeId}>Physical Address</h1><h5 class="font-bold leading-10 text-xl"${_scopeId}> Kindaruma Rd, Nairobi</h5></div></div></a></div></div><div class="relative isolate bg-white px-6 py-24 sm:py-32 lg:px-8"${_scopeId}><div class="mx-auto max-w-7xl"${_scopeId}><h2 class="wow animate__rubberBand text-4xl font-bold tracking-tight text-primary"${_scopeId}>Let’s talk about your project</h2><p class="mt-2 text-lg leading-8 text-black font-medium"${_scopeId}>We help companies and individuals build out their dream.</p><div class="mt-16 flex flex-col gap-16 sm:gap-y-20 lg:flex-row"${_scopeId}><form action="#" method="POST" class="lg:flex-auto"${_scopeId}><div class="grid grid-cols-1 gap-x-8 gap-y-6 sm:grid-cols-2"${_scopeId}><div${_scopeId}><label for="first-name" class="block text-sm font-semibold leading-6 text-gray-900"${_scopeId}>First name</label><div class="mt-2.5"${_scopeId}><input type="text" name="first-name" id="first-name" autocomplete="given-name" class="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"${_scopeId}></div></div><div${_scopeId}><label for="last-name" class="block text-sm font-semibold leading-6 text-gray-900"${_scopeId}>Last name</label><div class="mt-2.5"${_scopeId}><input type="text" name="last-name" id="last-name" autocomplete="family-name" class="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"${_scopeId}></div></div><div${_scopeId}><label for="budget" class="block text-sm font-semibold leading-6 text-gray-900"${_scopeId}>Phone Number</label><div class="mt-2.5"${_scopeId}><input id="budget" name="budget" type="number" class="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"${_scopeId}></div></div><div${_scopeId}><label for="website" class="block text-sm font-semibold leading-6 text-gray-900"${_scopeId}>Email Address</label><div class="mt-2.5"${_scopeId}><input type="url" name="website" id="website" class="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"${_scopeId}></div></div><div class="sm:col-span-2"${_scopeId}><label for="message" class="block text-sm font-semibold leading-6 text-gray-900"${_scopeId}>Message</label><div class="mt-2.5"${_scopeId}><textarea id="message" name="message" rows="4" class="block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"${_scopeId}></textarea></div></div></div><div class="mt-10"${_scopeId}><button type="submit" class="group transform transition hover:scale-95 duration-700 ease-out block w-full rounded-md bg-primary hover:bg-black px-3.5 py-2.5 text-center text-sm font-semibold text-black hover:text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"${_scopeId}>Let’s talk <i class="fas fa-message-captions ml-2 hover:text-primary fa-xl"${_scopeId}></i></button></div></form><div class="lg:mt-6 lg:w-80 lg:flex-none"${_scopeId}><img data-wow-duration="1.5s" data-wow-delay="0.5s" class="wow animate__lightSpeedInRight h-20 w-auto" src="/android-chrome-192x192.png" alt=""${_scopeId}><figure class="mt-10"${_scopeId}><blockquote data-wow-duration="1.5s" data-wow-delay="1s" class="wow animate__lightSpeedInRight text-lg font-semibold leading-8 text-gray-900"${_scopeId}><p${_scopeId}>“Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo expedita voluptas culpa sapiente alias molestiae. Numquam corrupti in laborum sed rerum et corporis.” </p></blockquote><a href="https://linkedin.com/in/lynnkimeto" class="tranform transition hover: mt-10 flex gap-x-6"${_scopeId}><img src="https://media.licdn.com/dms/image/C4D03AQGn1tn6Yt-9tw/profile-displayphoto-shrink_400_400/0/1660966861926?e=1698278400&amp;v=beta&amp;t=Ic79gjIeWBpMVS-cSlHGidQ5ag1VWd33wP2HPQi38fo" alt="" data-wow-duration="1.5s" data-wow-delay="1s" class="wow animate__lightSpeedInRight h-20 w-20 flex-none rounded-full bg-gray-50"${_scopeId}><div${_scopeId}><div data-wow-duration="1.5s" data-wow-delay="2s" class="wow animate__lightSpeedInRight text-base font-semibold text-gray-900"${_scopeId}>Lynn Kimeto</div><div data-wow-duration="1.5s" data-wow-delay="2.5s" class="wow animate__lightSpeedInRight text-sm leading-6 text-gray-600 font-medium"${_scopeId}>Managing Director</div></div></a></figure></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-white py-20" }, [
                createVNode("div", { class: "mx-auto max-w-7xl px-6 lg:px-8" }, [
                  createVNode("div", { class: "mx-auto max-w-2xl lg:mx-0" }, [
                    createVNode("h2", {
                      "data-wow-duration": "1.5s",
                      "data-wow-delay": "1s",
                      class: "wow animate__lightSpeedInLeft text-3xl font-bold tracking-tight text-primary"
                    }, "Get in touch, we are here to help"),
                    createVNode("p", {
                      "data-wow-duration": "1.5s",
                      "data-wow-delay": "1.5s",
                      class: "wow animate__lightSpeedInLeft mt-6 text-lg leading-8 text-black font-medium"
                    }, "Looking to start your food service business? Take the first step by contacting us today. Fill in the form below and let our expert team guide you towards achieving your dreams. Together, we'll bring your vision to life. Get started now!")
                  ]),
                  createVNode("div", { class: "mt-12 flex justify-between divide-primary divide-x-4" }, [
                    createVNode("a", {
                      href: "tel:+254717269050",
                      "data-wow-delay": "1.5s",
                      "data-wow-duration": "1.5s",
                      class: "wow animate__backInUp group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"
                    }, [
                      createVNode("div", { class: "h-20 w-20 bg-white rounded group-hover:bg-primary" }, [
                        createVNode("i", { class: "fas fa-phone flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white" })
                      ]),
                      createVNode("div", { class: "ml-5" }, [
                        createVNode("div", { class: "" }, [
                          createVNode("h1", { class: "font-bold text-2xl leading-10 text-primary" }, "Phone Number"),
                          createVNode("h5", { class: "font-bold leading-10 text-2xl" }, " +254 717 269 050")
                        ])
                      ])
                    ]),
                    createVNode("a", {
                      href: "mailto:info@commercialkitchen.co.ke",
                      "data-wow-delay": "2s",
                      "data-wow-duration": "1.5s",
                      class: "wow animate__backInUp group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"
                    }, [
                      createVNode("div", { class: "h-20 w-20 bg-white rounded group-hover:bg-primary" }, [
                        createVNode("i", { class: "fas fa-envelope flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white" })
                      ]),
                      createVNode("div", { class: "ml-5" }, [
                        createVNode("div", { class: "" }, [
                          createVNode("h1", { class: "font-bold text-2xl leading-10 text-primary" }, "Email Address"),
                          createVNode("h5", { class: "font-bold leading-10 text-xl" }, " info@commercialkitchen.co.ke")
                        ])
                      ])
                    ]),
                    createVNode("a", {
                      href: "https://www.google.com/maps/dir//commodore+suites/data=!4m6!4m5!1m1!4e2!1m2!1m1!1s0x182f109ec56d4431:0xdee2bf2039412201?sa=X&ved=2ahUKEwibpu2ftPeAAxULLsAKHY8IAK4Q9Rd6BAhSEAA&ved=2ahUKEwibpu2ftPeAAxULLsAKHY8IAK4Q9Rd6BAhiEAM",
                      target: "_blank",
                      "data-wow-delay": "2.5s",
                      "data-wow-duration": "1.5s",
                      class: "wow animate__backInUp group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"
                    }, [
                      createVNode("div", { class: "h-20 w-20 bg-white rounded group-hover:bg-primary" }, [
                        createVNode("i", { class: "fas fa-map-location-dot flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white" })
                      ]),
                      createVNode("div", { class: "ml-5" }, [
                        createVNode("div", { class: "" }, [
                          createVNode("h1", { class: "font-bold text-2xl leading-10 text-primary" }, "Physical Address"),
                          createVNode("h5", { class: "font-bold leading-10 text-xl" }, " Kindaruma Rd, Nairobi")
                        ])
                      ])
                    ])
                  ])
                ]),
                createVNode("div", { class: "relative isolate bg-white px-6 py-24 sm:py-32 lg:px-8" }, [
                  createVNode("div", { class: "mx-auto max-w-7xl" }, [
                    createVNode("h2", { class: "wow animate__rubberBand text-4xl font-bold tracking-tight text-primary" }, "Let’s talk about your project"),
                    createVNode("p", { class: "mt-2 text-lg leading-8 text-black font-medium" }, "We help companies and individuals build out their dream."),
                    createVNode("div", { class: "mt-16 flex flex-col gap-16 sm:gap-y-20 lg:flex-row" }, [
                      createVNode("form", {
                        action: "#",
                        method: "POST",
                        class: "lg:flex-auto"
                      }, [
                        createVNode("div", { class: "grid grid-cols-1 gap-x-8 gap-y-6 sm:grid-cols-2" }, [
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "first-name",
                              class: "block text-sm font-semibold leading-6 text-gray-900"
                            }, "First name"),
                            createVNode("div", { class: "mt-2.5" }, [
                              createVNode("input", {
                                type: "text",
                                name: "first-name",
                                id: "first-name",
                                autocomplete: "given-name",
                                class: "block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"
                              })
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "last-name",
                              class: "block text-sm font-semibold leading-6 text-gray-900"
                            }, "Last name"),
                            createVNode("div", { class: "mt-2.5" }, [
                              createVNode("input", {
                                type: "text",
                                name: "last-name",
                                id: "last-name",
                                autocomplete: "family-name",
                                class: "block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"
                              })
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "budget",
                              class: "block text-sm font-semibold leading-6 text-gray-900"
                            }, "Phone Number"),
                            createVNode("div", { class: "mt-2.5" }, [
                              createVNode("input", {
                                id: "budget",
                                name: "budget",
                                type: "number",
                                class: "block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"
                              })
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "website",
                              class: "block text-sm font-semibold leading-6 text-gray-900"
                            }, "Email Address"),
                            createVNode("div", { class: "mt-2.5" }, [
                              createVNode("input", {
                                type: "url",
                                name: "website",
                                id: "website",
                                class: "block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"
                              })
                            ])
                          ]),
                          createVNode("div", { class: "sm:col-span-2" }, [
                            createVNode("label", {
                              for: "message",
                              class: "block text-sm font-semibold leading-6 text-gray-900"
                            }, "Message"),
                            createVNode("div", { class: "mt-2.5" }, [
                              createVNode("textarea", {
                                id: "message",
                                name: "message",
                                rows: "4",
                                class: "block w-full rounded-md border-0 px-3.5 py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"
                              })
                            ])
                          ])
                        ]),
                        createVNode("div", { class: "mt-10" }, [
                          createVNode("button", {
                            type: "submit",
                            class: "group transform transition hover:scale-95 duration-700 ease-out block w-full rounded-md bg-primary hover:bg-black px-3.5 py-2.5 text-center text-sm font-semibold text-black hover:text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                          }, [
                            createTextVNode("Let’s talk "),
                            createVNode("i", { class: "fas fa-message-captions ml-2 hover:text-primary fa-xl" })
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "lg:mt-6 lg:w-80 lg:flex-none" }, [
                        createVNode("img", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "0.5s",
                          class: "wow animate__lightSpeedInRight h-20 w-auto",
                          src: "/android-chrome-192x192.png",
                          alt: ""
                        }),
                        createVNode("figure", { class: "mt-10" }, [
                          createVNode("blockquote", {
                            "data-wow-duration": "1.5s",
                            "data-wow-delay": "1s",
                            class: "wow animate__lightSpeedInRight text-lg font-semibold leading-8 text-gray-900"
                          }, [
                            createVNode("p", null, "“Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo expedita voluptas culpa sapiente alias molestiae. Numquam corrupti in laborum sed rerum et corporis.” ")
                          ]),
                          createVNode("a", {
                            href: "https://linkedin.com/in/lynnkimeto",
                            class: "tranform transition hover: mt-10 flex gap-x-6"
                          }, [
                            createVNode("img", {
                              src: "https://media.licdn.com/dms/image/C4D03AQGn1tn6Yt-9tw/profile-displayphoto-shrink_400_400/0/1660966861926?e=1698278400&v=beta&t=Ic79gjIeWBpMVS-cSlHGidQ5ag1VWd33wP2HPQi38fo",
                              alt: "",
                              "data-wow-duration": "1.5s",
                              "data-wow-delay": "1s",
                              class: "wow animate__lightSpeedInRight h-20 w-20 flex-none rounded-full bg-gray-50"
                            }),
                            createVNode("div", null, [
                              createVNode("div", {
                                "data-wow-duration": "1.5s",
                                "data-wow-delay": "2s",
                                class: "wow animate__lightSpeedInRight text-base font-semibold text-gray-900"
                              }, "Lynn Kimeto"),
                              createVNode("div", {
                                "data-wow-duration": "1.5s",
                                "data-wow-delay": "2.5s",
                                class: "wow animate__lightSpeedInRight text-sm leading-6 text-gray-600 font-medium"
                              }, "Managing Director")
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Client/Contact.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
