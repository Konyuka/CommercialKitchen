import { ref, withCtx, unref, mergeProps, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderStyle, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ClientLayout-e3ead9de.js";
import { Carousel, Slide } from "vue3-carousel";
/* empty css                   */import "wow.js";
const _sfc_main = {
  __name: "About",
  __ssrInlineRender: true,
  setup(__props) {
    const settings = ref({
      itemsToShow: 1,
      snapAlign: "center"
    });
    const breakpoints = ref({
      // 700px and up
      700: {
        itemsToShow: 3.5,
        snapAlign: "center"
      },
      // 1024 and up
      1024: {
        itemsToShow: 4,
        snapAlign: "start"
      }
    });
    const clients = ref([
      {
        name: "Mpesa Foundation",
        image: "/img/mpesa.png"
      },
      {
        name: "Acacia Residence",
        image: "/img/ac.jpg"
      },
      {
        name: "Nostro Pizza",
        image: "/img/nostro.jpg"
      },
      {
        name: "Icon Gardens",
        image: "/img/icon.jpg"
      },
      {
        name: "Dohn Bistro",
        image: "/img/db.jpg"
      },
      {
        name: "Golden Stool",
        image: "/img/golden.svg"
      },
      {
        name: "Adrian Kenya",
        image: "/img/adrian.jfif"
      },
      {
        name: "Nandi's Kitchen",
        image: "/img/nandi.jpg"
      },
      {
        name: "Saffron Grill",
        image: "/img/safron.png"
      },
      {
        name: "Limpopo Suites",
        image: "/img/limp.png"
      },
      {
        name: "Tangaza University",
        image: "/img/tang.png"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Head), { title: "Our Story" }, null, _parent2, _scopeId));
            _push2(`<div class="bg-white"${_scopeId}><main class="relative isolate"${_scopeId}><div class="absolute inset-x-0 top-4 -z-10 flex transform-gpu justify-center overflow-hidden blur-3xl" aria-hidden="true"${_scopeId}><div class="aspect-[1108/632] w-[69.25rem] flex-none bg-gradient-to-r from-[#000] to-primary opacity-25" style="${ssrRenderStyle({ "clip-path": "polygon(73.6% 51.7%, 91.7% 11.8%, 100% 46.4%, 97.4% 82.2%, 92.5% 84.9%, 75.7% 64%, 55.3% 47.5%, 46.5% 49.4%, 45% 62.9%, 50.3% 87.2%, 21.3% 64.1%, 0.1% 100%, 5.4% 51.1%, 21.4% 63.9%, 58.9% 0.2%, 73.6% 51.7%)" })}"${_scopeId}></div></div><div class="px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl pt-10 sm:pt-20 text-center"${_scopeId}><h2 class="wow animate__rubberBand text-4xl font-bold tracking-tight text-primary sm:text-6xl"${_scopeId}>Who We Are</h2></div></div><div class="mx-auto mt-10 sm:mt-20 max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl lg:mx-0 lg:max-w-none"${_scopeId}><div class="grid max-w-xl grid-cols-1 gap-8 text-sm sm:text-base leading-6 sm:leading-10 text-black font-semibold lg:max-w-none lg:grid-cols-1"${_scopeId}><div data-wow-duration="1.5s" data-wow-delay="2s" class="wow animate__lightSpeedInLeft"${_scopeId}><p${_scopeId}> We are a team of passionate professionals who share a common vision: to revolutionize the commercial kitchen experience. Our journey began with a collective drive to address the challenges faced by clients when setting up their dream culinary spaces. <br${_scopeId}> <br${_scopeId}> Drawing from our diverse backgrounds in the hospitality industry, we recognized that many clients, especially first-time purchasers, lacked the knowledge and guidance required to navigate the complexities of commercial kitchen design and equipment selection. We were determined to make a difference. <br${_scopeId}> <br${_scopeId}></p><p${_scopeId}> Together, we formed Commercial Kitchens Consultants with a singular mission: to empower our clients and ensure a seamless journey in creating their ideal commercial kitchens. We believe that no client should endure the frustration of unmet timelines or fall prey to suppliers who prioritize their own interests. <br${_scopeId}> <br${_scopeId}> Our team is committed to providing expert guidance and support throughout every step of the process. From designing innovative kitchen layouts to selecting the perfect equipment from trusted suppliers, we leverage our industry expertise and rigorous supplier qualification process to ensure that our clients make informed decisions that align with their needs and budgets. <br${_scopeId}><br${_scopeId}> With a meticulous approach to procurement and project management, we orchestrate the entire process, sparing our clients the stress of constant supervision. Our goal is to deliver on time and exceed expectations, leaving our clients with a kitchen that is fully functional, aesthetically pleasing, and optimized for productivity. <br${_scopeId}> <br${_scopeId}> Join us on this exciting journey as we redefine culinary spaces and elevate the dining experience for your guests. Together, let&#39;s create exceptional culinary spaces that inspire, captivate, and drive success. <br${_scopeId}><br${_scopeId}> Welcome to Commercial Kitchens Consultants, where we elevate culinary spaces, together. </p></div></div><dl class="mt-16 grid grid-cols-1 gap-x-8 gap-y-5 sm:mt-20 sm:grid-cols-2 sm:gap-y-16 lg:mt-28 lg:grid-cols-4"${_scopeId}><div data-wow-duration="1.5s" data-wow-delay="" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>Business was founded</dt><dd class="text-3xl font-semibold tracking-tight text-primary"${_scopeId}>2021</dd></div><div data-wow-duration="1.5s" data-wow-delay="0.5" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>People on the team</dt><dd class="text-3xl font-semibold tracking-tight text-primary"${_scopeId}>7+</dd></div><div data-wow-duration="1.5s" data-wow-delay="1.5s" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>Projects completed</dt><dd class="text-3xl font-semibold tracking-tight text-primary"${_scopeId}>20+</dd></div><div data-wow-duration="1.5s" data-wow-delay="1s" class="wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"${_scopeId}><dt class="text-base leading-7 text-black font-bold"${_scopeId}>Happy clients</dt><dd class="text-3xl font-semibold tracking-tight text-primary"${_scopeId}>18+</dd></div></dl></div></div><div class="mx-2 rounded-lg mt-16 sm:mt-40 xl:mx-auto xl:max-w-7xl xl:px-8"${_scopeId}><img src="/img/fist.jpg" alt="" class="aspect-[9/9] sm:aspect-[9/4] w-full object-cover xl:rounded-3xl"${_scopeId}></div><div class="mx-auto mt-16 max-w-7xl px-6 sm:mt-40 lg:px-8"${_scopeId}><div class="mx-auto max-w-7xl lg:mx-0 text-center"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-primary sm:text-4xl"${_scopeId}>Our values</h2><p class="mt-6 text-md sm:text-lg leading-6 sm:leading-8 text-black font-semibold text-center sm:px-28"${_scopeId}>At Commercial Kitchens Consultants, our values guide our every action, decision, and interaction. They are the foundation upon which we build trust, deliver excellence, and achieve success for our clients. </p></div><dl class="sm:mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-10 text-base leading-7 text-gray-300 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:gap-x-16"${_scopeId}><div class="relative sm:pl-9"${_scopeId}><dt class="inline font-semibold text-primary"${_scopeId}><i class="fa-sharp fa-light fa-user-chef fa-2x mb-5"${_scopeId}></i> Expertise <br${_scopeId}></dt><dd class="text-sm sm:text-md inline font-semibold"${_scopeId}>We are committed to staying at the forefront of the commercial kitchen industry, continuously expanding our knowledge and expertise to provide the best solutions for our clients.</dd></div><div class="relative sm:pl-9"${_scopeId}><dt class="inline font-semibold text-primary"${_scopeId}><i class="fa-regular fa-gavel fa-2x mb-5"${_scopeId}></i> Integrity <br${_scopeId}></dt><dd class="text-sm sm:text-md inline font-semibold"${_scopeId}> We uphold the highest ethical standards, ensuring transparency, honesty, and fairness in all our dealings. </dd></div><div class="relative sm:pl-9"${_scopeId}><dt class="inline font-semibold text-primary"${_scopeId}><i class="fa-sharp fa-solid fa-user-tie fa-2x mb-5"${_scopeId}></i> Client-Centric <br${_scopeId}></dt><dd class="text-sm sm:text-md inline font-semibold"${_scopeId}> Our clients are at the heart of everything we do. We listen, understand, and prioritize their unique needs to deliver tailored solutions. </dd></div><div class="relative sm:pl-9"${_scopeId}><dt class="inline font-semibold text-primary"${_scopeId}><i class="fa-sharp fa-regular fa-business-time fa-2x mb-5"${_scopeId}></i> Reliability <br${_scopeId}></dt><dd class="text-sm sm:text-md inline font-semibold"${_scopeId}>We are unwavering in our commitment to meeting deadlines, delivering on promises, and providing dependable services.</dd></div><div class="relative sm:pl-9"${_scopeId}><dt class="inline font-semibold text-primary"${_scopeId}><i class="fa-sharp fa-solid fa-thumbs-up fa-2x mb-5"${_scopeId}></i> Quality <br${_scopeId}></dt><dd class="text-sm sm:text-md inline font-semibold"${_scopeId}>We hold ourselves to the highest standards of quality, ensuring that every project we undertake reflects our dedication to excellence.</dd></div><div class="relative sm:pl-9"${_scopeId}><dt class="inline font-semibold text-primary"${_scopeId}><i class="fa-solid fa-gears fa-2x mb-5"${_scopeId}></i> Innovation <br${_scopeId}></dt><dd class="text-sm sm:text-md inline font-semibold"${_scopeId}>We embrace innovation and creativity to find unique solutions that drive efficiency and exceed expectations.</dd></div></dl></div><div class="mx-auto mt-32 max-w-7xl px-6 sm:mt-40 lg:px-8"${_scopeId}><div class="mx-auto max-w-7xl lg:mx-0 text-center mb-10"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-white sm:text-4xl"${_scopeId}>Our Clients</h2><p class="mt-6 text-lg leading-8 text-black font-bold"${_scopeId}>Who we&#39;ve worked with</p></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Carousel), mergeProps({
              autoplay: 2e3,
              "wrap-around": true
            }, settings.value, { breakpoints: breakpoints.value }), {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(clients.value, (client, index) => {
                    _push3(ssrRenderComponent(unref(Slide), { key: index }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<li class="mr-5"${_scopeId3}><img class="carousel__item aspect-[14/13] w-full rounded-2xl object-cover"${ssrRenderAttr("src", client.image)} alt=""${_scopeId3}><h3 class="mb-20 mt-6 text-lg font-semibold leading-8 tracking-tight text-white"${_scopeId3}>${ssrInterpolate(client.name)}</h3></li>`);
                        } else {
                          return [
                            createVNode("li", { class: "mr-5" }, [
                              createVNode("img", {
                                class: "carousel__item aspect-[14/13] w-full rounded-2xl object-cover",
                                src: client.image,
                                alt: ""
                              }, null, 8, ["src"]),
                              createVNode("h3", { class: "mb-20 mt-6 text-lg font-semibold leading-8 tracking-tight text-white" }, toDisplayString(client.name), 1)
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(clients.value, (client, index) => {
                      return openBlock(), createBlock(unref(Slide), { key: index }, {
                        default: withCtx(() => [
                          createVNode("li", { class: "mr-5" }, [
                            createVNode("img", {
                              class: "carousel__item aspect-[14/13] w-full rounded-2xl object-cover",
                              src: client.image,
                              alt: ""
                            }, null, 8, ["src"]),
                            createVNode("h3", { class: "mb-20 mt-6 text-lg font-semibold leading-8 tracking-tight text-white" }, toDisplayString(client.name), 1)
                          ])
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></main><div${_scopeId}></div></div>`);
          } else {
            return [
              createVNode(unref(Head), { title: "Our Story" }),
              createVNode("div", { class: "bg-white" }, [
                createVNode("main", { class: "relative isolate" }, [
                  createVNode("div", {
                    class: "absolute inset-x-0 top-4 -z-10 flex transform-gpu justify-center overflow-hidden blur-3xl",
                    "aria-hidden": "true"
                  }, [
                    createVNode("div", {
                      class: "aspect-[1108/632] w-[69.25rem] flex-none bg-gradient-to-r from-[#000] to-primary opacity-25",
                      style: { "clip-path": "polygon(73.6% 51.7%, 91.7% 11.8%, 100% 46.4%, 97.4% 82.2%, 92.5% 84.9%, 75.7% 64%, 55.3% 47.5%, 46.5% 49.4%, 45% 62.9%, 50.3% 87.2%, 21.3% 64.1%, 0.1% 100%, 5.4% 51.1%, 21.4% 63.9%, 58.9% 0.2%, 73.6% 51.7%)" }
                    })
                  ]),
                  createVNode("div", { class: "px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl pt-10 sm:pt-20 text-center" }, [
                      createVNode("h2", { class: "wow animate__rubberBand text-4xl font-bold tracking-tight text-primary sm:text-6xl" }, "Who We Are")
                    ])
                  ]),
                  createVNode("div", { class: "mx-auto mt-10 sm:mt-20 max-w-7xl px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl lg:mx-0 lg:max-w-none" }, [
                      createVNode("div", { class: "grid max-w-xl grid-cols-1 gap-8 text-sm sm:text-base leading-6 sm:leading-10 text-black font-semibold lg:max-w-none lg:grid-cols-1" }, [
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "2s",
                          class: "wow animate__lightSpeedInLeft"
                        }, [
                          createVNode("p", null, [
                            createTextVNode(" We are a team of passionate professionals who share a common vision: to revolutionize the commercial kitchen experience. Our journey began with a collective drive to address the challenges faced by clients when setting up their dream culinary spaces. "),
                            createVNode("br"),
                            createTextVNode(),
                            createVNode("br"),
                            createTextVNode(" Drawing from our diverse backgrounds in the hospitality industry, we recognized that many clients, especially first-time purchasers, lacked the knowledge and guidance required to navigate the complexities of commercial kitchen design and equipment selection. We were determined to make a difference. "),
                            createVNode("br"),
                            createTextVNode(),
                            createVNode("br")
                          ]),
                          createVNode("p", null, [
                            createTextVNode(" Together, we formed Commercial Kitchens Consultants with a singular mission: to empower our clients and ensure a seamless journey in creating their ideal commercial kitchens. We believe that no client should endure the frustration of unmet timelines or fall prey to suppliers who prioritize their own interests. "),
                            createVNode("br"),
                            createTextVNode(),
                            createVNode("br"),
                            createTextVNode(" Our team is committed to providing expert guidance and support throughout every step of the process. From designing innovative kitchen layouts to selecting the perfect equipment from trusted suppliers, we leverage our industry expertise and rigorous supplier qualification process to ensure that our clients make informed decisions that align with their needs and budgets. "),
                            createVNode("br"),
                            createVNode("br"),
                            createTextVNode(" With a meticulous approach to procurement and project management, we orchestrate the entire process, sparing our clients the stress of constant supervision. Our goal is to deliver on time and exceed expectations, leaving our clients with a kitchen that is fully functional, aesthetically pleasing, and optimized for productivity. "),
                            createVNode("br"),
                            createTextVNode(),
                            createVNode("br"),
                            createTextVNode(" Join us on this exciting journey as we redefine culinary spaces and elevate the dining experience for your guests. Together, let's create exceptional culinary spaces that inspire, captivate, and drive success. "),
                            createVNode("br"),
                            createVNode("br"),
                            createTextVNode(" Welcome to Commercial Kitchens Consultants, where we elevate culinary spaces, together. ")
                          ])
                        ])
                      ]),
                      createVNode("dl", { class: "mt-16 grid grid-cols-1 gap-x-8 gap-y-5 sm:mt-20 sm:grid-cols-2 sm:gap-y-16 lg:mt-28 lg:grid-cols-4" }, [
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "Business was founded"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-primary" }, "2021")
                        ]),
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "0.5",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "People on the team"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-primary" }, "7+")
                        ]),
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "1.5s",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "Projects completed"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-primary" }, "20+")
                        ]),
                        createVNode("div", {
                          "data-wow-duration": "1.5s",
                          "data-wow-delay": "1s",
                          class: "wow animate__backInUp flex flex-col-reverse gap-y-3 border-l border-white/20 pl-6"
                        }, [
                          createVNode("dt", { class: "text-base leading-7 text-black font-bold" }, "Happy clients"),
                          createVNode("dd", { class: "text-3xl font-semibold tracking-tight text-primary" }, "18+")
                        ])
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "mx-2 rounded-lg mt-16 sm:mt-40 xl:mx-auto xl:max-w-7xl xl:px-8" }, [
                    createVNode("img", {
                      src: "/img/fist.jpg",
                      alt: "",
                      class: "aspect-[9/9] sm:aspect-[9/4] w-full object-cover xl:rounded-3xl"
                    })
                  ]),
                  createVNode("div", { class: "mx-auto mt-16 max-w-7xl px-6 sm:mt-40 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-7xl lg:mx-0 text-center" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-primary sm:text-4xl" }, "Our values"),
                      createVNode("p", { class: "mt-6 text-md sm:text-lg leading-6 sm:leading-8 text-black font-semibold text-center sm:px-28" }, "At Commercial Kitchens Consultants, our values guide our every action, decision, and interaction. They are the foundation upon which we build trust, deliver excellence, and achieve success for our clients. ")
                    ]),
                    createVNode("dl", { class: "sm:mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-10 text-base leading-7 text-gray-300 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:gap-x-16" }, [
                      createVNode("div", { class: "relative sm:pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-primary" }, [
                          createVNode("i", { class: "fa-sharp fa-light fa-user-chef fa-2x mb-5" }),
                          createTextVNode(" Expertise "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "text-sm sm:text-md inline font-semibold" }, "We are committed to staying at the forefront of the commercial kitchen industry, continuously expanding our knowledge and expertise to provide the best solutions for our clients.")
                      ]),
                      createVNode("div", { class: "relative sm:pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-primary" }, [
                          createVNode("i", { class: "fa-regular fa-gavel fa-2x mb-5" }),
                          createTextVNode(" Integrity "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "text-sm sm:text-md inline font-semibold" }, " We uphold the highest ethical standards, ensuring transparency, honesty, and fairness in all our dealings. ")
                      ]),
                      createVNode("div", { class: "relative sm:pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-primary" }, [
                          createVNode("i", { class: "fa-sharp fa-solid fa-user-tie fa-2x mb-5" }),
                          createTextVNode(" Client-Centric "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "text-sm sm:text-md inline font-semibold" }, " Our clients are at the heart of everything we do. We listen, understand, and prioritize their unique needs to deliver tailored solutions. ")
                      ]),
                      createVNode("div", { class: "relative sm:pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-primary" }, [
                          createVNode("i", { class: "fa-sharp fa-regular fa-business-time fa-2x mb-5" }),
                          createTextVNode(" Reliability "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "text-sm sm:text-md inline font-semibold" }, "We are unwavering in our commitment to meeting deadlines, delivering on promises, and providing dependable services.")
                      ]),
                      createVNode("div", { class: "relative sm:pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-primary" }, [
                          createVNode("i", { class: "fa-sharp fa-solid fa-thumbs-up fa-2x mb-5" }),
                          createTextVNode(" Quality "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "text-sm sm:text-md inline font-semibold" }, "We hold ourselves to the highest standards of quality, ensuring that every project we undertake reflects our dedication to excellence.")
                      ]),
                      createVNode("div", { class: "relative sm:pl-9" }, [
                        createVNode("dt", { class: "inline font-semibold text-primary" }, [
                          createVNode("i", { class: "fa-solid fa-gears fa-2x mb-5" }),
                          createTextVNode(" Innovation "),
                          createVNode("br")
                        ]),
                        createVNode("dd", { class: "text-sm sm:text-md inline font-semibold" }, "We embrace innovation and creativity to find unique solutions that drive efficiency and exceed expectations.")
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "mx-auto mt-32 max-w-7xl px-6 sm:mt-40 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-7xl lg:mx-0 text-center mb-10" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-white sm:text-4xl" }, "Our Clients"),
                      createVNode("p", { class: "mt-6 text-lg leading-8 text-black font-bold" }, "Who we've worked with")
                    ]),
                    createVNode("div", null, [
                      createVNode(unref(Carousel), mergeProps({
                        autoplay: 2e3,
                        "wrap-around": true
                      }, settings.value, { breakpoints: breakpoints.value }), {
                        default: withCtx(() => [
                          (openBlock(true), createBlock(Fragment, null, renderList(clients.value, (client, index) => {
                            return openBlock(), createBlock(unref(Slide), { key: index }, {
                              default: withCtx(() => [
                                createVNode("li", { class: "mr-5" }, [
                                  createVNode("img", {
                                    class: "carousel__item aspect-[14/13] w-full rounded-2xl object-cover",
                                    src: client.image,
                                    alt: ""
                                  }, null, 8, ["src"]),
                                  createVNode("h3", { class: "mb-20 mt-6 text-lg font-semibold leading-8 tracking-tight text-white" }, toDisplayString(client.name), 1)
                                ])
                              ]),
                              _: 2
                            }, 1024);
                          }), 128))
                        ]),
                        _: 1
                      }, 16, ["breakpoints"])
                    ])
                  ])
                ]),
                createVNode("div")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Client/About.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
