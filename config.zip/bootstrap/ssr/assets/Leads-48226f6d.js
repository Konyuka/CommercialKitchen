import { ref, useSSRContext, computed, resolveComponent, unref, withCtx, createTextVNode, onMounted, createVNode, openBlock, createBlock, createCommentVNode, Fragment, renderList, toDisplayString, withDirectives, vModelText, vModelSelect } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$3 } from "./AdminLayout-86ff2b34.js";
import { useForm, router } from "@inertiajs/vue3";
import VueDatePicker from "@vuepic/vue-datepicker";
import moment from "moment";
import axios from "axios";
const _sfc_main$2 = {
  __name: "ImportLeadsModal",
  __ssrInlineRender: true,
  emits: [
    "close"
  ],
  setup(__props, { emit }) {
    ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true"><div class="fixed inset-0 bg-black bg-opacity-75 transition-opacity"></div><div class="fixed inset-0 z-10 w-screen overflow-y-auto"><div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0"><div class="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6"><div><div class="mt-2 text-center sm:mt-5"><div class="mt-3"><div class="space-y-12"><div class="border-b border-gray-900/10 pb-12"><div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6"><div class="col-span-full"><label for="cover-photo" class="block text-sm font-semibold leading-6 text-black"> Upload Lead File </label><div class="mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10"><div class="text-center"><i></i><div class="mt-4 flex text-sm leading-6 text-gray-600"><label for="file-upload" class="relative cursor-pointer rounded-md bg-white font-semibold text-primary-100 focus-within:outline-none focus-within:ring-2 focus-within:ring-primary-200 focus-within:ring-offset-2 hover:text-primary-200"><input id="file-upload" name="file-upload" type="file" class="item-center ring-1 ring-primary"></label></div></div></div></div></div></div></div></div></div></div><div class="mt-5 sm:mt-6 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:gap-3"><button type="button" class="inline-flex w-full justify-center rounded-md bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 sm:col-start-2"> Lead thy way... </button><button type="button" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-black hover:text-white shadow-sm ring-1 ring-inset ring-black hover:bg-black sm:col-start-1 sm:mt-0"> Cancel </button></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Admin/ImportLeadsModal.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const main = "";
const _sfc_main$1 = {
  __name: "ConvoSlide",
  __ssrInlineRender: true,
  props: {
    leadData: Object
  },
  emits: [
    "close"
  ],
  setup(__props, { emit }) {
    const props = __props;
    const parsedMessage = computed(() => {
      return JSON.parse(props.leadData.notes);
    });
    const convo = useForm({
      notes: {
        message: null,
        logged_at: Date.now()
      },
      call_date: null
    });
    const formatDate = (date) => {
      return moment(date).format("llll");
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_P = resolveComponent("P");
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="relative z-10" aria-labelledby="slide-over-title" role="dialog" aria-modal="true"><div class="fixed inset-0"></div><div class="fixed inset-0 overflow-hidden"><div class="absolute inset-0 overflow-hidden"><div class="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10 sm:pl-16"><div class="pointer-events-auto w-screen max-w-2xl"><form class="flex h-full flex-col overflow-y-auto bg-black shadow-xl"><div class="flex-1"><div class="bg-gray-50 px-4 py-6 sm:px-6"><div class="flex items-start justify-between space-x-3"><div class="space-y-1"><h2 class="text-base font-semibold leading-6 text-white" id="slide-over-title">Lead Conversation</h2><p class="text-sm text-white">This is were you log your conversation with client.</p></div><div class="flex h-7 items-center"><button type="button" class="relative text-white hover:text-white"><span class="absolute -inset-2.5"></span><span class="sr-only">Close panel</span><svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path></svg></button></div></div></div><div class="space-y-6 py-6 sm:space-y-0 sm:divide-y sm:divide-gray-200 sm:py-0"><div class="space-y-2 px-4 sm:grid sm:grid-cols-4 sm:gap-4 sm:space-y-0 sm:px-6 sm:py-5"><div><label for="project-description" class="block text-sm font-medium leading-6 text-white sm:mt-1.5">New notes</label></div><div class="relative sm:col-span-3"><textarea id="project-description" name="project-description" rows="3" class="block w-full border-0 py-1.5 text-black font-semibold italic shadow-sm ring-1 ring-inset ring-black placeholder:text-white focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6">${ssrInterpolate(unref(convo).notes.message)}</textarea></div></div><div class="space-y-2 px-4 sm:grid sm:grid-cols-4 sm:gap-4 sm:space-y-0 sm:px-6 sm:pb-5"><div></div><div class="sm:col-span-3"><label for="project-name" class="mb-2 block text-sm font-medium leading-6 text-white sm:mt-1.5"> Next Call Date </label>`);
      _push(ssrRenderComponent(unref(VueDatePicker), {
        modelValue: unref(convo).call_date,
        "onUpdate:modelValue": ($event) => unref(convo).call_date = $event
      }, null, _parent));
      _push(`<div><button type="button" class="right-7 mt-9 rounded bg-white px-3 py-2 text-sm font-semibold text-black shadow-sm ring-1 ring-inset ring-black hover:bg-primary"> Save Update </button></div></div></div><div class="bg-white h-full overflow-y-scroll"><div class="mx-auto max-w-7xl divide-y divide-gray-900/10 px-6 py-6"><h2 class="text-xl font-bold leading-10 tracking-tight text-gray-900"> Previous Notes</h2>`);
      if (__props.leadData.notes != null) {
        _push(`<dl class="space-y-2 divide-y divide-gray-900/10"><!--[-->`);
        ssrRenderList(parsedMessage.value, (message) => {
          _push(`<div class="pt-2 lg:grid lg:grid-cols-12 lg:gap-4"><dt class="text-sm font-semibold leading-7 text-gray-900 lg:col-span-5">${ssrInterpolate(formatDate(message == null ? void 0 : message.logged_at))}</dt><dd class="mt-4 lg:col-span-7 lg:mt-0"><p class="text-xs leading-7 text-black">${ssrInterpolate(message == null ? void 0 : message.message)}</p></dd></div>`);
        });
        _push(`<!--]--></dl>`);
      } else {
        _push(`<div class="h-full w-full flex justify-around">`);
        _push(ssrRenderComponent(_component_P, { class: "my-28 font-semibold" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`There are no notes for this lead`);
            } else {
              return [
                createTextVNode("There are no notes for this lead")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</div></div></div></div></form></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Admin/ConvoSlide.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Leads",
  __ssrInlineRender: true,
  setup(__props) {
    onMounted(() => {
      getLeads();
    });
    const leadModal = ref(false);
    const showConvos = ref(false);
    const leads = ref([]);
    const leadData = ref({
      id: null,
      notes: null
    });
    const dynamicInputs = ref([]);
    const statuses = [
      { id: 0, name: "Unrated" },
      { id: 1, name: "Negotiations" },
      { id: 2, name: "Willing" },
      { id: 3, name: "Almost" },
      { id: 4, name: "Ready" },
      { id: 5, name: "Closed" }
    ];
    const getLeads = () => {
      axios.get("/api/get-leads").then((res) => {
        leads.value = res.data;
        leads.value.forEach((element) => {
          const leadObject = {
            how_soon: element.how_soon,
            probability: element.probability == null ? 0 : element.probability,
            location: element.location == null ? null : element.location
          };
          dynamicInputs.value.push(leadObject);
        });
      }).catch((err) => {
        console.log(err);
      });
    };
    const closeLeadModal = () => {
      leadModal.value = false;
      getLeads();
    };
    const formatPhoneNumber = (number) => {
      const phoneNumber = number.substring(2);
      let formattedPhoneNumber = phoneNumber.substr(0, 4) + " " + phoneNumber.substr(4, 3) + " " + phoneNumber.substr(7, 3) + " " + phoneNumber.substr(10, 3);
      return formattedPhoneNumber;
    };
    const closeConvoSlide = () => {
      showConvos.value = false;
      getLeads();
    };
    const updateProbability = (leadID, index) => {
      router.post(route("update.probability", leadID), {
        value: dynamicInputs.value[index].probability
      });
    };
    const updateLocation = (leadID, index) => {
      router.post(route("update.location", leadID), {
        value: dynamicInputs.value[index].location
      });
    };
    const updateHowSoon = (leadID, index) => {
      router.post(route("update.when", leadID), {
        value: dynamicInputs.value[index].how_soon
      });
    };
    const setLeadData = (lead) => {
      leadData.value.id = lead.id;
      leadData.value.notes = lead.notes;
      showConvos.value = true;
    };
    const formatDate = (date) => {
      if (date != null) {
        return moment(date).format("llll");
      } else {
        return null;
      }
    };
    const getConvoCount = (notes) => {
      const notesArray = JSON.parse(notes);
      if (notesArray !== null) {
        return notesArray.length;
      } else {
        return;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$3, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="px-4 sm:px-6 lg:px-8"${_scopeId}><div class="sm:flex sm:items-center"${_scopeId}><div class="sm:flex-auto"${_scopeId}><h1 class="text-base font-bold leading-6 text-gray-900"${_scopeId}>Leads</h1>`);
            if (leads.value.length) {
              _push2(`<button type="button" class="mt-2 block rounded-md bg-black hover:bg-primary px-2 py-1 text-center text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"${_scopeId}><i class="fa-solid fa-arrow-up-9-1 mr-2"${_scopeId}></i> Refine Table Data </button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="mt-4 sm:ml-16 sm:mt-0 flex gap-3"${_scopeId}><button type="button" class="block rounded-md bg-black hover:bg-primary px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"${_scopeId}><i class="fa-solid fa-file-arrow-up mr-2"${_scopeId}></i> Upload FB Leads </button></div></div><div class="mt-8 flow-root"${_scopeId}><div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8"${_scopeId}><div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8"${_scopeId}><table class="min-w-full divide-y divide-gray-300"${_scopeId}><thead${_scopeId}><tr class="divide-x divide-gray-200"${_scopeId}><th scope="col" class="py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pl-0"${_scopeId}> Name</th><th scope="col" class="px-4 py-3.5 text-left text-sm font-semibold text-gray-900"${_scopeId}> Phone</th><th scope="col" class="px-4 py-3.5 text-left text-sm font-semibold text-gray-900"${_scopeId}> Email</th><th scope="col" class="py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"${_scopeId}> Timelines</th><th scope="col" class="py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"${_scopeId}> Location</th><th scope="col" class="py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"${_scopeId}> Probability</th><th scope="col" class="py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"${_scopeId}> Follow Up</th><th scope="col" class="py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"${_scopeId}> Conversation</th></tr></thead><tbody class="divide-y divide-gray-200 bg-white"${_scopeId}><!--[-->`);
            ssrRenderList(leads.value, (lead, index) => {
              _push2(`<tr class="divide-x divide-gray-200"${_scopeId}><td class="capitalize whitespace-nowrap py-2 text-sm font-medium text-gray-900 sm:pl-0"${_scopeId}>${ssrInterpolate(lead.full_name)}</td><td class="whitespace-nowrap p-4 text-xs text-gray-500"${_scopeId}>${ssrInterpolate(formatPhoneNumber(lead.phone_number))}</td><td class="whitespace-nowrap p-4 text-xs text-gray-500"${_scopeId}>${ssrInterpolate(lead.email)}</td><td class="whitespace-nowrap p-1 text-sm text-gray-500"${_scopeId}><div${_scopeId}><input${ssrRenderAttr("value", dynamicInputs.value[index].how_soon)} type="text" name="location" id="location" class="block w-full rounded-md border-0 py-1.5 text-black shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-xs sm:leading-6" placeholder="Kanairo"${_scopeId}></div></td><td class="whitespace-nowrap p-1 text-sm text-gray-500"${_scopeId}><div${_scopeId}><input${ssrRenderAttr("value", dynamicInputs.value[index].location)} type="text" name="location" id="location" class="block w-full rounded-md border-0 py-1.5 text-black shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-xs sm:leading-6" placeholder="Kanairo"${_scopeId}></div></td><td class="text-center whitespace-nowrap p-1 text-sm text-gray-500"${_scopeId}><div class=""${_scopeId}><select id="location" name="location" class="block w-full rounded-md border-0 py-1.5 text-black ring-1 ring-inset ring-black focus:ring-2 focus:ring-primary text-xs"${_scopeId}><!--[-->`);
              ssrRenderList(statuses, (status, index2) => {
                _push2(`<option${ssrRenderAttr("value", status.id)}${_scopeId}>${ssrInterpolate(status.name)}</option>`);
              });
              _push2(`<!--]--></select></div></td><td class="whitespace-nowrap p-1 font-semibold text-xs text-gray-500"${_scopeId}>${ssrInterpolate(formatDate(lead.call_date))}</td><td class="text-center whitespace-nowrap py-1 text-sm text-gray-500 sm:pr-0"${_scopeId}><i class="fa-solid fa-messages text-black hover:text-primary fa-lg transform transition hover:scale-125 duration-700 ease-in-out hover:cursor-pointer"${_scopeId}></i><span class="ml-2"${_scopeId}><i class="fas fa-caret-right mr-2"${_scopeId}></i><span class="font-bold text-xs text-primary italic"${_scopeId}>${ssrInterpolate(getConvoCount(lead.notes))}</span></span></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div></div>`);
            if (leadModal.value) {
              _push2(ssrRenderComponent(_sfc_main$2, { onClose: closeLeadModal }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (showConvos.value) {
              _push2(ssrRenderComponent(_sfc_main$1, {
                leadData: leadData.value,
                onClose: closeConvoSlide
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "px-4 sm:px-6 lg:px-8" }, [
                  createVNode("div", { class: "sm:flex sm:items-center" }, [
                    createVNode("div", { class: "sm:flex-auto" }, [
                      createVNode("h1", { class: "text-base font-bold leading-6 text-gray-900" }, "Leads"),
                      leads.value.length ? (openBlock(), createBlock("button", {
                        key: 0,
                        type: "button",
                        class: "mt-2 block rounded-md bg-black hover:bg-primary px-2 py-1 text-center text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                      }, [
                        createVNode("i", { class: "fa-solid fa-arrow-up-9-1 mr-2" }),
                        createTextVNode(" Refine Table Data ")
                      ])) : createCommentVNode("", true)
                    ]),
                    createVNode("div", { class: "mt-4 sm:ml-16 sm:mt-0 flex gap-3" }, [
                      createVNode("button", {
                        onClick: ($event) => leadModal.value = true,
                        type: "button",
                        class: "block rounded-md bg-black hover:bg-primary px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                      }, [
                        createVNode("i", { class: "fa-solid fa-file-arrow-up mr-2" }),
                        createTextVNode(" Upload FB Leads ")
                      ], 8, ["onClick"])
                    ])
                  ]),
                  createVNode("div", { class: "mt-8 flow-root" }, [
                    createVNode("div", { class: "-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8" }, [
                      createVNode("div", { class: "inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8" }, [
                        createVNode("table", { class: "min-w-full divide-y divide-gray-300" }, [
                          createVNode("thead", null, [
                            createVNode("tr", { class: "divide-x divide-gray-200" }, [
                              createVNode("th", {
                                scope: "col",
                                class: "py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pl-0"
                              }, " Name"),
                              createVNode("th", {
                                scope: "col",
                                class: "px-4 py-3.5 text-left text-sm font-semibold text-gray-900"
                              }, " Phone"),
                              createVNode("th", {
                                scope: "col",
                                class: "px-4 py-3.5 text-left text-sm font-semibold text-gray-900"
                              }, " Email"),
                              createVNode("th", {
                                scope: "col",
                                class: "py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"
                              }, " Timelines"),
                              createVNode("th", {
                                scope: "col",
                                class: "py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"
                              }, " Location"),
                              createVNode("th", {
                                scope: "col",
                                class: "py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"
                              }, " Probability"),
                              createVNode("th", {
                                scope: "col",
                                class: "py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"
                              }, " Follow Up"),
                              createVNode("th", {
                                scope: "col",
                                class: "py-3.5 pl-4 pr-4 text-left text-sm font-semibold text-gray-900 sm:pr-0"
                              }, " Conversation")
                            ])
                          ]),
                          createVNode("tbody", { class: "divide-y divide-gray-200 bg-white" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(leads.value, (lead, index) => {
                              return openBlock(), createBlock("tr", { class: "divide-x divide-gray-200" }, [
                                createVNode("td", { class: "capitalize whitespace-nowrap py-2 text-sm font-medium text-gray-900 sm:pl-0" }, toDisplayString(lead.full_name), 1),
                                createVNode("td", { class: "whitespace-nowrap p-4 text-xs text-gray-500" }, toDisplayString(formatPhoneNumber(lead.phone_number)), 1),
                                createVNode("td", { class: "whitespace-nowrap p-4 text-xs text-gray-500" }, toDisplayString(lead.email), 1),
                                createVNode("td", { class: "whitespace-nowrap p-1 text-sm text-gray-500" }, [
                                  createVNode("div", null, [
                                    withDirectives(createVNode("input", {
                                      onBlur: ($event) => updateHowSoon(lead.id, index),
                                      "onUpdate:modelValue": ($event) => dynamicInputs.value[index].how_soon = $event,
                                      type: "text",
                                      name: "location",
                                      id: "location",
                                      class: "block w-full rounded-md border-0 py-1.5 text-black shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-xs sm:leading-6",
                                      placeholder: "Kanairo"
                                    }, null, 40, ["onBlur", "onUpdate:modelValue"]), [
                                      [vModelText, dynamicInputs.value[index].how_soon]
                                    ])
                                  ])
                                ]),
                                createVNode("td", { class: "whitespace-nowrap p-1 text-sm text-gray-500" }, [
                                  createVNode("div", null, [
                                    withDirectives(createVNode("input", {
                                      onBlur: ($event) => updateLocation(lead.id, index),
                                      "onUpdate:modelValue": ($event) => dynamicInputs.value[index].location = $event,
                                      type: "text",
                                      name: "location",
                                      id: "location",
                                      class: "block w-full rounded-md border-0 py-1.5 text-black shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-xs sm:leading-6",
                                      placeholder: "Kanairo"
                                    }, null, 40, ["onBlur", "onUpdate:modelValue"]), [
                                      [vModelText, dynamicInputs.value[index].location]
                                    ])
                                  ])
                                ]),
                                createVNode("td", { class: "text-center whitespace-nowrap p-1 text-sm text-gray-500" }, [
                                  createVNode("div", { class: "" }, [
                                    withDirectives(createVNode("select", {
                                      onChange: ($event) => updateProbability(lead.id, index),
                                      "onUpdate:modelValue": ($event) => dynamicInputs.value[index].probability = $event,
                                      id: "location",
                                      name: "location",
                                      class: "block w-full rounded-md border-0 py-1.5 text-black ring-1 ring-inset ring-black focus:ring-2 focus:ring-primary text-xs"
                                    }, [
                                      (openBlock(), createBlock(Fragment, null, renderList(statuses, (status, index2) => {
                                        return createVNode("option", {
                                          key: index2,
                                          value: status.id
                                        }, toDisplayString(status.name), 9, ["value"]);
                                      }), 64))
                                    ], 40, ["onChange", "onUpdate:modelValue"]), [
                                      [vModelSelect, dynamicInputs.value[index].probability]
                                    ])
                                  ])
                                ]),
                                createVNode("td", { class: "whitespace-nowrap p-1 font-semibold text-xs text-gray-500" }, toDisplayString(formatDate(lead.call_date)), 1),
                                createVNode("td", { class: "text-center whitespace-nowrap py-1 text-sm text-gray-500 sm:pr-0" }, [
                                  createVNode("i", {
                                    onClick: ($event) => setLeadData(lead),
                                    class: "fa-solid fa-messages text-black hover:text-primary fa-lg transform transition hover:scale-125 duration-700 ease-in-out hover:cursor-pointer"
                                  }, null, 8, ["onClick"]),
                                  createVNode("span", { class: "ml-2" }, [
                                    createVNode("i", { class: "fas fa-caret-right mr-2" }),
                                    createVNode("span", { class: "font-bold text-xs text-primary italic" }, toDisplayString(getConvoCount(lead.notes)), 1)
                                  ])
                                ])
                              ]);
                            }), 256))
                          ])
                        ])
                      ])
                    ])
                  ])
                ]),
                leadModal.value ? (openBlock(), createBlock(_sfc_main$2, {
                  key: 0,
                  onClose: closeLeadModal
                })) : createCommentVNode("", true),
                showConvos.value ? (openBlock(), createBlock(_sfc_main$1, {
                  key: 1,
                  leadData: leadData.value,
                  onClose: closeConvoSlide
                }, null, 8, ["leadData"])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Leads.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
