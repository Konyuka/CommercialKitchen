import { ref, useSSRContext, watch, toRef, onMounted, unref, withCtx, withDirectives, createVNode, vShow } from "vue";
import { ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrRenderStyle, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$5 } from "./AdminLayout-86ff2b34.js";
import { useForm } from "@inertiajs/vue3";
import moment from "moment";
import { QuillEditor } from "@vueup/vue-quill";
import ImageUploader from "quill-image-uploader";
import axios from "axios";
const _sfc_main$4 = {
  __name: "BlogList",
  __ssrInlineRender: true,
  props: {
    blogs: Array
  },
  emits: [
    "createBlog",
    "publishBlog",
    "featureBlog",
    "editBlog",
    "getBlogs",
    "importBlogs"
  ],
  setup(__props, { emit: emits }) {
    const blogToDelete = ref(null);
    const deleteModal = ref(false);
    const publishClass = (blogStatus) => {
      if (blogStatus == 1) {
        return true;
      } else {
        return false;
      }
    };
    const featureClass = (blogStatus) => {
      if (blogStatus == 1) {
        return true;
      } else {
        return false;
      }
    };
    const formatDate = (date) => {
      return moment(date).format("MMM Do YY, h:mm a");
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="border-b border-gray-200 pb-5 sm:flex sm:items-center sm:justify-between"><h3 class="text-2xl font-semibold leading-6 text-gray-900">Blog List</h3><div class="mt-3 sm:ml-4 sm:mt-0 gap-5 flex"><button type="button" class="inline-flex items-center rounded-md bg-black hover:bg-primary px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"><i class="fas fa-add fa-xl mr-2 text-white"></i> Create Blog </button><button type="button" class="inline-flex items-center rounded-md bg-black hover:bg-primary px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"><i class="fa-solid fa-cloud-arrow-up fa-xl mr-2 text-white"></i> Import Blogs </button></div></div><div class="px-4 sm:px-6 lg:px-8"><div class="-mx-4 mt-8 flow-root sm:mx-0"><table class="min-w-full"><colgroup><col class="w-full sm:w-1/2"><col class="sm:w-1/6"><col class="sm:w-1/6"><col class="sm:w-1/6"></colgroup><thead class="border-b border-gray-300 text-gray-900"><tr><th scope="col" class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-0"> Blog Details</th><th scope="col" class="hidden px-1 py-3.5 text-right text-sm font-semibold text-gray-900 sm:table-cell"> Published</th><th scope="col" class="hidden px-1 py-3.5 text-right text-sm font-semibold text-gray-900 sm:table-cell"> Featured</th><th scope="col" class="hidden px-3 py-3.5 text-right text-sm font-semibold text-gray-900 sm:table-cell">Date Posted </th><th scope="col" class="py-3.5 pl-3 pr-4 text-right text-sm font-semibold text-gray-900 sm:pr-0"> Actions</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.blogs, (blog, index) => {
        _push(`<tr class="border-b border-gray-200"><td class="max-w-0 py-5 pl-4 pr-3 text-sm sm:pl-0"><div class="font-semibold text-gray-900">${ssrInterpolate(blog.title)}</div><div class="mt-1 truncate text-gray-500">${ssrInterpolate(blog.excerpt)}</div></td><td class="hidden px-1 py-5 text-right text-sm text-gray-500 sm:table-cell"><button type="button" class="${ssrRenderClass([[publishClass(blog.published) ? "bg-primary" : "bg-black"], "relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2"])}" role="switch" aria-checked="false"><span aria-hidden="true" class="${ssrRenderClass([[publishClass(blog.published) ? "translate-x-5" : "translate-x-0"], "pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out"])}"></span></button></td><td class="hidden px-1 py-5 text-right text-sm text-gray-500 sm:table-cell"><button type="button" class="${ssrRenderClass([[featureClass(blog.featured) ? "bg-primary" : "bg-black"], "bg-black relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2"])}" role="switch" aria-checked="false"><span aria-hidden="true" class="${ssrRenderClass([[featureClass(blog.featured) ? "translate-x-5" : "translate-x-0"], "translate-x-0 pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out"])}"></span></button></td><td class="hidden font-medium px-3 py-5 text-right text-sm text-gray-500 sm:table-cell">${ssrInterpolate(formatDate(blog.created_at))}</td><td class="py-5 pl-3 pr-4 text-right text-sm text-gray-500 sm:pr-0"><div><i class="transform transtion hover:scale-125 duration-600 hover:cursor-pointer ease-in-out fas fa-edit text-black fa-xl hover:text-primary mr-2"></i><i class="transform transtion hover:scale-125 duration-600 hover:cursor-pointer ease-in-out fas fa-trash text-black fa-xl hover:text-primary"></i></div></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div>`);
      if (deleteModal.value) {
        _push(`<div class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true"><div class="fixed inset-0 bg-black bg-opacity-75 transition-opacity"></div><div class="fixed inset-0 z-10 w-screen overflow-y-auto"><div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0"><div class="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6"><div><div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100"><i class="fa-solid fa-trash-can-clock fa-2x text-primary"></i></div><div class="mt-3 text-center sm:mt-5"><h3 class="text-sm font-medium leading-6 text-gray-900" id="modal-title"> Are you sure you want to delete this blog? </h3><div class="mt-2"><p class="text-md text-black font-semibold">${ssrInterpolate(blogToDelete.value.title)}</p></div></div></div><div class="mt-5 sm:mt-6 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:gap-3"><button type="button" class="inline-flex w-full justify-center rounded-md bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 sm:col-start-2"> Confirm </button><button type="button" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-black hover:text-white shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-black sm:col-start-1 sm:mt-0"> Cancel </button></div></div></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Admin/BlogList.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const vueQuill_snow = "";
const vueQuill_bubble = "";
const _sfc_main$3 = {
  __name: "CreateBlog",
  __ssrInlineRender: true,
  props: {
    blogToEdit: Object,
    uploadedPost: Boolean
  },
  emits: [
    "listBlogs"
    // 'update:content'
  ],
  setup(__props, { emit }) {
    const props = __props;
    const blog = useForm({
      title: null,
      category: null,
      excerpt: null,
      cover: null,
      content: null,
      uploadID: null
    });
    watch(toRef(() => props.blogToEdit), (newX) => {
      if (newX !== null) {
        blog.title = newX.title;
        blog.category = newX.category_id;
        blog.excerpt = newX.excerpt;
        blog.cover = newX.cover;
        blog.content = newX.content;
        if (props.uploadedPost) {
          showPreview.value = false;
        }
      } else {
        blog.reset();
        var element = document.getElementsByClassName("ql-editor");
        element[0].innerHTML = "";
        uploadedImage.value = null;
        imagePreview.value = null;
        showPreview.value = false;
      }
    });
    const category = useForm({
      name: null
    });
    const uploadedImage = ref(null);
    const imagePreview = ref(null);
    const showPreview = ref(false);
    const categoryModal = ref(false);
    const categoryList = ref([]);
    const modules = {
      name: "imageUploader",
      module: ImageUploader,
      options: {
        upload: (file) => {
          return new Promise((resolve, reject) => {
            const formData = new FormData();
            formData.append("image", file);
            axios.post("/upload-image", formData).then((res) => {
              console.log(res);
              resolve(res.data.url);
            }).catch((err) => {
              reject("Upload failed");
              console.error("Error:", err);
            });
          });
        }
      }
    };
    const getCategories = () => {
      axios.get("/api/get-categories").then((res) => {
        categoryList.value = res.data;
      }).catch((err) => {
        console.log(err);
      });
    };
    onMounted(() => {
      getCategories();
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="border-b border-gray-200 pb-5 sm:flex sm:items-center sm:justify-between"><div class="flex justify-between w-full"><div><h3 class="text-2xl font-semibold leading-6 text-gray-900">Create new blog</h3></div><div><button type="button" class="rounded bg-black hover:bg-primary px-2 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"><i class="fas fa-arrow-left fa-xl mr-2 text-white"></i> Blog List </button></div></div></div><div class="my-10"><div class="grid grid-cols-3 gap-5"><div class="col-span-2"><label for="email" class="block text-sm font-bold leading-6 text-black">Blog Title</label><div class="mt-2"><input${ssrRenderAttr("value", unref(blog).title)} type="text" name="text" id="text" class="capitalize font-semibold block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"><div>`);
      if (unref(blog).errors.title) {
        _push(`<p class="text-black mt-5 text-xs"><i class="fa-regular fa-circle-exclamation fa-xl mr-2 text-primary font-semibold"></i> ${ssrInterpolate(unref(blog).errors.title)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><div><div><div class="flex justify-between"><label for="location" class="block text-sm font-bold leading-6 text-gray-900">Category</label><button type="button" class="rounded bg-black px-2 py-1 text-xs font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"> Add Category </button></div><select id="location" name="location" class="font-semibold mt-2 block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-black focus:ring-2 focus:ring-primary sm:text-sm sm:leading-6">`);
      if (categoryList.value.length) {
        _push(`<!--[-->`);
        ssrRenderList(categoryList.value, (category2) => {
          _push(`<option class="font-medium mb-2"${ssrRenderAttr("value", parseInt(category2.id))}>${ssrInterpolate(category2.name)}</option>`);
        });
        _push(`<!--]-->`);
      } else {
        _push(`<option class="font-semibold italic">Please add categories to choose from</option>`);
      }
      _push(`</select></div></div></div><div class="grid grid-cols-3 gap-5 mt-10"><div class="col-span-2"><label for="comment" class="block text-sm font-bold leading-6 text-gray-900"> Add blog excerpt </label><div class="mt-2"><textarea rows="4" name="comment" id="comment" class="font-medium block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6">${ssrInterpolate(unref(blog).excerpt)}</textarea><div>`);
      if (unref(blog).errors.excerpt) {
        _push(`<p class="text-black mt-5 text-xs"><i class="fa-regular fa-circle-exclamation fa-xl mr-2 text-primary font-semibold"></i> ${ssrInterpolate(unref(blog).errors.excerpt)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><div><div class="col-span-full"><div class="flex justify-between"><label for="cover-photo" class="block text-sm font-bold leading-6 text-gray-900"> Cover </label><label for="cover-photo" class="block text-sm font-semibold leading-6 text-green">${ssrInterpolate(uploadedImage.value)}</label></div><div class="mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-2"><div class="text-center"><svg class="mx-auto h-12 w-12 text-gray-300" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z" clip-rule="evenodd"></path></svg><div class="mt-4 flex text-sm leading-6 text-gray-600"><label for="file-upload" class="relative cursor-pointer rounded-md bg-white font-semibold text-black"><input id="file-upload" name="file-upload" type="file" class=""></label></div></div></div><div>`);
      if (unref(blog).errors.cover) {
        _push(`<p class="text-black mt-5 text-xs"><i class="fa-regular fa-circle-exclamation fa-xl mr-2 text-primary font-semibold"></i> ${ssrInterpolate(unref(blog).errors.cover)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div><div class="my-10"><img${ssrRenderAttr("src", imagePreview.value)} class="min-h-[500px] max-h-[500px] w-full object-cover rounded-lg" style="${ssrRenderStyle(showPreview.value ? null : { display: "none" })}"><img${ssrRenderAttr("src", unref(blog).cover)} class="min-h-[500px] max-h-[500px] w-full object-cover rounded-lg" style="${ssrRenderStyle(__props.blogToEdit != null && uploadedImage.value == null ? null : { display: "none" })}"></div><div class="my-10 mt-10 flex justify-between"><div></div><div><button type="button" class="bg-black px-3 py-4 text-sm font-semibold text-white hover:text-black shadow-sm hover:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"> Rephrase with AI <i class="ml-3 fas fa-robot fa-xl"></i></button></div></div><div class="mt-10 h-screen">`);
      _push(ssrRenderComponent(unref(QuillEditor), {
        class: "ql-editor",
        ref: "quillEditor",
        content: unref(blog).content,
        "onUpdate:content": ($event) => unref(blog).content = $event,
        modules,
        toolbar: "full",
        theme: "snow",
        contentType: "html"
      }, null, _parent));
      _push(`<div>`);
      if (unref(blog).errors.content) {
        _push(`<p class="text-black mt-5 text-xs"><i class="fa-regular fa-circle-exclamation fa-xl mr-2 text-primary font-semibold"></i> ${ssrInterpolate(unref(blog).errors.content)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="mt-40">`);
      if (__props.blogToEdit == null || __props.uploadedPost === true) {
        _push(`<button type="button" class="rounded-md bg-black hover:bg-primary px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"> Save blog <i class="fas fa-check"></i></button>`);
      } else {
        _push(`<button type="button" class="rounded-md bg-black hover:bg-primary px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"> Update blog <i class="fas fa-check"></i></button>`);
      }
      _push(`</div></div><div style="${ssrRenderStyle(categoryModal.value ? null : { display: "none" })}" class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true"><div class="fixed inset-0 bg-black bg-opacity-75 transition-opacity"></div><div class="fixed inset-0 z-10 w-screen overflow-y-auto"><div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0"><div class="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6"><div><div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100"><i class="fas fa-list text-primary fa-2x my-5"></i></div><div class="mt-3 text-center sm:mt-5"><h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title">Enter category name</h3><div class="m-10"><div><label for="email" class="sr-only">Email</label><input${ssrRenderAttr("value", unref(category).name)} type="text" name="text" id="text" class="py-2 capitalize text-center font-bold block w-full rounded-md border-0 text-gray-900 shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6"><div>`);
      if (unref(category).errors.name) {
        _push(`<p class="text-black mt-5 text-xs"><i class="fa-regular fa-circle-exclamation fa-xl mr-2 text-primary font-semibold"></i> ${ssrInterpolate(unref(category).errors.name)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div></div><div class="mt-5 sm:mt-6 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:gap-3"><button type="button" class="inline-flex w-full justify-center rounded-md hover:bg-primary bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black sm:col-start-2"> Save </button><button type="button" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 hover:text-white shadow-sm ring-1 ring-inset ring-black hover:bg-black sm:col-start-1 sm:mt-0"> Close </button></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Admin/CreateBlog.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "ImportBlogModal",
  __ssrInlineRender: true,
  emits: [
    "close"
  ],
  setup(__props, { emit }) {
    const websiteName = ref(null);
    ref(null);
    ref([]);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true"><div class="fixed inset-0 bg-black bg-opacity-75 transition-opacity"></div><div class="fixed inset-0 z-10 w-screen overflow-y-auto"><div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0"><div class="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:p-6"><div><div class="mt-2 text-center sm:mt-5"><h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title"> Add wordpress site details </h3><div class="mt-5"><div class="text-left mb-3"><label for="email" class="block text-sm font-semibold leading-6 text-black">Website Name</label><div class="mt-2"><input${ssrRenderAttr("value", websiteName.value)} type="text" name="site" id="site" class="block w-full rounded-md border-0 py-1.5 text-black shadow-sm ring-1 ring-inset ring-black placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-primary sm:text-sm sm:leading-6" placeholder="kitchens kenya" aria-describedby="email-description"></div></div><div class="space-y-12"><div class="border-b border-gray-900/10 pb-12"><div class="mt-10 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6"><div class="col-span-full"><label for="cover-photo" class="block text-sm font-semibold leading-6 text-black"> Upload JSON file </label><div class="mt-2 flex justify-center rounded-lg border border-dashed border-gray-900/25 px-6 py-10"><div class="text-center"><i></i><div class="mt-4 flex text-sm leading-6 text-gray-600"><label for="file-upload" class="relative cursor-pointer rounded-md bg-white font-semibold text-primary-100 focus-within:outline-none focus-within:ring-2 focus-within:ring-primary-200 focus-within:ring-offset-2 hover:text-primary-200"><input id="file-upload" name="file-upload" type="file" class="item-center ring-1 ring-primary"></label></div></div></div></div></div></div></div></div></div></div><div class="mt-5 sm:mt-6 sm:grid sm:grid-flow-row-dense sm:grid-cols-2 sm:gap-3"><button type="button" class="inline-flex w-full justify-center rounded-md bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 sm:col-start-2"> We deserve their blogs </button><button type="button" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-black hover:text-white shadow-sm ring-1 ring-inset ring-black hover:bg-black sm:col-start-1 sm:mt-0"> Cancel </button></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Admin/ImportBlogModal.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "ImportBlogs",
  __ssrInlineRender: true,
  setup(__props) {
    onMounted(() => {
      getImportedBlogs();
    });
    const addBlogFeedModal = ref(false);
    const defaultView = ref(1);
    const importedBlogs = ref([]);
    const blogToEdit = ref(null);
    const closeBlogModal = () => {
      addBlogFeedModal.value = false;
      getImportedBlogs();
    };
    const getImportedBlogs = () => {
      axios.get(route("get.imported.blogs")).then((res) => {
        importedBlogs.value = res.data;
      }).catch((err) => {
        console.log(err);
      });
    };
    const listPage = () => {
      defaultView.value = 1;
      getImportedBlogs();
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div style="${ssrRenderStyle(defaultView.value == 1 ? null : { display: "none" })}" class="px-4 sm:px-6 lg:px-8"><div class="sm:flex sm:items-center"><div class="sm:flex-auto"><h1 class="text-base font-semibold leading-6 text-gray-900">Import Blogs</h1></div><div class="mt-4 sm:ml-16 sm:mt-0 sm:flex-none"><button type="button" class="block rounded-md bg-black px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"><i class="fas fa-add fa-xl"></i> Add new blog feed </button></div></div><div class="mt-8 flow-root"><div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8"><div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8"><table class="min-w-full divide-y divide-gray-300"><thead><tr><th scope="col" class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-0"> Status </th><th scope="col" class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-0"> Website Name </th><th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"> Website Title </th><th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"> Blog Link </th><th scope="col" class="relative py-3.5 pl-3 pr-4 sm:pr-0"><span class="sr-only">Edit</span></th></tr></thead><tbody class="divide-y divide-gray-200"><!--[-->`);
      ssrRenderList(importedBlogs.value, (blog) => {
        _push(`<tr><td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-0">`);
        if (blog.published) {
          _push(`<span class="inline-flex items-center gap-x-1.5 rounded-md px-2 py-1 text-xs font-medium text-black ring-1 ring-inset ring-black"><svg class="h-1.5 w-1.5 fill-primary" viewBox="0 0 6 6" aria-hidden="true"><circle cx="3" cy="3" r="3"></circle></svg> Posted </span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</td><td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-0">${ssrInterpolate(blog.website)}</td><td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">${ssrInterpolate(blog.title)}</td><td class="text-center whitespace-nowrap px-3 py-4 text-sm text-gray-500"><a${ssrRenderAttr("href", blog.link)} target="_blank"><i class="fa-sharp fa-solid fa-square-arrow-up-right fa-xl"></i></a></td><td class="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-0"><button class="transform transition hover:scale-125 duration-600 ease-in-out text-black font-bold hover:text-indigo-900"><i class="fas fa-edit fa-xl"></i> Edit Me </button></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></div>`);
      if (addBlogFeedModal.value) {
        _push(ssrRenderComponent(_sfc_main$2, { onClose: closeBlogModal }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_sfc_main$3, {
        uploadedPost: true,
        blogToEdit: blogToEdit.value,
        style: defaultView.value == 2 ? null : { display: "none" },
        onListBlogs: ($event) => listPage()
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Admin/ImportBlogs.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Blogs",
  __ssrInlineRender: true,
  setup(__props) {
    onMounted(() => {
      getBlogs();
    });
    const defaultView = ref(1);
    const blogs = ref([]);
    const blogToEdit = ref(null);
    watch(blogToEdit, (newX) => {
      if (newX) {
        defaultView.value = 2;
      }
    });
    const importBlogs = () => {
      defaultView.value = 3;
    };
    const createPage = () => {
      blogToEdit.value = null;
      defaultView.value = 2;
    };
    const listPage = () => {
      defaultView.value = 1;
      getBlogs();
    };
    const publishBlog = (blog) => {
      axios.post(route("publish.blog", blog)).then((res) => {
        getBlogs();
      });
    };
    const featureBlog = (blog) => {
      axios.post(route("feature.blog", blog)).then((res) => {
        getBlogs();
      });
    };
    const editBlog = (blog) => {
      blogToEdit.value = blog;
    };
    const getBlogs = () => {
      axios.get("/api/get-blogs").then((res) => {
        blogs.value = res.data;
      }).catch((err) => {
        console.log(err);
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$5, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$4, {
              blogs: blogs.value,
              style: defaultView.value == 1 ? null : { display: "none" },
              onCreateBlog: createPage,
              onImportBlogs: importBlogs,
              onPublishBlog: publishBlog,
              onFeatureBlog: featureBlog,
              onEditBlog: editBlog,
              onGetBlogs: getBlogs
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              blogToEdit: blogToEdit.value,
              style: defaultView.value == 2 ? null : { display: "none" },
              onListBlogs: listPage
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$1, {
              style: defaultView.value == 3 ? null : { display: "none" }
            }, null, _parent2, _scopeId));
          } else {
            return [
              withDirectives(createVNode(_sfc_main$4, {
                blogs: blogs.value,
                onCreateBlog: createPage,
                onImportBlogs: importBlogs,
                onPublishBlog: publishBlog,
                onFeatureBlog: featureBlog,
                onEditBlog: editBlog,
                onGetBlogs: getBlogs
              }, null, 8, ["blogs"]), [
                [vShow, defaultView.value == 1]
              ]),
              withDirectives(createVNode(_sfc_main$3, {
                blogToEdit: blogToEdit.value,
                onListBlogs: listPage
              }, null, 8, ["blogToEdit"]), [
                [vShow, defaultView.value == 2]
              ]),
              withDirectives(createVNode(_sfc_main$1, null, null, 512), [
                [vShow, defaultView.value == 3]
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Admin/Blogs.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
