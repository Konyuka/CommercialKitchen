import { computed, unref, withCtx, createVNode, toDisplayString, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttr, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ClientLayout-e3ead9de.js";
import "./Services-9319d8d3.js";
import "wow.js";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = {
  __name: "Detail",
  __ssrInlineRender: true,
  props: {
    blog: Object
  },
  setup(__props) {
    const props = __props;
    const blogUrl = computed(() => {
      const title = props.blog.title;
      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const trimmedSlug = slug.replace(/^-+|-+$/g, "");
      const finalSlug = trimmedSlug.replace(/-{2,}/g, "-");
      return "https://commercialkitchen.co.ke/commercial-kitchen-blog/" + finalSlug;
    });
    const blogImage = computed(() => {
      const imagePath = props.blog.cover;
      const escapedImage = imagePath.replace(/\\\//g, "/");
      return "https://commercialkitchen.co.ke/commercial-kitchen-blog/" + escapedImage;
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><meta property="og:article:author" content="https://www.linkedin.com/in/lynnkimeto/"><meta property="og:article:published_time"${ssrRenderAttr("content", __props.blog.created_at)}><meta property="og:article:section"${ssrRenderAttr("content", __props.blog.excerpt)}><meta property="og:article:tag"${ssrRenderAttr("content", __props.blog.title)}><meta property="company:id" content="Your LinkedIn Company Page ID"><meta property="og:type" content="website"><meta property="og:title"${ssrRenderAttr("content", __props.blog.title)}><meta property="og:description"${ssrRenderAttr("content", __props.blog.excerpt)}><meta property="og:url"${ssrRenderAttr("content", blogUrl.value)}><meta property="og:image"${ssrRenderAttr("content", blogImage.value)}><meta property="og:image:width" content="1080px"><meta property="og:image:height" content="1350px"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:site" content="@commercialkitchensconsultants"><meta name="twitter:creator" content="@commercialkitchensconsultants"><meta name="twitter:title"${ssrRenderAttr("content", __props.blog.title)}><meta name="twitter:description"${ssrRenderAttr("content", __props.blog.excerpt)}><meta name="twitter:image"${ssrRenderAttr("content", blogImage.value)}><meta name="twitter:image:alt" content="https://commercialkitchen.co.ke/img/logo.jpg">`);
      _push(ssrRenderComponent(unref(Head), { title: "Commercial Kitchen Consultancy Kenya Article" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}><div class="bg-white"${_scopeId}><div aria-hidden="true" class="relative"${_scopeId}><img${ssrRenderAttr("src", __props.blog.cover)} alt="" class="h-96 w-full object-cover object-center"${_scopeId}><div class="absolute inset-0 bg-gradient-to-t from-white"${_scopeId}></div></div><div class="relative mx-auto -mt-12 max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl text-center lg:max-w-4xl"${_scopeId}><p class="font-semibold mb-4 text-2xl"${_scopeId}>${ssrInterpolate(__props.blog.categories.name)}</p><h2 data-wow-duration="1.5" class="wow animate__rubberBand text-3xl font-bold tracking-tight text-primary sm:text-4xl"${_scopeId}>${ssrInterpolate(__props.blog.title)}</h2></div></div></div><div class="bg-white mb-20"${_scopeId}><div class="mx-auto max-w-5xl px-4 py-2 sm:px-6 sm:py-2 lg:max-w-7xl lg:px-8"${_scopeId}><div class="bg-white px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-5xl text-base leading-7 text-gray-700"${_scopeId}><div class="mt-2 max-w-5xl"${_scopeId}>${__props.blog.content}</div></div></div></div></div><div class="bg-white py-10 mb-20"${_scopeId}><div class="mx-auto max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl lg:mx-0"${_scopeId}><h2 class="text-primary text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"${_scopeId}>Related blogs </h2></div><div class="mx-auto mt-10 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 border-t border-gray-200 pt-10 sm:mt-16 sm:pt-16 lg:mx-0 lg:max-w-none lg:grid-cols-3"${_scopeId}><article class="flex max-w-xl flex-col items-start justify-between"${_scopeId}><div class="flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Mar 16, 2020</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Tables</a></div><div class="group relative"${_scopeId}><h3 class="mt-3 text-lg font-semibold leading-6 text-gray-900 group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Stainless Steel Tables </a></h3><p class="mt-5 line-clamp-3 text-sm leading-6 text-gray-600"${_scopeId}> When it comes to stainless steel work tables &amp; prep tables, the options are practically endless. With thousands of variations available, you can customize them to fit your kitchen&#39;s exact requirements. These tables can come with additional features like back or side panels, extra shelves, drawers, racks, caster wheels. Create functional, top-notch, and long-lasting spaces for food prep and storage with our diverse collection of commercial kitchen tables. Our tables are designed to make your life easier in the kitchen. They&#39;re not only practical, but they also offer high quality and durability, ensuring they can withstand the demands of a bustling kitchen. Easy to clean, they maintain maximum hygiene standards, which is essential in any culinary environment. From different sizes to various features, you can choose the perfect table that suits your specific venture. </p></div></article></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "bg-white" }, [
                  createVNode("div", {
                    "aria-hidden": "true",
                    class: "relative"
                  }, [
                    createVNode("img", {
                      src: __props.blog.cover,
                      alt: "",
                      class: "h-96 w-full object-cover object-center"
                    }, null, 8, ["src"]),
                    createVNode("div", { class: "absolute inset-0 bg-gradient-to-t from-white" })
                  ]),
                  createVNode("div", { class: "relative mx-auto -mt-12 max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl text-center lg:max-w-4xl" }, [
                      createVNode("p", { class: "font-semibold mb-4 text-2xl" }, toDisplayString(__props.blog.categories.name), 1),
                      createVNode("h2", {
                        "data-wow-duration": "1.5",
                        class: "wow animate__rubberBand text-3xl font-bold tracking-tight text-primary sm:text-4xl"
                      }, toDisplayString(__props.blog.title), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white mb-20" }, [
                  createVNode("div", { class: "mx-auto max-w-5xl px-4 py-2 sm:px-6 sm:py-2 lg:max-w-7xl lg:px-8" }, [
                    createVNode("div", { class: "bg-white px-6 lg:px-8" }, [
                      createVNode("div", { class: "mx-auto max-w-5xl text-base leading-7 text-gray-700" }, [
                        createVNode("div", {
                          class: "mt-2 max-w-5xl",
                          innerHTML: __props.blog.content
                        }, null, 8, ["innerHTML"])
                      ])
                    ])
                  ])
                ]),
                createVNode("div", { class: "bg-white py-10 mb-20" }, [
                  createVNode("div", { class: "mx-auto max-w-7xl px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl lg:mx-0" }, [
                      createVNode("h2", { class: "text-primary text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl" }, "Related blogs ")
                    ]),
                    createVNode("div", { class: "mx-auto mt-10 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 border-t border-gray-200 pt-10 sm:mt-16 sm:pt-16 lg:mx-0 lg:max-w-none lg:grid-cols-3" }, [
                      createVNode("article", { class: "flex max-w-xl flex-col items-start justify-between" }, [
                        createVNode("div", { class: "flex items-center gap-x-4 text-xs" }, [
                          createVNode("time", {
                            datetime: "2020-03-16",
                            class: "text-gray-500"
                          }, "Mar 16, 2020"),
                          createVNode("a", {
                            href: "#",
                            class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                          }, "Tables")
                        ]),
                        createVNode("div", { class: "group relative" }, [
                          createVNode("h3", { class: "mt-3 text-lg font-semibold leading-6 text-gray-900 group-hover:text-gray-600" }, [
                            createVNode("a", { href: "#" }, [
                              createVNode("span", { class: "absolute inset-0" }),
                              createTextVNode(" Stainless Steel Tables ")
                            ])
                          ]),
                          createVNode("p", { class: "mt-5 line-clamp-3 text-sm leading-6 text-gray-600" }, " When it comes to stainless steel work tables & prep tables, the options are practically endless. With thousands of variations available, you can customize them to fit your kitchen's exact requirements. These tables can come with additional features like back or side panels, extra shelves, drawers, racks, caster wheels. Create functional, top-notch, and long-lasting spaces for food prep and storage with our diverse collection of commercial kitchen tables. Our tables are designed to make your life easier in the kitchen. They're not only practical, but they also offer high quality and durability, ensuring they can withstand the demands of a bustling kitchen. Easy to clean, they maintain maximum hygiene standards, which is essential in any culinary environment. From different sizes to various features, you can choose the perfect table that suits your specific venture. ")
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Client/Detail.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
