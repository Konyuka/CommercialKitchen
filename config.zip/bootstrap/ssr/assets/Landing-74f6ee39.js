import { ref, resolveComponent, unref, withCtx, createTextVNode, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle } from "vue/server-renderer";
import { Link, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$6 } from "./ClientLayout-e3ead9de.js";
/* empty css                   */import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
import "wow.js";
const _sfc_main$5 = {
  __name: "Carousel",
  __ssrInlineRender: true,
  setup(__props) {
    const slide = ref(1);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = resolveComponent("Head");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_Head, { title: "Carousel" }, null, _parent));
      _push(`<div id="controls-carousel" class="relative w-full overflow-hidden" data-carousel="static"><div class="relative h-96 overflow-hidden md:h-[600px]">`);
      if (slide.value == 1) {
        _push(`<div class="duration-700 ease-in-out"><img src="img/concept.jpg" class="object-cover absolute block w-full h-full h-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="..."><div class="absolute z-10 flex flex-col items-center justify-center h-full w-full"><div class="absolute top-0 left-0 w-full h-full bg-black opacity-60"></div><h2 data-wow-duration="2s" class="wow animate__backInRight text-xl sm:text-5xl font-bold text-white z-20 mb-5 sm:mb-10">From Concept to Completion</h2><p class="wow animate__backInRight text-sm sm:text-lg text-white z-20 px-10 sm:px-96 text-center mb-5 sm:mb-10 leading-8"> Transform your food service vision into reality with our expert consultancy services. We provide comprehensive guidance and support, ensuring a seamless transition from concept to a remarkable culinary space.</p>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("services"),
          type: "button",
          "data-wow-delay": "6s",
          class: "wow animate__rubberBand z-20 mt-5 border-2 border-primary hover:bg-primary hover:text-black px-5 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Learn More <i class="ml-2 fas fa-up-right"${_scopeId}></i>`);
            } else {
              return [
                createTextVNode(" Learn More "),
                createVNode("i", { class: "ml-2 fas fa-up-right" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (slide.value == 2) {
        _push(`<div class="duration-700 ease-in-out"><img src="img/design.jpg" class="object-cover absolute block w-full h-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="..."><div class="absolute z-10 flex flex-col items-center justify-center h-full w-full"><div class="absolute top-0 left-0 w-full h-full bg-black opacity-60"></div><h2 data-wow-duration="2s" class="wow animate__backInRight text-xl sm:text-5xl font-bold text-white z-20 mb-5 sm:mb-10">Layout Concepts</h2><p class="wow animate__backInRight text-sm sm:text-lg text-white z-20 px-10 sm:px-96 text-center mb-5 sm:mb-10 leading-8"> We pride ourselves on our ability to craft kitchen designs that are not only visually stunning but also highly practical, ensuring your culinary operations run smoothly and efficiently. </p>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("services"),
          type: "button",
          "data-wow-delay": "6s",
          class: "wow animate__rubberBand z-20 mt-5 border-2 border-primary hover:bg-primary hover:text-black px-5 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Learn More <i class="ml-2 fas fa-up-right"${_scopeId}></i>`);
            } else {
              return [
                createTextVNode(" Learn More "),
                createVNode("i", { class: "ml-2 fas fa-up-right" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (slide.value == 3) {
        _push(`<div class="duration-700 ease-in-out"><img src="img/equipment.jpg" class="object-cover absolute block w-full h-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="..."><div class="absolute z-10 flex flex-col items-center justify-center h-full w-full"><div class="absolute top-0 left-0 w-full h-full bg-black opacity-60"></div><h2 data-wow-duration="2s" text-xl sm: class="wow animate__backInRight text-xl sm:text-5xl font-bold text-white z-20 mb-5 sm:mb-10">Choice of Equipment </h2><p class="wow animate__backInRight text-sm sm:text-lg text-white z-20 px-10 sm:px-96 text-center mb-5 sm:mb-10 leading-8"> We guide you in choosing the ideal equipment for your culinary space. We leverage our industry knowledge and extensive network to curate a tailored selection that meets your unique needs and budget, ensuring optimal performance and efficiency in your operations. </p>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("services"),
          type: "button",
          "data-wow-delay": "6s",
          class: "wow animate__rubberBand z-20 sm:mt-5 border-2 border-primary hover:bg-primary hover:text-black px-5 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Learn More <i class="ml-2 fas fa-up-right"${_scopeId}></i>`);
            } else {
              return [
                createTextVNode(" Learn More "),
                createVNode("i", { class: "ml-2 fas fa-up-right" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (slide.value == 4) {
        _push(`<div class="duration-700 ease-in-out"><img src="img/supplier.jpg" class="object-cover absolute block w-full h-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="..."><div class="absolute z-10 flex flex-col items-center justify-center h-full w-full"><div class="absolute top-0 left-0 w-full h-full bg-black opacity-60"></div><h2 data-wow-duration="2s" text-xl sm: class="wow animate__backInRight text-xl sm:text-5xl font-bold text-white z-20 mb-5 sm:mb-10">Supplier Qualification </h2><p class="wow animate__backInRight text-sm sm:text-lg text-white z-20 px-10 sm:px-96 text-center mb-5 sm:mb-10 leading-8"> Partnering with trusted suppliers to ensure quality and reliability in every project. </p>`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("services"),
          type: "button",
          "data-wow-delay": "6s",
          class: "wow animate__rubberBand z-20 mt-5 border-2 border-primary hover:bg-primary hover:text-black px-5 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Learn More <i class="ml-2 fas fa-up-right"${_scopeId}></i>`);
            } else {
              return [
                createTextVNode(" Learn More "),
                createVNode("i", { class: "ml-2 fas fa-up-right" })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (slide.value == 5) {
        _push(`<div class="duration-700 ease-in-out"><img src="img/procur.jpg" class="object-cover absolute block w-full h-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="..."><div class="absolute z-10 flex flex-col items-center justify-center h-full w-full"><div class="absolute top-0 left-0 w-full h-full bg-black opacity-60"></div><h2 data-wow-duration="2s" class="wow animate__backInRight text-xl sm:text-5xl font-bold text-white z-20 mb-5 sm:mb-10">Procurement &amp; <br> Project Management </h2><p class="wow animate__backInRight text-sm sm:text-lg text-white z-20 px-10 sm:px-96 text-center mb-5 sm:mb-10 leading-8"> Let us orchestrate the complex symphony of logistics, timelines, and seamless execution, so you can focus on your passion while we bring your vision to life. </p><button type="button" data-wow-delay="6s" class="wow animate__rubberBand z-20 mt-5 border-2 border-primary hover:bg-primary hover:text-black px-5 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"> Learn More <i class="ml-2 fas fa-up-right"></i></button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><button type="button" class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-prev><span class="inline-flex items-center justify-center w-8 h-8 sm:w-14 sm:h-14 rounded-full bg-primary dark:bg-gray-800/30 group-hover:bg-black dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none"><i class="fas fa-angle-left sm:fa-2xl text-white"></i><span class="sr-only">Previous</span></span></button><button type="button" class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-next><span class="inline-flex items-center justify-center w-8 h-8 sm:w-14 sm:h-14 rounded-full bg-primary dark:bg-gray-800/30 group-hover:bg-black dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none"><i class="fas fa-angle-right sm:fa-2xl text-white"></i><span class="sr-only">Next</span></span></button></div></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Client/Carousel.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="overflow-hidden bg-white py-10 sm:py-32"><div class="mx-auto max-w-7xl px-6 lg:flex lg:px-8"><div class="mx-auto grid max-w-2xl grid-cols-1 gap-x-12 gap-y-16 lg:mx-0 lg:min-w-full lg:max-w-none lg:flex-none lg:gap-y-8"><div class="lg:col-end-1 lg:w-full lg:max-w-3xl lg:pb-8"><h2 data-wow-delay="1s" data-wow-duration="1s" class="wow animate__lightSpeedInRight text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Why Choose Us?</h2><p data-wow-delay="1s" data-wow-duration="1s" class="wow animate__lightSpeedInLeft mt-6 text-xl leading-10 text-primary font-bold">We are a team that Cares!</p><p class="mt-6 leading-7 text-black font-medium text-sm sm:text-md"> Navigating the complexities of setting up a commercial kitchen can be a daunting task. With countless decisions to make, from design and equipment selection to supplier negotiations and project management, it&#39;s easy to feel overwhelmed. That&#39;s where we come in. At Commercial Kitchens Consultants, we specialize in simplifying the process for you. Our expert team takes the burden off your shoulders, leveraging our industry knowledge and experience to guide you every step of the way. By entrusting your commercial kitchen project to us, you can save valuable time and resources while gaining peace of mind, knowing that you have a dedicated partner who will ensure that your vision becomes a reality. Let us make the process easier for you, so you can focus on what you do best – running your business. </p><div class="mt-12 sm:flex justify-between"><a href="tel:+254717269050" class="group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"><div data-wow-duration="1.5s" data-wow-delay="1.5s" class="wow animate__lightSpeedInLeft h-20 w-20 bg-white rounded group-hover:bg-primary"><i class="fas fa-phone flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white"></i></div><div class="ml-5"><div class=""><h1 data-wow-duration="1s" data-wow-delay="2s" class="wow animate__lightSpeedInLeft font-bold text-2xl leading-10 text-primary">Get Expert Advice</h1><h5 data-wow-duration="1s" data-wow-delay="2.5s" class="wow animate__lightSpeedInLeft font-bold leading-10 text-lg sm:text-2xl"> +254 115 511 079</h5></div></div></a><a href="mailto:info@commercialkitchen.co.ke" class="group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex"><div data-wow-duration="1.5s" data-wow-delay="1s" class="wow animate__lightSpeedInLeft h-20 w-20 bg-white rounded group-hover:bg-primary"><i class="fas fa-envelope flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white"></i></div><div class="ml-5"><div class=""><h1 data-wow-duration="1s" data-wow-delay="1.5s" class="wow animate__lightSpeedInLeft font-bold text-2xl leading-10 text-primary">Get Expert Advice</h1><h5 data-wow-duration="1s" data-wow-delay="2s" class="wow animate__lightSpeedInLeft font-bold leading-10 text-sm sm:text-xl"> info@commercialkitchen.co.ke</h5></div></div></a></div></div><div class="flex flex-wrap items-start justify-end gap-6 sm:gap-8 lg:contents"><div class="w-0 flex-auto lg:ml-auto lg:w-auto lg:flex-none lg:self-end"><img src="/img/y.jpg" alt="" class="transform -translate-x-64 sm:-translate-x-5 ring-2 ring-primary aspect-[7/5] w-[37rem] max-w-none rounded-2xl bg-gray-50 object-cover h-[600px]"></div></div></div></div></div></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Client/Choose.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const Choose = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$3 = {
  __name: "Who",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="bg-primary relative z-20"><div class="absolute top-0 left-0 w-full h-full bg-black opacity-10 z-10"></div><div class="px-6 py-10 sm:px-6 sm:py-16 lg:px-8"><div class="mx-auto max-w-6xl text-center"><h2 data-wow-duration="2s" class="wow animate__rubberBand text-3xl font-bold tracking-tight text-black sm:text-4xl"> Who we are </h2><p data-wow-duration="1s" class="wow animate__lightSpeedInRight font-medium text-left mx-auto mt-6 max-w-6xl text-sm sm:text-md sm:text-lg leading-8 text-white"> At Commercial Kitchens Consultants, we are passionate about supporting the growth and success of the hospitality industry. With years of experience in the field, we understand the unique challenges faced by investors when it comes to commercial kitchens. Our dedicated team of experts is here to guide you through every step of the process, from design to installation, ensuring that your kitchen meets your needs, budget, and timeline. Trust us to be your trusted partner in creating efficient, functional, and inspiring commercial kitchen spaces that drive your business forward. </p></div></div></div></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Client/Who.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="bg-black py-14 sm:py-32"><div class="mx-auto max-w-[100vw] px-6 lg:px-8"><div class="mx-auto max-w-4xl text-center"><h2 class="text-base font-semibold leading-7 text-primary">This is how we can work together</h2><p data-wow-duration="1.5s" class="wow animate__rubberBand mt-2 text-4xl font-bold tracking-tight text-white sm:text-5xl">Our Process</p></div><div class="isolate mx-auto mt-10 grid max-w-md grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-3"><div data-wow-delay="1s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-messages-question group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary"> Initial Consultation </span></p><p class="mt-4 text-xs sm:text-sm leading-6 text-white"> Picture this: you, us, and a cup of coffee. During our initial consultation, we dive deep into your dreams, your vision, and even your secret recipe aspirations. We listen, we learn, and together, we craft a plan that aligns with your goals, budget, and unique needs. Consider us your kitchen confidantes, ready to guide you every step of the way </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 1 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="1.5s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-compass-drafting group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Design and Layout</span></p><p class="mt-4 text-xs sm:text-sm leading-6 text-white"> Based on the brief gotten during the initial consultation, our experienced designers will work closely with you to create a customized kitchen design. We consider factors such as workflow optimization, space utilization, and regulatory compliance to ensure an efficient and functional design. We leverage our expertise to help you maximize productivity, create ergonomic workstations, and optimize the overall efficiency of your kitchen space. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 2 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="2s" class="wow animate__backInUp elative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-ballot-check group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Equipment Selection</span></p><p class="mb-16 mt-4 text-xs sm:text-sm leading-6 text-white"> Once we have agreed on the kitchen layout, we proceed to equipment selection. Choosing the right equipment is crucial for the success of your commercial kitchen. With our deep knowledge of the industry, we assist you in selecting the most suitable equipment for your specific needs. We will take into account your menu requirements, capacity needs, budget constraints, and quality standards to recommend reliable and high-performing equipment that aligns with your business goals. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 3 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="1s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-users group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Supplier Qualification &amp; Procurement </span></p><p class="mt-4 text-xs sm:text-sm leading-6 text-white"> Navigating the multitude of suppliers can be overwhelming. As part of our comprehensive service, we shall handle the supplier qualification process for you. We will thoroughly evaluate and prequalify suppliers based on their reputation, product quality, pricing, and customer service. Once the supplier is selected, we manage the procurement process to ensure a seamless experience, including negotiating pricing, handling order placement, and coordinating logistics for timely delivery of the equipment. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 4 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="1.5s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-user-helmet-safety group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Project Management </span></p><p class="mt-4 text-xs sm:text-sm leading-6 text-white"> We understand that overseeing a commercial kitchen project can be challenging, especially when coordinating multiple stakeholders. As your dedicated project managers, we take on the responsibility of managing the entire project on your behalf. We coordinate with suppliers, contractors, and other involved parties to ensure smooth progress, timely execution, and adherence to quality standards. Our meticulous project management approach allows you to focus on your core business while we handle the complexities of the project. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 5 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="2s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-wrench group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Installation and Testing </span></p><p class="mb-20 mt-4 text-xs sm:text-sm leading-6 text-white"> Efficient and accurate installation of equipment is vital to the functionality and safety of your commercial kitchen. Our team of experts will work closely with the selected suppliers and contractors to coordinate the installation process. We ensure that all equipment is installed properly and in compliance with relevant regulations and industry standards. Rigorous testing and quality checks are conducted to ensure that each piece of equipment operates seamlessly and meets your requirements. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 6 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="1s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-folder-open group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Handover &amp; Documentation </span></p><p class="mt-4 text-xs sm:text-sm leading-6 text-white"> Once the installation is complete, we facilitate a comprehensive handover process. We ensure that you are provided with all relevant documentation, including warranties, operating manuals, and maintenance guidelines, ensuring that you have the necessary information to operate and maintain your commercial kitchen effectively. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 7 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="1.5s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-users-gear group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Maintenance Contracts </span></p><p class="mt-4 text-xs sm:text-sm leading-6 text-white"> Our relationship doesn&#39;t end with the completion of your kitchen. We&#39;re committed to your ongoing success We work closely with the awarded suppliers to ensure that they offer comprehensive after-sales support and maintenance services. We help facilitate the process of signing the maintenance contract, ensuring that you have a dedicated agreement in place for regular upkeep and servicing of your commercial kitchen. This ensures that your equipment remains in excellent condition and minimizes any potential downtime. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 8 <i class="fas fa-angles-right text-primary"></i></a></div><div data-wow-delay="2s" class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group"><div class="flex items-center justify-between gap-x-4"><h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white"><i class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-comment-smile group-hover:text-white text-primary fa-2xl"></i></h3></div><p class="mt-6 flex items-baseline gap-x-1"><span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Customer Satisfaction and Success </span></p><p class="pb-16 mt-4 text-xs sm:text-sm leading-6 text-white"> We measure our success by your satisfaction. After completing the installation and ensuring everything is in perfect working order, we take a moment to celebrate your kitchen triumph. Your delight and happiness are our greatest rewards. We make sure you&#39;re fully satisfied with your new, fully functional kitchen, ready to create memorable experiences and drive your business forward. Your success is our ultimate validation, and we&#39;re proud to have played a part in making your kitchen dreams come true. </p><a href="#" aria-describedby="tier-freelancer" class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white"> Step 9 </a></div></div></div></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Client/Process.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const Process = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="relative isolate bg-white pb-32 pt-24 sm:pt-32"><div class="absolute inset-x-0 top-1/2 -z-10 -translate-y-1/2 transform-gpu overflow-hidden opacity-30 blur-3xl" aria-hidden="true"><div class="ml-[max(50%,38rem)] aspect-[1313/771] w-[82.0625rem] bg-gradient-to-tr from-[#f97316] to-[#000]" style="${ssrRenderStyle({ "clip-path": "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)" })}"></div></div><div class="absolute inset-x-0 top-0 -z-10 flex transform-gpu overflow-hidden pt-32 opacity-25 blur-3xl sm:pt-40 xl:justify-end" aria-hidden="true"><div class="ml-[-22rem] aspect-[1313/771] w-[82.0625rem] flex-none origin-top-right rotate-[30deg] bg-gradient-to-tr from-[#f97316] to-[#000] xl:ml-0 xl:mr-[calc(50%-12rem)]" style="${ssrRenderStyle({ "clip-path": "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)" })}"></div></div><div class="mx-auto max-w-7xl px-6 lg:px-2"><div class="mx-auto max-w-xl text-center"><h2 class="text-lg font-semibold leading-8 tracking-tight text-primary">Testimonials</h2><p data-wow-duration="1.5s" class="wow animate__rubberBand mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"> What our clients are saying</p></div><div class="mx-auto mt-16 grid max-w-7xl grid-cols-1 grid-rows-1 gap-8 text-sm leading-6 text-gray-900 sm:mt-20 sm:grid-cols-2 xl:mx-0 xl:max-w-none xl:grid-flow-col xl:grid-cols-4"><div class="space-y-2 xl:contents xl:space-y-0"><div data-wow-delay="0.5s" class="wow animate__shakeX space-y-8 xl:row-span-2"><figure class="mt-1 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary"><blockquote class="text-black font-semibold"><p>“I had the pleasure of working with Commercial Kitchens Consultants on our restaurant project, and I couldn&#39;t be more impressed. Despite my frequent travels in and out of the country, they managed the project seamlessly. From kitchen design to equipment selection, their expertise and attention to detail were exceptional. Thanks to their dedication and professionalism, Golden Stool now has a functional kitchen that perfectly complements our menu”</p></blockquote><figcaption class="mt-6 flex items-center gap-x-4"><img class="h-10 w-10 rounded-full bg-gray-50" src="https://goldenstoolkitchen.com/wp-content/uploads/2022/01/golden-logo.svg" alt=""><div><div class="font-semibold">Martin Yeboha</div><div class="text-primary">Golden Stool Restaurant</div></div></figcaption></figure></div><div data-wow-delay="1s" class="wow animate__shakeX space-y-8 xl:row-start-1"><figure class="mt-14 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary"><blockquote class="text-black font-semibold"><p>“We had strict timelines to upgrade our cafe&#39;s kitchen. The team displayed excellent project management skills and attention to detail. They listened to our requirements and provided valuable recommendations. Thanks to their expertise, our kitchen is now more efficient and functional. I would highly recommend their services.&quot;”</p></blockquote><figcaption class="mt-6 flex items-center gap-x-4"><img class="h-10 w-10 rounded-full bg-gray-50" src="/img/db.jpg" alt=""><div><div class="font-semibold">Gideon</div><div class="text-primary">Dohn Café</div></div></figcaption></figure></div></div><div class="space-y-8 xl:contents xl:space-y-0"><div data-wow-delay="1.5s" class="wow animate__shakeX space-y-8 xl:row-start-1"><figure class="rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary"><blockquote class="text-black font-semibold"><p>“ I can confidently recommend Commercial Kitchens Consultants for their excellent service. Throughout the process, they provided valuable guidance and support. Despite my busy schedule, they managed the project effectively, ensuring we got a kitchen that meets our needs. Their expertise and transparency was highly appreciated”</p></blockquote><figcaption class="mt-6 flex items-center gap-x-4"><img class="h-10 w-10 rounded-full bg-gray-50" src="https://media.istockphoto.com/id/1415397771/vector/teapot-logo-teahouse-logo-design.jpg?s=612x612&amp;w=0&amp;k=20&amp;c=eOa2TDw60gIS3x-pfZM0Wnli048xnproGh1Ic-Xfzhg=" alt=""><div><div class="font-semibold">Tinega</div><div class="text-primary">Fahari Tea Restaurant</div></div></figcaption></figure></div><div data-wow-delay="2s" class="wow animate__shakeX space-y-8 xl:row-span-2"><figure class="mt-20 rounded-2xl bg-white p-6 shadow-lg ring-1 ring-primary"><blockquote class="text-black font-semibold"><p>“ This being our first restaurant we had no knowledge of the process and what we needed for the kitchen set up. The team at CKC were very helpful and they provided guidance throughout the process. They understood our budget constraints and they were able to match us up with reliable suppliers and we truly got value for our money. Would highly recommend them.”</p></blockquote><figcaption class="mt-6 flex items-center gap-x-4"><img class="h-10 w-10 rounded-full bg-gray-50" src="https://media-cdn.grubhub.com/image/upload/d_search:browse-images:default.jpg/w_300,q_100,fl_lossy,dpr_2.0,c_fit,f_auto,h_300/qekxwuihiwpua1rhmxzw" alt=""><div><div class="font-semibold">Mukhtar</div><div class="text-primary">Saffron Grill</div></div></figcaption></figure></div></div></div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Client/Testimonial.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Testimonial = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "Landing",
  __ssrInlineRender: true,
  props: {
    // canLogin: Boolean,
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Commercial Kitchen Consultants in Kenya - Commercial Kitchen Equipment" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$6, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$5, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(Choose, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(Process, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(Testimonial, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_sfc_main$5),
              createVNode(_sfc_main$3),
              createVNode(Choose),
              createVNode(Process),
              createVNode(Testimonial)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Client/Landing.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
