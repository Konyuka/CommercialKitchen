import { onMounted, ref, unref, withCtx, createVNode, openBlock, createBlock, createTextVNode, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./ClientLayout-e3ead9de.js";
import axios from "axios";
import moment from "moment";
import "wow.js";
const _sfc_main = {
  __name: "Media",
  __ssrInlineRender: true,
  setup(__props) {
    onMounted(() => {
      getBlog();
    });
    const blogs = ref(null);
    const getBlog = () => {
      axios.get("/api/get-published-blogs").then((res) => {
        blogs.value = res.data;
      }).catch((err) => {
        console.log(err);
      });
    };
    const formatDate = (date) => {
      return moment(date).format("MMM Do YY");
    };
    const detailsPage = (blog) => {
      const title = blog.title;
      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const trimmedSlug = slug.replace(/^-+|-+$/g, "");
      const finalSlug = trimmedSlug.replace(/-{2,}/g, "-");
      router.post(route("blog.details", finalSlug), {
        blogId: blog.id
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Blogs & Gallery" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div${_scopeId}><div class="bg-white py-10 sm:py-20"${_scopeId}><div class="mx-auto max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-2xl text-center"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-primary sm:text-4xl"${_scopeId}>From our blogs</h2><p class="mt-2 text-lg leading-8 text-gray-600"${_scopeId}>Learn how to grow your business with our expert content.</p></div>`);
            if (!((_a = blogs.value) == null ? void 0 : _a.length)) {
              _push2(`<div class="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3"${_scopeId}><article class="transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between"${_scopeId}><div class="relative w-full"${_scopeId}><img src="https://www.samtell.com/hubfs/Blogs/SamTell-Blog-Restaurant-Kitchen-Design-Tips-to-Maximize-Functionality.jpg" alt="" class="aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"${_scopeId}><div class="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10"${_scopeId}></div></div><div class="max-w-xl"${_scopeId}><div class="mt-8 flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Mar 16, 2023</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Marketing</a></div><div class="group relative"${_scopeId}><h3 class="mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> The Evolution of Commercial Kitchen Trends </a></h3><p class="mt-5 line-clamp-4 text-sm leading-6 text-black font-medium"${_scopeId}> Setting up a restaurant can be an exciting endeavor, but it often comes with significant financial challenges. However, with the right budget-friendly strategies, aspiring restaurant owners can turn their dreams into reality without breaking the bank. In this blog post, we will explore a range of practical tips and cost-saving measures to help you set up a restaurant on a budget. </p></div></div></article><article class="transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between"${_scopeId}><div class="relative w-full"${_scopeId}><img src="https://www.cadpro.com/wp-content/uploads/2013/08/Restaurant-Floor-Plan.png" alt="" class="aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"${_scopeId}><div class="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10"${_scopeId}></div></div><div class="max-w-xl"${_scopeId}><div class="mt-8 flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Mar 16, 2023</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Marketing</a></div><div class="group relative"${_scopeId}><h3 class="mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Trends in Commercial Kitchen Designs </a></h3><p class="mt-5 line-clamp-4 text-sm leading-6 text-black font-medium"${_scopeId}> Commercial kitchen design plays a crucial role in the success of any foodservice establishment. From restaurants and hotels to catering companies and ghost kitchens, a well-designed kitchen can significantly impact efficiency, productivity, and customer satisfaction. </p></div></div></article><article class="transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between"${_scopeId}><div class="relative w-full"${_scopeId}><img src="https://www.samtell.com/hubfs/Blogs/SamTell-Blog-Restaurant-Kitchen-Design-Tips-to-Maximize-Functionality.jpg" alt="" class="aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"${_scopeId}><div class="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10"${_scopeId}></div></div><div class="max-w-xl"${_scopeId}><div class="mt-8 flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Mar 16, 2023</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Marketing</a></div><div class="group relative"${_scopeId}><h3 class="mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> The Evolution of Commercial Kitchen Trends </a></h3><p class="mt-5 line-clamp-4 text-sm leading-6 text-black font-medium"${_scopeId}> Setting up a restaurant can be an exciting endeavor, but it often comes with significant financial challenges. However, with the right budget-friendly strategies, aspiring restaurant owners can turn their dreams into reality without breaking the bank. In this blog post, we will explore a range of practical tips and cost-saving measures to help you set up a restaurant on a budget. </p></div></div></article></div>`);
            } else {
              _push2(`<div class="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3"${_scopeId}><!--[-->`);
              ssrRenderList(blogs.value, (blog) => {
                _push2(`<article class="transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between"${_scopeId}><div class="relative w-full"${_scopeId}><img${ssrRenderAttr("src", blog.cover)} alt="" class="aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"${_scopeId}><div class="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10"${_scopeId}></div></div><div class="max-w-xl"${_scopeId}><div class="mt-8 flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>${ssrInterpolate(formatDate(blog.created_at))}</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>${ssrInterpolate(blog.categories.name)}</a></div><div class="group relative"${_scopeId}><h3 class="mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> ${ssrInterpolate(blog.title)}</a></h3><p class="mt-5 line-clamp-4 text-sm leading-6 text-black font-medium"${_scopeId}>${ssrInterpolate(blog.excerpt)}</p></div></div></article>`);
              });
              _push2(`<!--]--></div>`);
            }
            _push2(`</div></div><div class="bg-white py-10 sm:pb-20"${_scopeId}><div class="mx-auto max-w-7xl px-6 lg:px-8"${_scopeId}><div class="mx-auto max-w-7xl lg:mx-0 text-center"${_scopeId}><h2 class="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl text-primary"${_scopeId}>Latest News </h2><p class="mt-2 text-lg leading-8 text-gray-600"${_scopeId}> Get the lastest industry insight and news </p></div><div class="mx-auto mt-10 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 border-t border-gray-200 pt-10 sm:mt-16 sm:pt-16 lg:mx-0 lg:max-w-none lg:grid-cols-3"${_scopeId}><article class="flex max-w-xl flex-col items-start justify-between"${_scopeId}><div class="flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Aug 16, 2023</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Food</a></div><div class="group relative"${_scopeId}><h3 class="text-primary mt-3 text-md capitalize font-semibold leading-6 text-gray-900 group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> The premier international exihibition for food </a></h3><p class="mt-5 line-clamp-4 text-sm leading-6 text-gray-600"${_scopeId}> he Kenyan Hospitality Event (KHE) is the biggest exhibition serving the hospitality industry across East Africa. With its next edition taking place in September 2023 at the Sarit Centre in Nairobi, Kenya </p></div><div class="relative mt-8 flex items-center gap-x-4"${_scopeId}><div class="text-sm leading-6"${_scopeId}><p class="text-md hover:text-primary font-semibold text-gray-900"${_scopeId}><a href="https://www.kenyanfoodevent.com/kenyan-hospitality-event" target="_blank"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Read news article <i class="ml-2 fas fa-up-right"${_scopeId}></i></a></p></div></div></article><article class="flex max-w-xl flex-col items-start justify-between"${_scopeId}><div class="flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Aug 22, 2023</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Hospitality</a></div><div class="group relative"${_scopeId}><h3 class="text-primary mt-3 text-md capitalize font-semibold leading-6 text-gray-900 group-hover:text-gray-600"${_scopeId}><a href="#" target="_blank"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Kenya&#39;s hospitality recovery in 2022 </a></h3><p class="mt-5 line-clamp-4 text-sm leading-6 text-gray-600"${_scopeId}> Kenya’s hospitality sector is recovering steadily despite the many challenges experienced in the last 12 months, including inflationary pressures and stiff competition. Several factors have helped to cushion the sector against challenges since the start of the Covid-19 pandemic in 2020. </p></div><div class="relative mt-8 flex items-center gap-x-4"${_scopeId}><div class="text-sm leading-6"${_scopeId}><p class="text-md hover:text-primary font-semibold text-gray-900"${_scopeId}><a href="https://www.businessdailyafrica.com/bd/opinion-analysis/columnists/kenya-s-hospitality-rides-out-storm-to-recovery-in-2022--4053846" target="_blank"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Read news article <i class="ml-2 fas fa-up-right"${_scopeId}></i></a></p></div></div></article><article class="flex max-w-xl flex-col items-start justify-between"${_scopeId}><div class="flex items-center gap-x-4 text-xs"${_scopeId}><time datetime="2020-03-16" class="text-gray-500"${_scopeId}>Sept 2, 2023</time><a href="#" class="relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"${_scopeId}>Places</a></div><div class="group relative"${_scopeId}><h3 class="text-primary mt-3 text-md capitalize font-semibold leading-6 text-gray-900 group-hover:text-gray-600"${_scopeId}><a href="#"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> The best restaurants and bars in Nairobi </a></h3><p class="mt-5 line-clamp-4 text-sm leading-6 text-gray-600"${_scopeId}> 50 Best Discovery, an exciting database for eating and drinking, operates as an extension of the annual 50 Best rankings of restaurants and bars. The venues featured on 50 Best Discovery have all received votes from the experts who create the rankings </p></div><div class="relative mt-8 flex items-center gap-x-4"${_scopeId}><div class="text-sm leading-6"${_scopeId}><p class="text-md hover:text-primary font-semibold text-gray-900"${_scopeId}><a href="https://www.theworlds50best.com/discovery/sitemap/kenya/nairobi" target="_blank"${_scopeId}><span class="absolute inset-0"${_scopeId}></span> Read news article <i class="ml-2 fas fa-up-right"${_scopeId}></i></a></p></div></div></article></div></div></div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "bg-white py-10 sm:py-20" }, [
                  createVNode("div", { class: "mx-auto max-w-7xl px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-2xl text-center" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-primary sm:text-4xl" }, "From our blogs"),
                      createVNode("p", { class: "mt-2 text-lg leading-8 text-gray-600" }, "Learn how to grow your business with our expert content.")
                    ]),
                    !((_b = blogs.value) == null ? void 0 : _b.length) ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3"
                    }, [
                      createVNode("article", { class: "transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between" }, [
                        createVNode("div", { class: "relative w-full" }, [
                          createVNode("img", {
                            src: "https://www.samtell.com/hubfs/Blogs/SamTell-Blog-Restaurant-Kitchen-Design-Tips-to-Maximize-Functionality.jpg",
                            alt: "",
                            class: "aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"
                          }),
                          createVNode("div", { class: "absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" })
                        ]),
                        createVNode("div", { class: "max-w-xl" }, [
                          createVNode("div", { class: "mt-8 flex items-center gap-x-4 text-xs" }, [
                            createVNode("time", {
                              datetime: "2020-03-16",
                              class: "text-gray-500"
                            }, "Mar 16, 2023"),
                            createVNode("a", {
                              href: "#",
                              class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                            }, "Marketing")
                          ]),
                          createVNode("div", { class: "group relative" }, [
                            createVNode("h3", { class: "mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600" }, [
                              createVNode("a", { href: "#" }, [
                                createVNode("span", { class: "absolute inset-0" }),
                                createTextVNode(" The Evolution of Commercial Kitchen Trends ")
                              ])
                            ]),
                            createVNode("p", { class: "mt-5 line-clamp-4 text-sm leading-6 text-black font-medium" }, " Setting up a restaurant can be an exciting endeavor, but it often comes with significant financial challenges. However, with the right budget-friendly strategies, aspiring restaurant owners can turn their dreams into reality without breaking the bank. In this blog post, we will explore a range of practical tips and cost-saving measures to help you set up a restaurant on a budget. ")
                          ])
                        ])
                      ]),
                      createVNode("article", { class: "transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between" }, [
                        createVNode("div", { class: "relative w-full" }, [
                          createVNode("img", {
                            src: "https://www.cadpro.com/wp-content/uploads/2013/08/Restaurant-Floor-Plan.png",
                            alt: "",
                            class: "aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"
                          }),
                          createVNode("div", { class: "absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" })
                        ]),
                        createVNode("div", { class: "max-w-xl" }, [
                          createVNode("div", { class: "mt-8 flex items-center gap-x-4 text-xs" }, [
                            createVNode("time", {
                              datetime: "2020-03-16",
                              class: "text-gray-500"
                            }, "Mar 16, 2023"),
                            createVNode("a", {
                              href: "#",
                              class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                            }, "Marketing")
                          ]),
                          createVNode("div", { class: "group relative" }, [
                            createVNode("h3", { class: "mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600" }, [
                              createVNode("a", { href: "#" }, [
                                createVNode("span", { class: "absolute inset-0" }),
                                createTextVNode(" Trends in Commercial Kitchen Designs ")
                              ])
                            ]),
                            createVNode("p", { class: "mt-5 line-clamp-4 text-sm leading-6 text-black font-medium" }, " Commercial kitchen design plays a crucial role in the success of any foodservice establishment. From restaurants and hotels to catering companies and ghost kitchens, a well-designed kitchen can significantly impact efficiency, productivity, and customer satisfaction. ")
                          ])
                        ])
                      ]),
                      createVNode("article", { class: "transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between" }, [
                        createVNode("div", { class: "relative w-full" }, [
                          createVNode("img", {
                            src: "https://www.samtell.com/hubfs/Blogs/SamTell-Blog-Restaurant-Kitchen-Design-Tips-to-Maximize-Functionality.jpg",
                            alt: "",
                            class: "aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"
                          }),
                          createVNode("div", { class: "absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" })
                        ]),
                        createVNode("div", { class: "max-w-xl" }, [
                          createVNode("div", { class: "mt-8 flex items-center gap-x-4 text-xs" }, [
                            createVNode("time", {
                              datetime: "2020-03-16",
                              class: "text-gray-500"
                            }, "Mar 16, 2023"),
                            createVNode("a", {
                              href: "#",
                              class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                            }, "Marketing")
                          ]),
                          createVNode("div", { class: "group relative" }, [
                            createVNode("h3", { class: "mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600" }, [
                              createVNode("a", { href: "#" }, [
                                createVNode("span", { class: "absolute inset-0" }),
                                createTextVNode(" The Evolution of Commercial Kitchen Trends ")
                              ])
                            ]),
                            createVNode("p", { class: "mt-5 line-clamp-4 text-sm leading-6 text-black font-medium" }, " Setting up a restaurant can be an exciting endeavor, but it often comes with significant financial challenges. However, with the right budget-friendly strategies, aspiring restaurant owners can turn their dreams into reality without breaking the bank. In this blog post, we will explore a range of practical tips and cost-saving measures to help you set up a restaurant on a budget. ")
                          ])
                        ])
                      ])
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3"
                    }, [
                      (openBlock(true), createBlock(Fragment, null, renderList(blogs.value, (blog) => {
                        return openBlock(), createBlock("article", {
                          onClick: ($event) => detailsPage(blog),
                          class: "transform transition hover:scale-95 duration-700 ease-in-out hover:cursor-pointer flex flex-col items-start justify-between"
                        }, [
                          createVNode("div", { class: "relative w-full" }, [
                            createVNode("img", {
                              src: blog.cover,
                              alt: "",
                              class: "aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]"
                            }, null, 8, ["src"]),
                            createVNode("div", { class: "absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" })
                          ]),
                          createVNode("div", { class: "max-w-xl" }, [
                            createVNode("div", { class: "mt-8 flex items-center gap-x-4 text-xs" }, [
                              createVNode("time", {
                                datetime: "2020-03-16",
                                class: "text-gray-500"
                              }, toDisplayString(formatDate(blog.created_at)), 1),
                              createVNode("a", {
                                href: "#",
                                class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                              }, toDisplayString(blog.categories.name), 1)
                            ]),
                            createVNode("div", { class: "group relative" }, [
                              createVNode("h3", { class: "mt-3 text-md font-semibold leading-6 text-primary group-hover:text-gray-600" }, [
                                createVNode("a", { href: "#" }, [
                                  createVNode("span", { class: "absolute inset-0" }),
                                  createTextVNode(" " + toDisplayString(blog.title), 1)
                                ])
                              ]),
                              createVNode("p", { class: "mt-5 line-clamp-4 text-sm leading-6 text-black font-medium" }, toDisplayString(blog.excerpt), 1)
                            ])
                          ])
                        ], 8, ["onClick"]);
                      }), 256))
                    ]))
                  ])
                ]),
                createVNode("div", { class: "bg-white py-10 sm:pb-20" }, [
                  createVNode("div", { class: "mx-auto max-w-7xl px-6 lg:px-8" }, [
                    createVNode("div", { class: "mx-auto max-w-7xl lg:mx-0 text-center" }, [
                      createVNode("h2", { class: "text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl text-primary" }, "Latest News "),
                      createVNode("p", { class: "mt-2 text-lg leading-8 text-gray-600" }, " Get the lastest industry insight and news ")
                    ]),
                    createVNode("div", { class: "mx-auto mt-10 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 border-t border-gray-200 pt-10 sm:mt-16 sm:pt-16 lg:mx-0 lg:max-w-none lg:grid-cols-3" }, [
                      createVNode("article", { class: "flex max-w-xl flex-col items-start justify-between" }, [
                        createVNode("div", { class: "flex items-center gap-x-4 text-xs" }, [
                          createVNode("time", {
                            datetime: "2020-03-16",
                            class: "text-gray-500"
                          }, "Aug 16, 2023"),
                          createVNode("a", {
                            href: "#",
                            class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                          }, "Food")
                        ]),
                        createVNode("div", { class: "group relative" }, [
                          createVNode("h3", { class: "text-primary mt-3 text-md capitalize font-semibold leading-6 text-gray-900 group-hover:text-gray-600" }, [
                            createVNode("a", { href: "#" }, [
                              createVNode("span", { class: "absolute inset-0" }),
                              createTextVNode(" The premier international exihibition for food ")
                            ])
                          ]),
                          createVNode("p", { class: "mt-5 line-clamp-4 text-sm leading-6 text-gray-600" }, " he Kenyan Hospitality Event (KHE) is the biggest exhibition serving the hospitality industry across East Africa. With its next edition taking place in September 2023 at the Sarit Centre in Nairobi, Kenya ")
                        ]),
                        createVNode("div", { class: "relative mt-8 flex items-center gap-x-4" }, [
                          createVNode("div", { class: "text-sm leading-6" }, [
                            createVNode("p", { class: "text-md hover:text-primary font-semibold text-gray-900" }, [
                              createVNode("a", {
                                href: "https://www.kenyanfoodevent.com/kenyan-hospitality-event",
                                target: "_blank"
                              }, [
                                createVNode("span", { class: "absolute inset-0" }),
                                createTextVNode(" Read news article "),
                                createVNode("i", { class: "ml-2 fas fa-up-right" })
                              ])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("article", { class: "flex max-w-xl flex-col items-start justify-between" }, [
                        createVNode("div", { class: "flex items-center gap-x-4 text-xs" }, [
                          createVNode("time", {
                            datetime: "2020-03-16",
                            class: "text-gray-500"
                          }, "Aug 22, 2023"),
                          createVNode("a", {
                            href: "#",
                            class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                          }, "Hospitality")
                        ]),
                        createVNode("div", { class: "group relative" }, [
                          createVNode("h3", { class: "text-primary mt-3 text-md capitalize font-semibold leading-6 text-gray-900 group-hover:text-gray-600" }, [
                            createVNode("a", {
                              href: "#",
                              target: "_blank"
                            }, [
                              createVNode("span", { class: "absolute inset-0" }),
                              createTextVNode(" Kenya's hospitality recovery in 2022 ")
                            ])
                          ]),
                          createVNode("p", { class: "mt-5 line-clamp-4 text-sm leading-6 text-gray-600" }, " Kenya’s hospitality sector is recovering steadily despite the many challenges experienced in the last 12 months, including inflationary pressures and stiff competition. Several factors have helped to cushion the sector against challenges since the start of the Covid-19 pandemic in 2020. ")
                        ]),
                        createVNode("div", { class: "relative mt-8 flex items-center gap-x-4" }, [
                          createVNode("div", { class: "text-sm leading-6" }, [
                            createVNode("p", { class: "text-md hover:text-primary font-semibold text-gray-900" }, [
                              createVNode("a", {
                                href: "https://www.businessdailyafrica.com/bd/opinion-analysis/columnists/kenya-s-hospitality-rides-out-storm-to-recovery-in-2022--4053846",
                                target: "_blank"
                              }, [
                                createVNode("span", { class: "absolute inset-0" }),
                                createTextVNode(" Read news article "),
                                createVNode("i", { class: "ml-2 fas fa-up-right" })
                              ])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("article", { class: "flex max-w-xl flex-col items-start justify-between" }, [
                        createVNode("div", { class: "flex items-center gap-x-4 text-xs" }, [
                          createVNode("time", {
                            datetime: "2020-03-16",
                            class: "text-gray-500"
                          }, "Sept 2, 2023"),
                          createVNode("a", {
                            href: "#",
                            class: "relative z-10 rounded-full bg-gray-50 px-3 py-1.5 font-medium text-gray-600 hover:bg-gray-100"
                          }, "Places")
                        ]),
                        createVNode("div", { class: "group relative" }, [
                          createVNode("h3", { class: "text-primary mt-3 text-md capitalize font-semibold leading-6 text-gray-900 group-hover:text-gray-600" }, [
                            createVNode("a", { href: "#" }, [
                              createVNode("span", { class: "absolute inset-0" }),
                              createTextVNode(" The best restaurants and bars in Nairobi ")
                            ])
                          ]),
                          createVNode("p", { class: "mt-5 line-clamp-4 text-sm leading-6 text-gray-600" }, " 50 Best Discovery, an exciting database for eating and drinking, operates as an extension of the annual 50 Best rankings of restaurants and bars. The venues featured on 50 Best Discovery have all received votes from the experts who create the rankings ")
                        ]),
                        createVNode("div", { class: "relative mt-8 flex items-center gap-x-4" }, [
                          createVNode("div", { class: "text-sm leading-6" }, [
                            createVNode("p", { class: "text-md hover:text-primary font-semibold text-gray-900" }, [
                              createVNode("a", {
                                href: "https://www.theworlds50best.com/discovery/sitemap/kenya/nairobi",
                                target: "_blank"
                              }, [
                                createVNode("span", { class: "absolute inset-0" }),
                                createTextVNode(" Read news article "),
                                createVNode("i", { class: "ml-2 fas fa-up-right" })
                              ])
                            ])
                          ])
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Client/Media.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
