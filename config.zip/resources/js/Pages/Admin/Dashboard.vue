<script setup>
import AdminLayout from '@/Layouts/AdminLayout.vue';

</script>

<template>
    <AdminLayout>

    </AdminLayout>
</template>