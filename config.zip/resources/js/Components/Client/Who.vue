<script setup>
import { Link } from "@inertiajs/vue3";
</script>

<template>
    <div>
        <div class="bg-primary relative z-20">
            <div class="absolute top-0 left-0 w-full h-full bg-black opacity-10 z-10"></div>
            <div class="px-6 py-10 sm:px-6 sm:py-16 lg:px-8">
                <div class=" mx-auto max-w-6xl text-center">
                    <h2 data-wow-duration="2s"
                        class="wow animate__rubberBand text-3xl font-bold tracking-tight text-black sm:text-4xl">
                        Who we are
                    </h2>
                    <p data-wow-duration="1s"
                        class="wow animate__lightSpeedInRight font-medium text-left mx-auto mt-6 max-w-6xl text-sm sm:text-md sm:text-lg leading-8 text-white">
                        At Commercial Kitchens Consultants, we are passionate about supporting the growth and success of the
                        hospitality industry. With years of experience in the field, we understand the unique challenges
                        faced by
                        investors when it comes to commercial kitchens. Our dedicated team of experts is here to guide you
                        through every step of the process, from design to installation, ensuring that your kitchen meets
                        your
                        needs, budget, and timeline. Trust us to be your trusted partner in creating efficient, functional,
                        and
                        inspiring commercial kitchen spaces that drive your business forward.
                    </p>
                    
                    <!-- <div class="z-50 mt-10 flex items-center justify-center gap-x-6">
                        <Link :href="route('contacts')"
                            class="transform transition hover:scale-125 duration-700 ease-in-out bg-black px-10 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white">
                        Inquire
                        </Link>
                    </div> -->

                </div>
            </div>
        </div>
    </div>
</template>