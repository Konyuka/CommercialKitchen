<script setup>

</script>

<template>
    <div>

        <div class="bg-white">
            <div aria-hidden="true" class="relative">
                <img src="/img/ck.jpg"  alt=""
                    class="h-56 w-full object-cover object-center">
                <div class="absolute inset-0 bg-gradient-to-t from-white"></div>
            </div>

            <div class="relative mx-auto -mt-12 max-w-7xl px-4 pb-16 sm:px-6 sm:pb-24 lg:px-8">
                <div class="mx-auto max-w-2xl text-center lg:max-w-4xl">
                    <p  class="mt-4 text-black leading-10 font-bold">Our Services</p>
                    <h2 data-wow-duration="1.5" class="wow animate__rubberBand text-3xl font-bold tracking-tight text-primary sm:text-4xl">What we do</h2>
                </div>

            </div>
        </div>

        <div class="bg-white mb-20">
            <div class="mx-auto max-w-2xl px-4 py-2 sm:px-6 sm:py-2 lg:max-w-7xl lg:px-8">

                <div class="space-y-10">

                    <div class="flex flex-col-reverse lg:grid lg:grid-cols-12 lg:items-center lg:gap-x-8">
                        <div class="mt-6 lg:col-span-5 lg:row-start-1 lg:mt-0 xl:col-span-4 lg:col-start-1">
                            <h3 class="wow animate__lightSpeedInLeft text-lg font-bold text-primary">Kitchen Design & Layout Concepts</h3>
                            <p data-wow-dalay="1s" class="wow animate__lightSpeedInLeft mt-2 text-sm text-black font-medium">
                                Our expertise in kitchen design and layout allows us to create innovative and efficient
                                spaces tailored to
                                your specific needs. We utilize the latest design concepts, considering factors such as
                                workflow
                                optimization, spatial efficiency, and ergonomics. Our team will collaborate closely with
                                you to
                                understand your menu, operational requirements, and desired aesthetic. With a keen eye
                                for detail, we
                                design functional and visually appealing kitchens that enhance productivity, promote
                                safety, and create
                                an optimal working environment for your staff.
                            </p>
                        </div>
                        <div class="flex-auto lg:col-span-7 lg:row-start-1 xl:col-span-8 lg:col-start-6 xl:col-start-5">
                            <div class="aspect-h-2 aspect-w-5 overflow-hidden rounded-lg bg-gray-100">
                                <img src="/img/pic.jpg"
                                    alt="White canvas laptop sleeve with gray felt interior, silver zipper, and tan leather zipper pull."
                                    class="object-cover object-center w-[800px] h-[300px]">
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col-reverse lg:grid lg:grid-cols-12 lg:items-center lg:gap-x-8">
                        <div class="mt-6 lg:col-span-5 lg:row-start-1 lg:mt-0 xl:col-span-4 lg:col-start-8 xl:col-start-9">
                            <h3 class="wow animate__lightSpeedInRight text-lg font-bold text-primary">Equipment Selection</h3>
                            <p data-wow-dalay="1s" class="wow animate__lightSpeedInRight mt-2 text-sm text-black font-medium">
                                Selecting the right equipment is critical for the success of your commercial kitchen.
                                Our in-depth
                                knowledge of the industry and strong supplier partnerships enable us to recommend the
                                most suitable
                                equipment for your specific needs. We consider factors such as menu requirements,
                                production
                                capacity, energy efficiency, durability, and budget constraints. By assessing your
                                unique requirements,
                                we ensure that you invest in high-quality equipment that aligns with your operational
                                goals and
                                maximizes return on investment.
                            </p>
                        </div>
                        <div class="flex-auto lg:col-span-7 lg:row-start-1 xl:col-span-8 lg:col-start-1">
                            <div class="aspect-h-2 aspect-w-5 overflow-hidden rounded-lg bg-gray-100">
                                <img src="/img/es.jpg"
                                    alt="Detail of zipper pull with tan leather and silver rivet."
                                    class="object-cover object-center w-[800px] h-[300px]">
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col-reverse lg:grid lg:grid-cols-12 lg:items-center lg:gap-x-8">
                        <div class="mt-6 lg:col-span-5 lg:row-start-1 lg:mt-0 xl:col-span-4 lg:col-start-1">
                            <h3 class="wow animate__lightSpeedInLeft text-lg font-bold text-primary">Supplier Qualification</h3>
                            <p data-wow-dalay="1s" class="wow animate__lightSpeedInLeft mt-2 text-sm text-black font-medium">
                                Navigating the numerous equipment suppliers in the market can be overwhelming. Our
                                supplier
                                qualification process streamlines the selection and ensures you partner with reputable
                                and reliable
                                suppliers. We conduct thorough assessments of suppliers&#39; track records, product
                                quality, service levels,
                                and pricing structures. By prequalifying suppliers, we help you make informed decisions
                                and mitigate
                                risks, ensuring that you collaborate with suppliers who can meet your specific needs and
                                provide
                                exceptional products and services.
                            </p>
                        </div>
                        <div class="flex-auto lg:col-span-7 lg:row-start-1 xl:col-span-8 lg:col-start-6 xl:col-start-5">
                            <div class="aspect-h-2 aspect-w-5 overflow-hidden rounded-lg bg-gray-100">
                                <img src="/img/sq.jpg"
                                    alt="White canvas laptop sleeve with gray felt interior, silver zipper, and tan leather zipper pull."
                                    class="object-cover object-center w-[800px] h-[300px]">
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col-reverse lg:grid lg:grid-cols-12 lg:items-center lg:gap-x-8">
                        <div class="mt-6 lg:col-span-5 lg:row-start-1 lg:mt-0 xl:col-span-4 lg:col-start-8 xl:col-start-9">
                            <h3 class="wow animate__lightSpeedInRight text-lg font-bold text-primary">Procurement</h3>
                            <p data-wow-dalay="1s" class="wow animate__lightSpeedInRight mt-2 text-sm text-black font-medium">
                                Our team manages the procurement process from start to finish, ensuring a smooth and
                                hassle-free
                                experience for you. We leverage our industry connections and negotiate competitive
                                pricing on your
                                behalf. We handle order placement, manage logistics, and coordinate with suppliers to
                                ensure timely
                                delivery of the equipment. With our expertise in procurement, we minimize delays,
                                facilitate seamless
                                transactions, and ensure that the equipment arrives as scheduled, ready for
                                installation.
                            </p>
                        </div>
                        <div class="flex-auto lg:col-span-7 lg:row-start-1 xl:col-span-8 lg:col-start-1">
                            <div class="aspect-h-2 aspect-w-5 overflow-hidden rounded-lg bg-gray-100">
                                <img src="/img/pro.jpg"
                                    alt="Detail of zipper pull with tan leather and silver rivet."
                                    class="object-cover object-center w-[800px] h-[300px]">
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col-reverse lg:grid lg:grid-cols-12 lg:items-center lg:gap-x-8">
                        <div class="mt-6 lg:col-span-5 lg:row-start-1 lg:mt-0 xl:col-span-4 lg:col-start-1">
                            <h3 class="wow animate__lightSpeedInLeft text-lg font-bold text-primary">Project Management</h3>
                            <p data-wow-dalay="1s" class="wow animate__lightSpeedInLeft mt-2 text-sm text-black font-medium">
                                We understand that managing a commercial kitchen project requires coordination among
                                various
                                stakeholders. As your dedicated project managers, we oversee the entire process, from
                                initial concept to
                                final handover. We handle supplier coordination, timeline management, quality control,
                                and
                                communication with contractors and other parties involved. Our goal is to ensure that
                                your project
                                progresses smoothly, stays on schedule, and meets your expectations in terms of quality,
                                functionality,
                                and budget.
                            </p>
                        </div>
                        <div class="flex-auto lg:col-span-7 lg:row-start-1 xl:col-span-8 lg:col-start-6 xl:col-start-5">
                            <div class="aspect-h-2 aspect-w-5 overflow-hidden rounded-lg bg-gray-100">
                                <img src="/img/pm.jpg"
                                    alt="White canvas laptop sleeve with gray felt interior, silver zipper, and tan leather zipper pull."
                                    class="object-cover object-center w-[800px] h-[300px]">
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col-reverse lg:grid lg:grid-cols-12 lg:items-center lg:gap-x-8">
                        <div class="mt-6 lg:col-span-5 lg:row-start-1 lg:mt-0 xl:col-span-4 lg:col-start-8 xl:col-start-9">
                            <h3 class="wow animate__lightSpeedInRight text-lg font-bold text-primary">Import Advisory</h3>
                            <p data-wow-dalay="1s" class="wow animate__lightSpeedInRight mt-2 text-sm text-black font-medium">
                                Our Import Advisory service is designed to provide professional guidance and support for
                                individuals
                                who prefer to personally import their equipment. By leveraging our vast network and
                                relationships with
                                international suppliers, we are able to source high-quality equipment at competitive
                                prices, helping you
                                make the most cost-effective choices.
                            </p>
                        </div>
                        <div class="flex-auto lg:col-span-7 lg:row-start-1 xl:col-span-8 lg:col-start-1">
                            <div class="aspect-h-2 aspect-w-5 overflow-hidden rounded-lg bg-gray-100">
                                <img src="/img/imp.jpg"
                                    alt="Detail of zipper pull with tan leather and silver rivet."
                                    class="object-cover object-center w-[800px] h-[300px]">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>






    </div>
</template>