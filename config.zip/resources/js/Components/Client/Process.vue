<script setup>

</script>

<template>
    <div>
        <div class="bg-black py-14 sm:py-32"> 
            <div class="mx-auto max-w-[100vw] px-6 lg:px-8">

                <div class="mx-auto max-w-4xl text-center">
                    <h2 class="text-base font-semibold leading-7 text-primary">This is how we can work together</h2>
                    <p data-wow-duration="1.5s" class="wow animate__rubberBand mt-2 text-4xl font-bold tracking-tight text-white sm:text-5xl">Our Process</p>
                </div>

                <div class="isolate mx-auto mt-10 grid max-w-md grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-3">

                    <div
                        data-wow-delay="1s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-messages-question group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">
                                Initial
                                Consultation
                            </span>
                        </p>
                        <p class="mt-4 text-xs sm:text-sm leading-6 text-white">
                            Picture this: you, us, and a cup of coffee. During our initial consultation, we dive deep into
                            your dreams, your vision, and even your secret recipe aspirations. We listen, we learn, and
                            together, we craft a plan that aligns with your goals, budget, and unique needs. Consider us
                            your kitchen confidantes, ready to guide you every step of the way
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 1 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="1.5s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-compass-drafting group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Design and
                                Layout</span>
                        </p>
                        <p class="mt-4 text-xs sm:text-sm leading-6 text-white">
                            Based on the brief gotten during the initial consultation, our experienced designers
                            will work closely
                            with you to create a customized kitchen design. We consider factors such as workflow
                            optimization,
                            space utilization, and regulatory compliance to ensure an efficient and functional
                            design. We leverage
                            our expertise to help you maximize productivity, create ergonomic workstations, and
                            optimize the
                            overall efficiency of your kitchen space.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 2 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="2s"
                        class="wow animate__backInUp elative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-ballot-check group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Equipment
                                Selection</span>
                        </p>
                        <p class="mb-16 mt-4 text-xs sm:text-sm leading-6 text-white">
                            Once we have agreed on the kitchen layout, we proceed to equipment selection. Choosing
                            the right
                            equipment is crucial for the success of your commercial kitchen. With our deep knowledge
                            of the
                            industry, we assist you in selecting the most suitable equipment for your specific
                            needs. We will take
                            into account your menu requirements, capacity needs, budget constraints, and quality
                            standards to
                            recommend reliable and high-performing equipment that aligns with your business goals.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 3 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="1s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-users group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Supplier Qualification &
                                Procurement
                            </span>
                        </p>
                        <p class="mt-4 text-xs sm:text-sm leading-6 text-white">
                            Navigating the multitude of suppliers can be overwhelming. As part of our comprehensive
                            service, we
                            shall handle the supplier qualification process for you. We will thoroughly evaluate and
                            prequalify
                            suppliers based on their reputation, product quality, pricing, and customer service.
                            Once the supplier is
                            selected, we manage the procurement process to ensure a seamless experience, including
                            negotiating
                            pricing, handling order placement, and coordinating logistics for timely delivery of the
                            equipment.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 4 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="1.5s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-user-helmet-safety group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Project
                                Management
                            </span>
                        </p>
                        <p class="mt-4 text-xs sm:text-sm leading-6 text-white">
                            We understand that overseeing a commercial kitchen project can be challenging,
                            especially when
                            coordinating multiple stakeholders. As your dedicated project managers, we take on the
                            responsibility

                            of managing the entire project on your behalf. We coordinate with suppliers,
                            contractors, and other
                            involved parties to ensure smooth progress, timely execution, and adherence to quality
                            standards. Our
                            meticulous project management approach allows you to focus on your core business while
                            we handle
                            the complexities of the project.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block  absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 5 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="2s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-wrench group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Installation
                                and Testing
                            </span>
                        </p>
                        <p class="mb-20 mt-4 text-xs sm:text-sm leading-6 text-white">
                            Efficient and accurate installation of equipment is vital to the functionality and
                            safety of your
                            commercial kitchen. Our team of experts will work closely with the selected suppliers
                            and contractors to
                            coordinate the installation process. We ensure that all equipment is installed properly
                            and in compliance
                            with relevant regulations and industry standards. Rigorous testing and quality checks
                            are conducted to
                            ensure that each piece of equipment operates seamlessly and meets your requirements.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10  transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 6 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="1s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-folder-open group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Handover &
                                Documentation
                            </span>
                        </p>
                        <p class="mt-4 text-xs sm:text-sm leading-6 text-white">
                            Once the installation is complete, we facilitate a comprehensive handover process. We
                            ensure that you
                            are provided with all relevant documentation, including warranties, operating manuals,
                            and
                            maintenance guidelines, ensuring that you have the necessary information to operate and
                            maintain your
                            commercial kitchen effectively.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 7 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="1.5s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-users-gear group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Maintenance
                                Contracts
                            </span>
                        </p>
                        <p class="mt-4 text-xs sm:text-sm leading-6 text-white">
                            Our relationship doesn't end with the completion of your kitchen. We're
                            committed to your ongoing
                            success We work closely with the awarded suppliers to ensure that they offer
                            comprehensive after-sales
                            support and maintenance services. We help facilitate the process of signing the
                            maintenance contract,
                            ensuring that you have a dedicated agreement in place for regular upkeep and servicing
                            of your
                            commercial kitchen. This ensures that your equipment remains in excellent condition and
                            minimizes any
                            potential downtime.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 8 <i class="fas fa-angles-right text-primary"></i>
                        </a>
                    </div>

                    <div
                        data-wow-delay="2s"
                        class="wow animate__backInUp relative transform transition hover:scale-105 duration-700 ease-out rounded-3xl p-8 xl:p-10 ring-2 hover:ring-3 ring-primary hover:ring-white group">
                        <div class="flex items-center justify-between gap-x-4">
                            <h3 id="tier-freelancer" class="text-lg font-semibold leading-8 text-white">
                                <i
                                    class="transform transition group-hover:scale-75 duration-700 ease-out fas fa-comment-smile group-hover:text-white text-primary fa-2xl"></i>
                            </h3>
                        </div>

                        <p class="mt-6 flex items-baseline gap-x-1">
                            <span class="text-lg sm:text-3xl font-bold tracking-tight text-white group-hover:text-primary">Customer
                                Satisfaction and Success
                            </span>
                        </p>
                        <p class="pb-16 mt-4 text-xs sm:text-sm leading-6 text-white">
                            We measure our success by your satisfaction. After completing the installation and
                            ensuring everything is in perfect working order, we take a moment to celebrate your
                            kitchen triumph. Your delight and happiness are our greatest rewards. We make sure
                            you're fully satisfied with your new, fully functional kitchen, ready to create
                            memorable experiences and drive your business forward. Your success is our ultimate
                            validation, and we're proud to have played a part in making your kitchen dreams come
                            true.
                        </p>
                        <a href="#" aria-describedby="tier-freelancer"
                            class="hidden sm:block absolute bottom-10 transform transition group-hover:scale-75 duration-700 ease-out mt-6 block rounded-md py-2 px-3 text-center text-sm font-semibold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 bg-white/10 group-hover:bg-primary text-white focus-visible:outline-white">
                            Step 9 
                        </a>
                    </div>

                </div>


            </div>
        </div>

    </div>
</template>