<script setup>

</script>

<template>
    <div>
        <div class="overflow-hidden bg-white py-10 sm:py-32">
            <div class="mx-auto max-w-7xl px-6 lg:flex lg:px-8">  
                <div
                    class="mx-auto grid max-w-2xl grid-cols-1 gap-x-12 gap-y-16 lg:mx-0 lg:min-w-full lg:max-w-none lg:flex-none lg:gap-y-8">
                    <div class="lg:col-end-1 lg:w-full lg:max-w-3xl lg:pb-8">
                        <h2 data-wow-delay="1s" data-wow-duration="1s" class="wow animate__lightSpeedInRight text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Why Choose Us?</h2>
                        <p data-wow-delay="1s" data-wow-duration="1s" class="wow animate__lightSpeedInLeft mt-6 text-xl leading-10 text-primary font-bold">We are a team that Cares!</p>
                        <p class="mt-6  leading-7 text-black font-medium text-sm sm:text-md">
                            Navigating the complexities of setting up a commercial kitchen can be a daunting task. With
                            countless decisions to make, from design and equipment selection to supplier negotiations and
                            project management, it's easy to feel overwhelmed. That's where we come in. At Commercial
                            Kitchens Consultants, we specialize in simplifying the process for you. Our expert team takes
                            the burden off your shoulders, leveraging our industry knowledge and experience to guide you
                            every step of the way. By entrusting your commercial kitchen project to us, you can save
                            valuable time and resources while gaining peace of mind, knowing that you have a dedicated
                            partner who will ensure that your vision becomes a reality. Let us make the process easier for
                            you, so you can focus on what you do best – running your business.
                        </p>
                        <div class="mt-12 sm:flex justify-between">
                            
                            <a href="tel:+254717269050" class="group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex">
                                <div data-wow-duration="1.5s"  data-wow-delay="1.5s" class="wow animate__lightSpeedInLeft h-20 w-20 bg-white rounded group-hover:bg-primary">
                                    <i class="fas fa-phone flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white"></i>
                                </div>
    
                                <div class="ml-5">
                                    <div class="">
                                        <h1 data-wow-duration="1s"  data-wow-delay="2s" class="wow animate__lightSpeedInLeft font-bold text-2xl leading-10 text-primary">Get Expert Advice</h1>
                                        <h5 data-wow-duration="1s"  data-wow-delay="2.5s" class="wow animate__lightSpeedInLeft font-bold leading-10 text-lg sm:text-2xl"> +254 115 511 079</h5>
                                    </div>
                                </div>
                            </a>

                            <a href="mailto:info@commercialkitchen.co.ke" class="group transform transition hover:scale-95 duration-700 ease-out hover:cursor-pointer flex">
                                    <div data-wow-duration="1.5s"  data-wow-delay="1s" class="wow animate__lightSpeedInLeft h-20 w-20 bg-white rounded group-hover:bg-primary">
                                        <i class="fas fa-envelope flex w-full h-full justify-center items-center fa-2xl text-black group-hover:text-white"></i>
                                    </div>
    
                                    <div class="ml-5">
                                        <div class="">
                                            <h1 data-wow-duration="1s"  data-wow-delay="1.5s" class="wow animate__lightSpeedInLeft font-bold text-2xl leading-10 text-primary">Get Expert Advice</h1>
                                            <h5 data-wow-duration="1s"  data-wow-delay="2s" class="wow animate__lightSpeedInLeft font-bold leading-10 text-sm sm:text-xl"> info@commercialkitchen.co.ke</h5>
                                        </div>
                                    </div>
                                </a>


                        </div>
                    </div>
                    <div class="flex flex-wrap items-start justify-end gap-6 sm:gap-8 lg:contents">
                        <div class="w-0 flex-auto lg:ml-auto lg:w-auto lg:flex-none lg:self-end ">
                            <img src="/img/y.jpg"
                                alt=""
                                class="transform -translate-x-64 sm:-translate-x-5 ring-2 ring-primary aspect-[7/5] w-[37rem] max-w-none rounded-2xl bg-gray-50 object-cover  h-[600px]">
                        </div>
                        <!-- <div
                            class="contents lg:col-span-2 lg:col-end-2 lg:ml-auto lg:flex lg:w-[37rem] lg:items-start lg:justify-end lg:gap-x-8">
                            <div class="order-first flex w-64 flex-none justify-end self-end lg:w-auto">
                                <img src="https://images.unsplash.com/photo-1605656816944-971cd5c1407f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=768&h=604&q=80"
                                    alt=""
                                    class="ring-4 ring-primary aspect-[4/3] w-[24rem] max-w-none flex-none rounded-2xl bg-gray-50 object-cover">
                            </div>
                            <div class="flex w-96 flex-auto justify-end lg:w-auto lg:flex-none">
                                <img src="https://images.unsplash.com/photo-1568992687947-868a62a9f521?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1152&h=842&q=80"
                                    alt=""
                                    class="ring-4 ring-black aspect-[7/5] w-[37rem] max-w-none flex-none rounded-2xl bg-gray-50 object-cover">
                            </div>
                            <div class="hidden sm:block sm:w-0 sm:flex-auto lg:w-auto lg:flex-none">
                                <img src="https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=768&h=604&q=80"
                                    alt=""
                                    class="ring-4 ring-primary aspect-[4/3] w-[24rem] max-w-none rounded-2xl bg-gray-50 object-cover">
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>